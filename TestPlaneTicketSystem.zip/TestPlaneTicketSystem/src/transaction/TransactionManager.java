package transaction;

import java.sql.SQLException;

import exception.DataAccessException;

/**
 * 事务管理器
 * @author ljd
 *
 */
public interface TransactionManager {
	/**
	 * 开启事务
	 * @throws DataAccessException 
	 */
	public abstract void beginTransation() throws SQLException, DataAccessException;
	/**
	 * 提交事务
	 * @throws SQLException 
	 * @throws DataAccessException 
	 */
	public abstract void commit() throws SQLException, DataAccessException;
	/**
	 * 回滚事务
	 * @throws DataAccessException 
	 */
	public abstract void rollback() throws DataAccessException;
}
