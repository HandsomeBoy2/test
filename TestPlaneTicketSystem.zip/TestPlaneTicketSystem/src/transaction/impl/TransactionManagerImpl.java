package transaction.impl;

import java.sql.Connection;
import java.sql.SQLException;

import exception.DataAccessException;

import transaction.TransactionManager;
import util.JDBCUtil;
/**
 * 事务管理器接口的实现类
 * @author soft01
 *
 */
public class TransactionManagerImpl implements TransactionManager{
	/**
	 * 开启事务
	 * @throws SQLException 
	 * @throws DataAccessException 
	 */
	public void beginTransation() throws SQLException, DataAccessException {
		Connection  con = null;
		try {
			con = JDBCUtil.getConnection();
			con.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataAccessException("数据库访问异常");
		}
	}
	/**
	 * 提交事务
	 * @throws SQLException 
	 * @throws DataAccessException 
	 */
	public void commit() throws SQLException, DataAccessException {
		Connection con = null;
		try {
			con = JDBCUtil.getConnection();
			con.commit();
		} catch (SQLException e) {
			con.rollback();
			e.printStackTrace();
			throw new DataAccessException("数据库访问异常");
		}finally{
			JDBCUtil.close();
		}
	}
	/**
	 * 回滚事务
	 * @throws DataAccessException 
	 */
	public void rollback() throws DataAccessException {
		Connection con = null;
		try {
			con = JDBCUtil.getConnection();
			con.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataAccessException("数据库访问异常");
		}finally{
			JDBCUtil.close();
		}
	}

}
