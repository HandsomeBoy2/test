create table admin (
	id varchar(18) primary key not null Comment '身份证号码',
	userName varchar(20) not null Comment '用户名',
	password varchar(20) not null  Comment '密码',
	name varchar(20) not null Comment '姓名',
	phoneNumber varchar(20) not null Comment '手机号'
)Comment='管理员信息表';

create table flightTable(
	flightNumber varchar(10) primary key not null  Comment '航班号',
	takeoffTime varchar(20) not null Comment '出发时间',
	flyingTime varchar(20) not null Comment '飞行时间',
	startPlace varchar(20) not null Comment '出发地',
	endPlace varchar(20) not null Comment '目的地',
	tickets int not null Comment '余票',
	price float not null Comment '票价'
)Comment= '航班信息表';

create table user(
	id varchar(18) primary key not null  Comment '身份证号',
	name varchar(20) not null Comment '姓名',
	userName varchar(20) not null Comment '用户名',
	password varchar(20) not null Comment '密码',
	gender varchar(20) not null Comment '性别',
	phoneNumber varchar(20) not null Comment '手机号',
	email varchar(20) not null Comment '邮箱',
	address varchar(20) not null Comment '地址'
)Comment= '用户信息表';

create table purchaseTicketInformation (
	orderNumber int primary key not null auto_increment Comment '订单号',
	flightNumber varchar(10) not null Comment'航班号',
	id varchar(18) not null Comment'用户id',
	status varchar(20) not null Comment '订票状态'
)Comment='购票信息表';

constraint fk_flightNumber foreign key (flightNumber) references flightTable(flightNumber) Comment '关联航班信息表'
constraint fk_userId foreign key (userId) references user(id)  Comment '关联user表'






