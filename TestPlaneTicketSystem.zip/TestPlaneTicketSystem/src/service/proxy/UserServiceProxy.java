package service.proxy;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import entity.FlightTable;
import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.FlightTableNotFoundException;
import exception.PurchaseTicketInformationNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;
import service.UserService;
import transaction.TransactionManager;

public class UserServiceProxy implements UserService, Serializable{

	
	private static final long serialVersionUID = 1L;

	public void regist(User user) throws DuplicateUsernameException,
	ServiceException, SQLException, DataAccessException, UserNotFoundException {
		UserService service=(UserService) ObjectFactory.getObject("UserServiceTarget");
		TransactionManager tm=(TransactionManager) ObjectFactory.getObject("TransactionManager");
		try {
			//在执行真正的业务逻辑之前将事务开启
			tm.beginTransation();
			service.regist(user);
			//业务逻辑运行成功提交事务
			tm.commit();
		} catch (DuplicateUsernameException e) {
			e.printStackTrace();
			//当业务逻辑运行失败回滚事务
			tm.rollback();
			throw e;
		} catch (ServiceException e) {
			e.printStackTrace();
			//当业务逻辑运行失败回滚事务
			tm.rollback();
			throw e;
		}
		
	}
	
	public User login(String userName, String password)
			throws UserNotFoundException, ServiceException, DataAccessException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		User user = null;
		try {
			//开启事务
			tm.beginTransation();
			user = us.login(userName, password);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		} catch (UserNotFoundException e) {
				e.printStackTrace();
				tm.rollback();
				throw e;
		}
		return user;
	}

	public void modifyInformation(User user) throws ServiceException,
			SQLException, DataAccessException, UserNotFoundException, DuplicateUsernameException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		try {
			//开启事务
			tm.beginTransation();
			us.modifyInformation(user);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}
	}

	public void deleteTicket(int orderNumber) throws DataAccessException,
			ServiceException, FlightTableNotFoundException,
			PurchaseTicketInformationNotFoundException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		try {
			//开启事务
			tm.beginTransation();
			us.deleteTicket(orderNumber);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}		
	}

	public FlightTable findFlighttableByFlightNumber(String FlightNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		FlightTable ft = null;
		try {
			//开启事务
			tm.beginTransation();
			ft = us.findFlighttableByFlightNumber(FlightNumber);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}		
		return ft;
	}

	public FlightTable findFlighttableByStartPlaceAndEndPlaceAndDate(
			String startPlace, String endPlace, String date)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		FlightTable ft = null;
		try {
			//开启事务
			tm.beginTransation();
			ft = us.findFlighttableByStartPlaceAndEndPlaceAndDate(startPlace, endPlace, date);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}		
		return ft;
	}

	public void modifyTicket(User user, FlightTable ft, int orderNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException,
			PurchaseTicketInformationNotFoundException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		try {
			//开启事务
			tm.beginTransation();
			us.modifyTicket(user, ft, orderNumber);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}		
		
	}

	public void orderTicket(User user, FlightTable ft)
			throws DataAccessException, ServiceException,
			UserNotFoundException, FlightTableNotFoundException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		try {
			//开启事务
			tm.beginTransation();
			us.orderTicket(user, ft);
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}		
		
	}

	public List<FlightTable> findAllFlighttable() throws DataAccessException,
			ServiceException, FlightTableNotFoundException, SQLException {
		//获得UserService的实现类对象
		UserService us = (UserService)ObjectFactory.getObject("UserServiceTarget");
		//获得事务管理器
		TransactionManager tm = (TransactionManager)ObjectFactory.getObject("TransactionManager");
		List <FlightTable> ft = null;
		try {
			//开启事务
			tm.beginTransation();
			ft = us.findAllFlighttable();
			//提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			//回滚事务
			tm.rollback();
			throw e;
		}		
		return ft;
	}
}
