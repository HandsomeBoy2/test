package service.proxy;

import java.sql.SQLException;
import java.util.List;

import entity.Admin;
import entity.FlightTable;
import exception.AdminNotFoundException;
import exception.DataAccessException;
import exception.DuplicateFlightTableException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;
import service.AdminService;
import transaction.TransactionManager;

public class AdminServiceProxy implements AdminService{

	public Admin login(String userName, String password)
			throws UserNotFoundException, ServiceException,
			DataAccessException, SQLException, AdminNotFoundException {
		// 获得AdminService的实现类对象
		AdminService as = (AdminService) ObjectFactory
				.getObject("AdminServiceTarget");
		// 获得事务管理器
		TransactionManager tm = (TransactionManager) ObjectFactory
				.getObject("TransactionManager");
		Admin admin = null;
		try {
			// 开启事务
			tm.beginTransation();
			admin = as.login(userName, password);
			// 提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			// 回滚事务
			tm.rollback();
			throw e;
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			tm.rollback();
			throw e;
		}
		return admin;
	}

	public void addFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, DuplicateFlightTableException,
			FlightTableNotFoundException, SQLException {
		// 获得AdminService的实现类对象
		AdminService as = (AdminService) ObjectFactory
				.getObject("AdminServiceTarget");
		// 获得事务管理器
		TransactionManager tm = (TransactionManager) ObjectFactory
				.getObject("TransactionManager");
		try {
			// 开启事务
			tm.beginTransation();
			as.addFlighttable(ft);
			// 提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			// 回滚事务
			tm.rollback();
			throw e;
		} catch (DuplicateFlightTableException e) {
			e.printStackTrace();
			tm.rollback();
			throw e;
		}
		
	}

	public void deleteFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, FlightTableNotFoundException, SQLException {
		// 获得AdminService的实现类对象
		AdminService as = (AdminService) ObjectFactory
				.getObject("AdminServiceTarget");
		// 获得事务管理器
		TransactionManager tm = (TransactionManager) ObjectFactory
				.getObject("TransactionManager");
		try {
			// 开启事务
			tm.beginTransation();
			as.deleteFlighttable(ft);
			// 提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			// 回滚事务
			tm.rollback();
			throw e;
		} catch (FlightTableNotFoundException e) {
			e.printStackTrace();
			tm.rollback();
			throw e;
		}
		
	}

	public List<FlightTable> findFlighttableByFlightNumber(String FlightNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException, SQLException {
		// 获得AdminService的实现类对象
		AdminService as = (AdminService) ObjectFactory
				.getObject("AdminServiceTarget");
		// 获得事务管理器
		TransactionManager tm = (TransactionManager) ObjectFactory
				.getObject("TransactionManager");
		List<FlightTable> ft = null;
		try {
			// 开启事务
			tm.beginTransation();
			ft = as.findFlighttableByFlightNumber(FlightNumber);
			// 提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			// 回滚事务
			tm.rollback();
			throw e;
		} catch (FlightTableNotFoundException e) {
			e.printStackTrace();
			tm.rollback();
			throw e;
		}
		return ft;
	}

	public List<FlightTable> findFlighttableByStartPlaceAndEndPlaceAndDate(
			String startPlace, String endPlace, String date)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException, SQLException {
		// 获得AdminService的实现类对象
		AdminService as = (AdminService) ObjectFactory
				.getObject("AdminServiceTarget");
		// 获得事务管理器
		TransactionManager tm = (TransactionManager) ObjectFactory
				.getObject("TransactionManager");
		List<FlightTable> ft = null;
		try {
			// 开启事务
			tm.beginTransation();
			ft = as.findFlighttableByStartPlaceAndEndPlaceAndDate(startPlace, endPlace, date);
			// 提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			// 回滚事务
			tm.rollback();
			throw e;
		} catch (FlightTableNotFoundException e) {
			e.printStackTrace();
			tm.rollback();
			throw e;
		}
		return ft;
	}

	public void modifyFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, FlightTableNotFoundException, SQLException {
		// 获得AdminService的实现类对象
		AdminService as = (AdminService) ObjectFactory
				.getObject("AdminServiceTarget");
		// 获得事务管理器
		TransactionManager tm = (TransactionManager) ObjectFactory
				.getObject("TransactionManager");
		try {
			// 开启事务
			tm.beginTransation();
			as.modifyFlighttable(ft);
			// 提交事务
			tm.commit();
		} catch (DataAccessException e) {
			e.printStackTrace();
			// 回滚事务
			tm.rollback();
			throw e;
		} catch (FlightTableNotFoundException e) {
			e.printStackTrace();
			tm.rollback();
			throw e;
		}
		
	}
	
}
