package service;

import java.sql.SQLException;
import java.util.List;

import entity.FlightTable;
import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.FlightTableNotFoundException;
import exception.PurchaseTicketInformationNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;

/**
 * 用户服务接口
 * @author xzf
 *
 */
public interface UserService {
	/*
	 * 1.根据用户名密码查询用户
	 */
	/**
	 * 1.用户登录功能
	 * @param userName
	 * @param password
	 * @return User
 	 * @throws UserNotFoundException
	 * @throws ServiceException 
	 * @throws DataAccessException 
	 * @throws SQLException 
	 */
	public abstract User login(String userName, String password) throws UserNotFoundException, ServiceException, DataAccessException, SQLException;

	/*
	 * 1.根据用户名判断用户名是否存在
	 * 2.用户注册功能
	 */
	/**
	 * 用户注册功能
	 * @param user 封装了用户信息的对象
	 * @throws DuplicateUsernameException 重复的用户名异常
	 * @throws ServiceException	当程序在运行过程中发生不可预知错误所抛出
	 * @throws DataAccessException 
	 * @throws SQLException 
	 * @throws UserNotFoundException 
	 */
	public abstract void regist(User user) throws DuplicateUsernameException,ServiceException, SQLException, DataAccessException, UserNotFoundException;
	
	/**
	 * 用户修改用户信息
	 * @param user
	 * @throws ServiceException
	 * @throws SQLException
	 * @throws DataAccessException
	 * @throws DuplicateUsernameException 
	 */
	public abstract void modifyInformation(User user) throws  ServiceException, SQLException, DataAccessException,UserNotFoundException, DuplicateUsernameException;
	
	
	/**
	 * 根据出发地.目的地.日期查询
	 * @param startPlace
	 * @param endPlace
	 * @param date
	 * @return FlightTable
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract FlightTable findFlighttableByStartPlaceAndEndPlaceAndDate(String startPlace, String endPlace, String date)
						throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;
	
	/**
	 * 根据航班号查询
	 * @param FlightNumber
	 * @return FlightTable
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract FlightTable findFlighttableByFlightNumber(String FlightNumber)
				throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;
	
	/**
	 * 查询所有的航班信息
	 * @return list
	 * @throws DataAccessException
	 * @throws ServiceException
	 * @throws FlightTableNotFoundException
	 * @throws SQLException
	 */
	public abstract List<FlightTable> findAllFlighttable()
							throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;

	/**
	 * 用户订票
	 * @param user
	 * @param ft
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract void orderTicket(User user, FlightTable ft) 
			throws DataAccessException, ServiceException, UserNotFoundException, FlightTableNotFoundException, SQLException;
	
	/**
	 * 用户改签         
	 * @param user
	 * @param ft
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract void modifyTicket(User user, FlightTable ft, int orderNumber) 
		throws DataAccessException, ServiceException, FlightTableNotFoundException, PurchaseTicketInformationNotFoundException, SQLException;
	
	/**
	 * 根据订单号给用户退票
	 * @param orderNumber
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract void deleteTicket(int orderNumber) 
		throws DataAccessException, ServiceException, FlightTableNotFoundException, PurchaseTicketInformationNotFoundException, SQLException;
	
}
