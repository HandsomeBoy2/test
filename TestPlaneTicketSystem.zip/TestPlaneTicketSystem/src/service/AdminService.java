package service;

import java.sql.SQLException;
import java.util.List;

import entity.Admin;
import entity.FlightTable;
import exception.AdminNotFoundException;
import exception.DataAccessException;
import exception.DuplicateFlightTableException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;

/**
 * 管理员服务接口
 * @author xzf
 *
 */
public interface AdminService {
	/**
	 * 1.管理员登录功能
	 * @param userName
	 * @param password
	 * @return User
 	 * @throws UserNotFoundException
	 * @throws ServiceException 
	 * @throws DataAccessException 
	 * @throws SQLException 
	 * @throws AdminNotFoundException 
	 */
	public abstract Admin login(String userName, String password) throws UserNotFoundException, ServiceException, DataAccessException, SQLException, AdminNotFoundException;

	
	/**
	 * 删除航班
	 * @param ids
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract void deleteFlighttable(FlightTable  ft) 
						throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;
	/**
	 * 修改航班
	 * @param ft
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract void modifyFlighttable(FlightTable  ft)
			throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;
	/**
	 * 添加航班
	 * @param ft
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract void addFlighttable(FlightTable ft) 
			throws DataAccessException, ServiceException, DuplicateFlightTableException, FlightTableNotFoundException, SQLException;
	
	/**
	 * 根据出发地.目的地.日期查询
	 * @param startPlace
	 * @param endPlace
	 * @param date
	 * @return FlightTable
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract List<FlightTable> findFlighttableByStartPlaceAndEndPlaceAndDate(String startPlace, String endPlace, String date)
						throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;
	
	/**
	 * 根据航班号查询
	 * @param FlightNumber
	 * @return FlightTable
	 * @throws DataAccessException
	 * @throws SQLException 
	 */
	public abstract List<FlightTable> findFlighttableByFlightNumber(String FlightNumber)
					throws DataAccessException, ServiceException, FlightTableNotFoundException, SQLException;
	
}
