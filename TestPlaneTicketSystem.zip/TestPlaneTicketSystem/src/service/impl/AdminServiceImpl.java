package service.impl;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import dao.AdminDao;
import dao.UserDao;

import entity.Admin;
import entity.FlightTable;
import exception.AdminNotFoundException;
import exception.DataAccessException;
import exception.DuplicateFlightTableException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;
import service.AdminService;

public class AdminServiceImpl implements AdminService{

	public Admin login(String userName, String password)
			throws UserNotFoundException, ServiceException,
			DataAccessException, SQLException, AdminNotFoundException {
		AdminDao ad = (AdminDao)ObjectFactory.getObject("AdminDaoTarget");
		Admin admin = null;
		try {
			 admin = ad.selectAdminByUsernameAndPassword(userName, password);
			 if(admin==null){
					throw new UserNotFoundException("管理员用户名密码不正确");
			}
		} catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试！");
		}	
		return admin;
	}

	public void addFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, DuplicateFlightTableException,
			FlightTableNotFoundException {
		AdminDao ad = (AdminDao)ObjectFactory.getObject("AdminDaoTarget");
		try{
			// 判断用户名是否重复
			List<FlightTable> f = ad.selectFlighttableByFlightNumber(ft.getFlightNumber());
			if(f != null){
				throw new DuplicateFlightTableException("该航班号已存在");
			}
			ad.addFlighttable(ft); 
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		
	}

	public void deleteFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, FlightTableNotFoundException {
		AdminDao ad = (AdminDao)ObjectFactory.getObject("AdminDaoTarget");
		try{
			ad.deleteFlighttable(ft);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		
	}

	public List<FlightTable> findFlighttableByFlightNumber(String FlightNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		AdminDao ad = (AdminDao)ObjectFactory.getObject("AdminDaoTarget");
		List<FlightTable> ft= null;
		try{
			ft = ad.selectFlighttableByFlightNumber(FlightNumber);
			if(ft == null){
					throw new FlightTableNotFoundException("没有查询到任何航班信息");
			}
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		return ft;
	}

	public List<FlightTable> findFlighttableByStartPlaceAndEndPlaceAndDate(
			String startPlace, String endPlace, String date)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		AdminDao ad = (AdminDao)ObjectFactory.getObject("AdminDaoTarget");
		List<FlightTable> ft= null;
		try{
			ft = ad.selectFlighttableByStartPlaceAndEndPlaceAndDate(startPlace, endPlace, date);
			if(ft == null){
					throw new FlightTableNotFoundException("没有查询到任何航班信息");
			}
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		return ft;
	}

	public void modifyFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, FlightTableNotFoundException {
		AdminDao ad = (AdminDao)ObjectFactory.getObject("AdminDaoTarget");
		try{
			 ad.modifyFlighttable(ft);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
	}

}
