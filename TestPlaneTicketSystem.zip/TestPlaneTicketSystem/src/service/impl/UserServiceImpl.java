package service.impl;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import dao.UserDao;
import entity.FlightTable;
import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.FlightTableNotFoundException;
import exception.PurchaseTicketInformationNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;
import service.UserService;

public class UserServiceImpl implements UserService, Serializable{

	
	private static final long serialVersionUID = 1L;
	
	//登录
	public User login(String userName, String password)
			throws UserNotFoundException, ServiceException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		User user = null;
		try {
			 user = ud.selectUserByUsernameAndPassword(userName, password);
			 if(user==null){
					throw new UserNotFoundException("用户名密码不正确");
			}
		} catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试！");
		}	
		return user;
	}

	//注册
	public void regist(User user) throws DuplicateUsernameException,
			ServiceException, UserNotFoundException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		User u= null;
		try{
			u = ud.selectUserByUsername(user.getUserName());
			if(u != null){
				throw new DuplicateUsernameException("用户名已存在");
			}
			ud.insert(user);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
	}

	//修改信息
	public void modifyInformation(User user) throws ServiceException,
			SQLException, DataAccessException, DuplicateUsernameException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		try{
			ud.update(user);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		
	}

	//根据订单号给用户退票
	public void deleteTicket(int orderNumber) throws DataAccessException,
			ServiceException, FlightTableNotFoundException,
			PurchaseTicketInformationNotFoundException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		try{
			ud.deleteTicket(orderNumber);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
	}

	//根据航班号查询
	public FlightTable findFlighttableByFlightNumber(String FlightNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		FlightTable ft= null;
		try{
			ft = ud.selectFlighttableByFlightNumber(FlightNumber);
			if(ft == null){
					throw new FlightTableNotFoundException("没有查询到任何航班信息");
			}
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		return ft;
	}

	//根据出发地.目的地.日期查询
	public FlightTable findFlighttableByStartPlaceAndEndPlaceAndDate(
			String startPlace, String endPlace, String date)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		FlightTable ft= null;
		try{
			ft = ud.selectFlighttableByStartPlaceAndEndPlaceAndDate(startPlace, endPlace, date);
			if(ft == null){
					throw new FlightTableNotFoundException("没有查询到任何航班信息");
			}
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		return ft;
	}
	//用户改签
	public void modifyTicket(User user, FlightTable ft, int orderNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException,
			PurchaseTicketInformationNotFoundException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		try{
			ud.modifyTicket(user, ft, orderNumber);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		
	}
	//用户订票
	public void orderTicket(User user, FlightTable ft)
			throws DataAccessException, ServiceException,
			UserNotFoundException, FlightTableNotFoundException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		try{
			ud.orderTicket(user, ft);
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
	}

	public List<FlightTable> findAllFlighttable() throws DataAccessException,
			ServiceException, FlightTableNotFoundException, SQLException {
		UserDao ud = (UserDao)ObjectFactory.getObject("UserDaoTarget");
		List <FlightTable> ft= null;
		try{
			ft = ud.selectAllFlighttable();
			if(ft == null){
					throw new FlightTableNotFoundException("没有查询到任何航班信息");
			}
		}catch (DataAccessException e){
			e.printStackTrace();
			throw new ServiceException("系统忙，稍后再试");
		}
		return ft;
	}

}
