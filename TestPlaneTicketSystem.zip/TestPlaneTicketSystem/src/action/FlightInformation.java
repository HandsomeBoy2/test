package action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import service.AdminService;
import service.UserService;

import entity.FlightTable;
import entity.User;
import exception.DataAccessException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
import factory.ObjectFactory;


public class FlightInformation { 
		private static User user;
	
		private static JTable jt;
		private static JButton selectAllButton, selectByFlightNumberButton, selectByStartPlaceAndEndPlaceAndDateButton;
		private static JButton returnButton;
		private static JTextField flightNumberJt, startPlaceJt, endPlaceJt, dateJt;
		
		
		private static JPanel jp;
		public JButton orderTicketJb  = new JButton("订票");

		public FlightInformation(User user) {
			this.user = user;
			
			jt = new JTable();
			selectAllButton = new JButton("查询所有航班");
			selectByFlightNumberButton = new JButton("按航班号查询："); 
			flightNumberJt = new JTextField(20);
			selectByStartPlaceAndEndPlaceAndDateButton = new JButton("按地点和时间查询：");
			
			
			startPlaceJt = new JTextField(20);
			endPlaceJt = new JTextField(20);
			dateJt = new JTextField(20);
			jp = new JPanel();
		}
		
		private void init(){
			JScrollPane jsp=new JScrollPane(jt);			
			jp.add(jsp);
			jp.add(selectAllButton);
			jp.add(selectByFlightNumberButton);
			jp.add(flightNumberJt);
			jp.add(selectByStartPlaceAndEndPlaceAndDateButton);
		
			
			jp.add(startPlaceJt);
			jp.add(endPlaceJt);
			jp.add(dateJt);
			
			jp.add(orderTicketJb);
		}
		
//		查询FlightTable表中所有数据
		private void initData() {
			UserService us=(UserService) ObjectFactory.getObject("UserService");
			try {
				List<FlightTable> ft= us.findAllFlighttable();
				addDataToTable(ft);	
			} catch (FlightTableNotFoundException e) {
				e.printStackTrace();
			} catch (ServiceException e) {
				e.printStackTrace();
			} catch (DataAccessException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
//		//将查询结果显示在表单中
		private  void addDataToTable(List<FlightTable> ft){
			//将查询的数据添加到表格中
			DefaultTableModel dtm=new DefaultTableModel();
//			添加表格的列名
			dtm.addColumn("flightNumber");
			dtm.addColumn("takeoffTime");
			dtm.addColumn("flyingTime");
			dtm.addColumn("startPlace");
			dtm.addColumn("endPlace");
			dtm.addColumn("tickets");
			dtm.addColumn("price");
			
//			遍历集合添加每一行数据
			for (int i = 0; i < ft.size(); i++) {
				FlightTable f=ft.get(i);
				Vector v=new Vector();
				v.add(f.getFlightNumber());
				v.add(f.getTakeoffTime());
				v.add(f.getFlyingTime());
				v.add(f.getStartPlace());
				v.add(f.getEndPlace());
				v.add(f.getTickets());
				v.add(f.getPrice());
				dtm.addRow(v);
			}		
			jt.setModel(dtm);
		}
		
		private void addEventHandler() {
			initData();
			
			orderTicketJb.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {
					UserService us=(UserService) ObjectFactory.getObject("UserService");
					try {
						
						
						
						
						
						
						
						us.orderTicket(user, ft);
						
						
//						addDataToTable(ft);	
					} catch (FlightTableNotFoundException e) {
						e.printStackTrace();
					} catch (ServiceException e) {
						e.printStackTrace();
					} catch (DataAccessException e) {
						e.printStackTrace();
					} catch (SQLException e) {
						e.printStackTrace();
					}				
				}	
			});
			
			selectAllButton.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					UserService us=(UserService) ObjectFactory.getObject("UserService");
					try {
						List<FlightTable> ft= us.findAllFlighttable();
						addDataToTable(ft);	
					} catch (FlightTableNotFoundException e) {
						e.printStackTrace();
					} catch (ServiceException e) {
						e.printStackTrace();
					} catch (DataAccessException e) {
						e.printStackTrace();
					} catch (SQLException e) {
						e.printStackTrace();
					}		
				}
			});
			
			
			selectByFlightNumberButton.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					//获得航班号文本框中的数据
					String flightNumber=flightNumberJt.getText();			
					FlightTable ft=new FlightTable();
					ft.setFlightNumber(flightNumber);
					AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
					
					try {
						List<FlightTable> f = null;
						try {
							f = service.findFlighttableByFlightNumber(ft.getFlightNumber());
						} catch (DataAccessException e1) {
							e1.printStackTrace();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
						addDataToTable(f);
					} catch (FlightTableNotFoundException e1) {
						e1.printStackTrace();
					} catch (ServiceException e1) {
						e1.printStackTrace();
					}
				}		
			});
		
			selectByStartPlaceAndEndPlaceAndDateButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {
					String takeoffTime=dateJt.getText();
					String startPlace = startPlaceJt.getText();
					String endPlace=endPlaceJt.getText();
					FlightTable ft=new FlightTable();
					//根据出发时间和起止地查询
					if(!takeoffTime.equals("") || !startPlace.equals("") || !(endPlace.equals(""))){
						ft.setTakeoffTime(takeoffTime);
						ft.setStartPlace(startPlace);
						ft.setEndPlace(endPlace);
						AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
						
						try {
							List<FlightTable> f = null;
							try {
								f = service.findFlighttableByStartPlaceAndEndPlaceAndDate(
										ft.getStartPlace(),ft.getEndPlace(), ft.getTakeoffTime());
							} catch (DataAccessException e1) {
								e1.printStackTrace();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
							addDataToTable(f);
						} catch (FlightTableNotFoundException e1) {
							e1.printStackTrace();
						} catch (ServiceException e1) {
							e1.printStackTrace();
						}
					}
				}	
			});
		}
		
		public void setJbutton(JButton orderJbutton){
			orderJbutton.setVisible(false);
		}
		public void show() { 
			init();	
			addEventHandler();
		}
		
		public JPanel getJPanel(){
			return jp;
		}
}
