package action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import service.UserService;
import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;

public class PersonalInformation {
	private User user;
	private static String id;
	
	private static JFrame jf;

	private static JPanel jp;

	private static JTextField nameJtf, usernameJtf, passwordJtf,
			genderJtf, phoneNumberJtf, emailJtf, addressJtf;

	private static JPasswordField confirmPasswordJpf;

	private static JLabel nameJl, usernameJl, passwordJl, genderJl,
			phoneNumberJl, emailJl, addressJl;

	private static JLabel confirmPasswordJl;

	private static JLabel userNameTipJl, passwordTipJl, phoneNumberTipJl,
			emailTipJl, addressTipJl;

	private static JButton modifyJb;

	public PersonalInformation(User user) {	
		this.user = user;
		id = user.getId();
		
		jf = new JFrame("用户注册信息界面");
		jp = new JPanel(null);
		jp.setBounds(400, 150, 600, 500);

		
		nameJtf=new JTextField(user.getName(),20);
		usernameJtf=new JTextField(user.getUserName(), 20);
		passwordJtf=new JTextField(user.getPassword(), 20);
		genderJtf=new JTextField(user.getGender(), 20);
		phoneNumberJtf=new JTextField(user.getPhoneNumber(), 20);
		emailJtf = new JTextField(user.getEmail(), 20);
		addressJtf=new JTextField(user.getAddress(), 20);
		
		confirmPasswordJpf=new JPasswordField(20);
		
		nameJl=new JLabel("姓名：");
		usernameJl=new JLabel("用户名：");
		userNameTipJl= new JLabel("由数字、下划线或字母组成，长度为6—16位");
		passwordJl=new JLabel("密码：");
		passwordTipJl= new JLabel("由数字、下划线或字母组成，长度为6—16位");
		genderJl=new JLabel("性别：");
		phoneNumberJl=new JLabel("电话号码：");
		phoneNumberTipJl= new JLabel("号码长度为11位");
		emailJl = new JLabel("邮箱地址：");
		emailTipJl= new JLabel("可选填");
		addressJl=new JLabel("地址：");
		addressTipJl= new JLabel("可选填");
		confirmPasswordJl = new JLabel("确认密码:");

		modifyJb = new JButton("修改");

	}

	private static void init() {
		nameJl.setBounds(10, 50, 100, 30);			
		usernameJl.setBounds(10, 90, 100, 30);
		userNameTipJl.setBounds(300, 90, 300, 30);
		passwordJl.setBounds(10, 130, 100, 30);
		passwordTipJl.setBounds(300, 130, 300, 30);
		confirmPasswordJl.setBounds(10, 170, 100, 30);
		genderJl.setBounds(10, 210, 100, 30);
		phoneNumberJl.setBounds(10, 250, 100, 30);
		phoneNumberTipJl.setBounds(300, 250, 300, 30);
		emailJl.setBounds(10, 290,100, 30);
		emailTipJl.setBounds(300, 290, 300, 30);
		addressJl.setBounds(10, 330, 100, 30);
		addressTipJl.setBounds(300, 330, 300, 30);
		
		nameJtf.setBounds(100, 50, 200, 30);	
		usernameJtf.setBounds(100, 90, 200, 30);
		passwordJtf.setBounds(100, 130, 200, 30);
		confirmPasswordJpf.setBounds(100, 170, 200, 30);
		genderJtf.setBounds(100, 210, 200, 30);
		phoneNumberJtf.setBounds(100, 250, 200, 30);
		emailJtf.setBounds(100, 290,200, 30);
		addressJtf.setBounds(100, 330, 200, 30);

		modifyJb.setBounds(200, 400, 100, 30);

		jp.add(nameJl);
		jp.add(nameJtf);
		jp.add(usernameJl);
		jp.add(usernameJtf);
		jp.add(userNameTipJl);
		jp.add(passwordJl);
		jp.add(passwordJtf);
		jp.add(passwordTipJl);
		jp.add(confirmPasswordJl);
		jp.add(confirmPasswordJpf);
		jp.add(genderJl);
		jp.add(genderJtf);
		jp.add(phoneNumberJl);
		jp.add(phoneNumberJtf);
		jp.add(phoneNumberTipJl);
		jp.add(emailJl);
		jp.add(emailJtf);
		jp.add(emailTipJl);
		jp.add(addressJl);
		jp.add(addressJtf);	
		jp.add(addressTipJl);

		jp.add(modifyJb);

		jf.add(jp);
	}

	private static void addEventHandler() {
		modifyJb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = nameJtf.getText().trim();
				String userName = usernameJtf.getText().trim();
				String password = passwordJtf.getText().trim();
				String confirmPassword = confirmPasswordJpf.getText().trim();
				String gender = genderJtf.getText().trim();
				String phoneNumber = phoneNumberJtf.getText().trim();
				String email = emailJtf.getText().trim();			
				String address = addressJtf.getText().trim();
				String userNameAndPasswordregex = "[a-zA-Z0-9_]{6,16}";
				String emailRegex = "(\\d|[a-zA-Z]){6,11}@(qq|sina).(com|cn)";
				
				if(name.equals("")){
					JOptionPane.showMessageDialog(jp, "姓名不可以是空！");
					return;		
				} else if(!userName.matches(userNameAndPasswordregex) || !(password.matches(userNameAndPasswordregex))){
					JOptionPane.showMessageDialog(jp, "用户名与密码都是由6-16数字、字母、下划线组成");
					return;					
				} else if (!password.equals(confirmPassword)){
					JOptionPane.showMessageDialog(jp, "两次密码不一致");
					return;
				}else if (phoneNumber.length() != 11){
						JOptionPane.showMessageDialog(jp, "手机号错误！应由11位数字组成");
						return;
				} else if(!email.matches(emailRegex)){
					JOptionPane.showMessageDialog(jp, "邮箱不匹配");
					return;					
				} else{
					User user = new User();
					user.setId(id);
					user.setName(name);
					user.setUserName(userName);
					user.setPassword(password);
					user.setGender(gender);
					user.setPhoneNumber(phoneNumber);	
					user.setEmail(email);
					if(!address.equals("")){
						user.setAddress(address);
					}else {
						user.setAddress(" ");
					}
						
					UserService us = (UserService) ObjectFactory.getObject("UserService");
					try {
						try {
							us.modifyInformation(user);
						} catch (UserNotFoundException e1) {
							e1.printStackTrace();
						} catch (DuplicateUsernameException e1) {
							e1.printStackTrace();
						}
						JOptionPane.showMessageDialog(jp, "修改成功");
					} catch (ServiceException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					} catch (DataAccessException e1) {
						e1.printStackTrace();
					}			
					return;
				}
			}
		});
	}

	public void show() {
		init();
		addEventHandler();
	}

	public JPanel getJPanel() {
		return jp;
	}
	
}
