package action;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import service.AdminService;
import service.UserService;
import entity.FlightTable;
import exception.DataAccessException;
import exception.DuplicateFlightTableException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
import factory.ObjectFactory;

/**
 * 管理员主界面
 * @author xzf
 *
 */
public class AdminFrame {
	private JFrame jf;
	private JPanel jpN, jpS;
	private JLabel flightNumberJLabel, takeoffTimeJLabel, flyingTimeJLabel,
							startPlaceJLabel, endPlaceJLabel, ticketsJLabel, priceJLabel;
	private JTextField flightNumberField, takeoffTimeField, flyingTimeField,
							startPlaceField, endPlaceField, ticketsField, priceField;
	private JTable jt;
	private JButton selectAllButton, addButton, removeButton, modifybButton, findButton;
	
	public AdminFrame(){
		jf=new JFrame("管理员界面");
		jpN=new JPanel();
		jpS=new JPanel();
		
		flightNumberJLabel  = new JLabel("flightNumber:");
		takeoffTimeJLabel = new JLabel("takeoffTime:");
		flyingTimeJLabel = new JLabel("flyingTime:");
		startPlaceJLabel = new JLabel("startPlace:");
		endPlaceJLabel = new JLabel("endPlace:");
		 ticketsJLabel = new JLabel("ticketsJLabel:");
		 priceJLabel = new JLabel("price:");
		 
		 flightNumberField = new JTextField(10);
		 takeoffTimeField = new JTextField(10);
		 flyingTimeField = new JTextField(10);
		 startPlaceField = new JTextField(10);
		 endPlaceField = new JTextField(10);
		 ticketsField= new JTextField(10);
		 priceField = new JTextField(10);
		 
		jt=new JTable();
		
		selectAllButton= new JButton("查询所有航班");
		addButton=new JButton("添加航班");
		removeButton=new JButton("删除航班");
		modifybButton=new JButton("修改航班");
		findButton=new JButton("查询航班");
	}
	
	public void init(){
		jpN.add(flightNumberJLabel );
		jpN.add(flightNumberField);
		jpN.add(takeoffTimeJLabel );
		jpN.add(takeoffTimeField);
		jpN.add(flyingTimeJLabel);
		jpN.add(flyingTimeField);
		jpN.add(startPlaceJLabel);
		jpN.add(startPlaceField);
		jpN.add(endPlaceJLabel);
		jpN.add(endPlaceField);
		jpN.add(ticketsJLabel);
		jpN.add(ticketsField);
		jpN.add( priceJLabel);
		jpN.add( priceField);
		
		jf.add(jpN,BorderLayout.NORTH);
		
		JScrollPane jsp=new JScrollPane(jt);
		jf.add(jsp);
		
		jpS.add(selectAllButton);
		jpS.add(addButton);
		jpS.add(removeButton);
		jpS.add(modifybButton);
		jpS.add(findButton);
		jf.add(jpS,BorderLayout.SOUTH);
	}
	
	public void setStyle(){
	
	}
	public void addEventHandler(){
		initData();
		
		//查询所有航班
		selectAllButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent arg0) {
				UserService us=(UserService) ObjectFactory.getObject("UserService");
				try {
					List<FlightTable> ft= us.findAllFlighttable();
					addDataToTable(ft);	
				} catch (FlightTableNotFoundException e) {
					e.printStackTrace();
				} catch (ServiceException e) {
					e.printStackTrace();
				} catch (DataAccessException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}		
			}
		});	
		//添加操作
		addButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				//获得七个文本框中的数据
				String flightNumber=flightNumberField.getText();
				String takeoffTime=takeoffTimeField.getText();
				String flyingTime=flyingTimeField.getText();
				String startPlace = startPlaceField.getText();
				String endPlace=endPlaceField.getText();
				int tickets=Integer.parseInt(ticketsField.getText());
				float price = Float.parseFloat(priceField.getText());
				
				FlightTable ft=new FlightTable();
				ft.setFlightNumber(flightNumber);
				ft.setTakeoffTime(takeoffTime);
				ft.setFlyingTime(flyingTime);
				ft.setStartPlace(startPlace);
				ft.setEndPlace(endPlace);
				ft.setTickets(tickets);
				ft.setPrice(price);
				
				AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
				try {
					try {
						service.addFlighttable(ft);
					} catch (DataAccessException e1) {
						e1.printStackTrace();
					} catch (FlightTableNotFoundException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					initData();
					JOptionPane.showMessageDialog(jf, "添加成功");
				} catch (ServiceException e2) {
					e2.printStackTrace();
					JOptionPane.showMessageDialog(jf, e2.getMessage());
				} catch (DuplicateFlightTableException e2) {
					e2.printStackTrace();
					JOptionPane.showMessageDialog(jf, e2.getMessage());
				}
			}
		});
		
		
		
		
		//查询操作
		findButton.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
				//获得航班号文本框中的数据
				String flightNumber=flightNumberField.getText();	
				String takeoffTime=takeoffTimeField.getText();
				String startPlace = startPlaceField.getText();
				String endPlace=endPlaceField.getText();
				FlightTable ft=new FlightTable();
				//根据航班号查询操作
				if(!flightNumber.equals("")){
					ft.setFlightNumber(flightNumber);	
					AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
					
					try {
						List<FlightTable> f = null;
						try {
							f = service.findFlighttableByFlightNumber(ft.getFlightNumber());
						} catch (DataAccessException e1) {
							e1.printStackTrace();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
						addDataToTable(f);
					} catch (FlightTableNotFoundException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(jf, e1.getMessage());
					} catch (ServiceException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(jf, e1.getMessage());
					}
				}
				//根据出发时间和起止地查询
				if(!takeoffTime.equals("") || !startPlace.equals("") || !(endPlace.equals(""))){
					ft.setTakeoffTime(takeoffTime);
					ft.setStartPlace(startPlace);
					ft.setEndPlace(endPlace);
					AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
					
					try {
						List<FlightTable> f = null;
						try {
							f = service.findFlighttableByStartPlaceAndEndPlaceAndDate(
									ft.getStartPlace(),ft.getEndPlace(), ft.getTakeoffTime());
						} catch (DataAccessException e1) {
							e1.printStackTrace();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
						addDataToTable(f);
					} catch (FlightTableNotFoundException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(jf, e1.getMessage());
					} catch (ServiceException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(jf, e1.getMessage());
					}
				}
			}
		});
		
//		删除操作
		removeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//获得航班号文本框中的数据
			String flightNumber=flightNumberField.getText();			
			FlightTable ft=new FlightTable();
			ft.setFlightNumber(flightNumber);
			AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
			try {
				try {
					service.deleteFlighttable(ft);
				} catch (DataAccessException e1) {
					e1.printStackTrace();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				initData();
			} catch (FlightTableNotFoundException e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(jf, e1.getMessage());
			} catch (ServiceException e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(jf, e1.getMessage());
			}
			}
		});
		
		//修改操作
		modifybButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				//获得七个文本框中的数据
				String flightNumber=flightNumberField.getText();
				String takeoffTime=takeoffTimeField.getText();
				String flyingTime=flyingTimeField.getText();
				String startPlace = startPlaceField.getText();
				String endPlace=endPlaceField.getText();
				int tickets=Integer.parseInt(ticketsField.getText());
				float price = Float.parseFloat(priceField.getText());
				
				FlightTable ft=new FlightTable();
				ft.setFlightNumber(flightNumber);
				ft.setTakeoffTime(takeoffTime);
				ft.setFlyingTime(flyingTime);
				ft.setStartPlace(startPlace);
				ft.setEndPlace(endPlace);
				ft.setTickets(tickets);
				ft.setPrice(price);
				
				AdminService service=(AdminService) ObjectFactory.getObject("AdminService");
				try {
					try {
						service.modifyFlighttable(ft);
					} catch (DataAccessException e1) {
						e1.printStackTrace();
					} catch (FlightTableNotFoundException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					initData();
					JOptionPane.showMessageDialog(jf, "修改成功");
				} catch (ServiceException e2) {
					e2.printStackTrace();
					JOptionPane.showMessageDialog(jf, e2.getMessage());
				}
			}
		});
	}
	
//	查询FlightTable表中所有数据
	private void initData() {
		UserService us=(UserService) ObjectFactory.getObject("UserService");
		try {
			List<FlightTable> ft= us.findAllFlighttable();

			addDataToTable(ft);
			
		} catch (FlightTableNotFoundException e) {
			e.printStackTrace();
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (DataAccessException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
//	//将查询结果显示在表单中
	private  void addDataToTable(List<FlightTable> ft){
		//将查询的数据添加到表格中
		DefaultTableModel dtm=new DefaultTableModel();
//		添加表格的列名
		dtm.addColumn("flightNumber");
		dtm.addColumn("takeoffTime");
		dtm.addColumn("flyingTime");
		dtm.addColumn("startPlace");
		dtm.addColumn("endPlace");
		dtm.addColumn("tickets");
		dtm.addColumn("price");
		
//		遍历集合添加每一行数据
		for (int i = 0; i < ft.size(); i++) {
			FlightTable f=ft.get(i);
			Vector v=new Vector();
			v.add(f.getFlightNumber());
			v.add(f.getTakeoffTime());
			v.add(f.getFlyingTime());
			v.add(f.getStartPlace());
			v.add(f.getEndPlace());
			v.add(f.getTickets());
			v.add(f.getPrice());
			dtm.addRow(v);
		}
		
		jt.setModel(dtm);
	}
	public void show(){
		init();
		setStyle();
		addEventHandler();
		jf.pack();
		jf.setBounds(10, 150, 1300, 500);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
	}
	public static void main(String[] args) {
		new AdminFrame().show();
	}
}
