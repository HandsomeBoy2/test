package action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import service.UserService;
import entity.FlightTable;
import exception.DataAccessException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
import factory.ObjectFactory;

public class MyFlightFrame {

		private static JPanel jp;
		private static JTable jt;
		private static JButton  cancelJb, modifyJb;

		public MyFlightFrame() {
			jp=new JPanel();
			jt = new JTable();

			cancelJb = new JButton("退票");
			modifyJb = new JButton("改签");
		}
		
		private void init(){
			JScrollPane jsp=new JScrollPane(jt);			
			jp.add(jsp);
			
			
			jp.add(cancelJb);
			jp.add(modifyJb);
		}
		
		
		
//		查询FlightTable表中所有数据
		private void initData() {
			UserService us=(UserService) ObjectFactory.getObject("UserService");
			try {
				List<FlightTable> ft= us.findAllFlighttable();
				addDataToTable(ft);	
			} catch (FlightTableNotFoundException e) {
				e.printStackTrace();
			} catch (ServiceException e) {
				e.printStackTrace();
			} catch (DataAccessException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
//		//将查询结果显示在表单中
		private  void addDataToTable(List<FlightTable> ft){
			//将查询的数据添加到表格中
			DefaultTableModel dtm=new DefaultTableModel();
//			添加表格的列名
			dtm.addColumn("flightNumber");
			dtm.addColumn("takeoffTime");
			dtm.addColumn("flyingTime");
			dtm.addColumn("startPlace");
			dtm.addColumn("endPlace");
			dtm.addColumn("tickets");
			dtm.addColumn("price");
			
//			遍历集合添加每一行数据
			for (int i = 0; i < ft.size(); i++) {
				FlightTable f=ft.get(i);
				Vector v=new Vector();
				v.add(f.getFlightNumber());
				v.add(f.getTakeoffTime());
				v.add(f.getFlyingTime());
				v.add(f.getStartPlace());
				v.add(f.getEndPlace());
				v.add(f.getTickets());
				v.add(f.getPrice());
				dtm.addRow(v);
			}		
			jt.setModel(dtm);
		}
		
		
		private void addEventHandler(){
			
			cancelJb.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {
		
				}	
			});
			
			modifyJb.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {
		
					
					
				}
			});
		}
		
		public  void show(){
			init();
			addEventHandler();
		}
		
		public JPanel getJPanel(){
			return jp;
		}
}
