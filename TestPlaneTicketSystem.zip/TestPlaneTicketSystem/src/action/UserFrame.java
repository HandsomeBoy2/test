package action;

/**
 * 用户主界面
 * @author xzf
 *
 */


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import entity.User;
import exception.DataAccessException;


public class UserFrame {
	private JFrame jf;
	private JTabbedPane jtp;//选项卡
	private User user;
	
	public UserFrame(User user){
		jf = new JFrame("用户功能界面");
		jtp=new JTabbedPane();
		this.user = user;
	}
	
	private void init(User user){
		
		FlightInformation flightFrame=new FlightInformation(user);
		flightFrame.show();
		
		MyFlightFrame myFlightFrame = new MyFlightFrame();
		myFlightFrame.show();
		
		PersonalInformation personalInformation=new PersonalInformation(user);
		personalInformation.show();
		
		jtp.add("航班查询", flightFrame.getJPanel());
		jtp.add("我的机票",myFlightFrame.getJPanel());
		jtp.add("修改个人信息", personalInformation.getJPanel());
		
		jf.add(jtp);
	}
	
	private void setStyle() {
		
		
	}
	private void addEventHandler() {
		
	}
	
	public void show(){
		init(user);
		setStyle();
		addEventHandler();
		jf.setBounds(400, 150, 500, 650);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
	}
}