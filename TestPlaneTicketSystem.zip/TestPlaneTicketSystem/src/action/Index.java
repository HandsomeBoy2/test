package action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import entity.User;
import exception.DataAccessException;
/**
 * 主界面
 * @author xzf
 *
 */
public class Index {
	private JFrame jf;
	private JTabbedPane jtp; //选项卡

	public Index() {    
		jf = new JFrame("航班预定系统");
		jtp = new JTabbedPane();
	}
	
	
	private void init(){
		UserLogin userLogin = new UserLogin();
		userLogin.show();
		

		AdminLogin adminLogin = new AdminLogin();
		adminLogin.show();
		
		FlightInformation flightInformation = new FlightInformation();
		flightInformation.setJbutton(flightInformation.orderTicketJb);
		flightInformation.show();
		
		jtp.add("用户", userLogin.getJpanel());
		jtp.add("管理员", adminLogin.getJpanel());
		jtp.add("航班信息",flightInformation.getJPanel());
	
		jf.add(jtp);
	}
	
	private void setStyle() {
		
		
	}
	
	private void addEventHandler() {
		
	}
	
	public void show(){
		init();
		setStyle();
		addEventHandler();
		jf.pack();
		jf.setBounds(300, 100, 500,650);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
	}


	public static void main(String[] args) {
		new Index().show();
	}
}
