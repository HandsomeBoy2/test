package action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import service.UserService;

import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;

public class PersonalInfromationRegist implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static JFrame jf;
	
	private static JPanel jp;
	
	private static JTextField idJtf, nameJtf, usernameJtf, passwordJtf,
							genderJtf, phoneNumberJtf, emailJtf, addressJtf;
	
	private static JPasswordField confirmPasswordJpf;
	
	private static JLabel idJl, nameJl, usernameJl, passwordJl,
						genderJl, phoneNumberJl, emailJl, addressJl;
	
	private static JLabel confirmPasswordJl;
	
	private static JButton confirmJb;
	private static JButton cancelJb;
	
	
	public PersonalInfromationRegist() {
		jf = new JFrame("用户注册信息界面");
		jp=new JPanel(null);
		
		idJtf=new JTextField("身份证号码为18位", 20);
		nameJtf=new JTextField("请填入真实姓名", 20);
		usernameJtf=new JTextField("由数字、下划线或字母组成，长度为6—16位", 20);
		passwordJtf=new JTextField("由数字、下划线或字母组成，长度为6—16位", 20);
		genderJtf=new JTextField("填男或女", 20);
		phoneNumberJtf=new JTextField("手机号码为11位",20);
		emailJtf = new JTextField("qq邮箱或者新浪邮箱（可选填）", 20);
		addressJtf=new JTextField("可选填", 20);
		
		confirmPasswordJpf=new JPasswordField(20);
		
		idJl=new JLabel("身份证号：");
		nameJl=new JLabel("姓名：");
		usernameJl=new JLabel("用户名：");
		passwordJl=new JLabel("密码：");
		genderJl=new JLabel("性别：");
		phoneNumberJl=new JLabel("电话号码：");
		emailJl = new JLabel("邮箱地址：");
		addressJl=new JLabel("地址：");
		confirmPasswordJl = new JLabel("确认密码:");
		
		confirmJb=new JButton("确定注册");
		cancelJb= new JButton("取消注册");

	}
	
	private static void init(){
		idJl.setBounds(10, 10, 100, 30);
		nameJl.setBounds(10, 50, 100, 30);			
		usernameJl.setBounds(10, 90, 100, 30);
		passwordJl.setBounds(10, 130, 100, 30);
		confirmPasswordJl.setBounds(10, 170, 100, 30);
		genderJl.setBounds(10, 210, 100, 30);
		phoneNumberJl.setBounds(10, 250, 100, 30);
		emailJl.setBounds(10, 290,100, 30);
		addressJl.setBounds(10, 330, 100, 30);
		
		idJtf.setBounds(100, 10, 200, 30);
		nameJtf.setBounds(100, 50, 200, 30);	
		usernameJtf.setBounds(100, 90, 200, 30);
		passwordJtf.setBounds(100, 130, 200, 30);
		confirmPasswordJpf.setBounds(100, 170, 200, 30);
		genderJtf.setBounds(100, 210, 200, 30);
		phoneNumberJtf.setBounds(100, 250, 200, 30);
		emailJtf.setBounds(100, 290,200, 30);
		addressJtf.setBounds(100, 330, 200, 30);
		confirmJb.setBounds(100, 500, 100, 30);
		cancelJb.setBounds(200, 500, 100, 30);

		jp.add(idJl);
		jp.add(idJtf);
		jp.add(nameJl);
		jp.add(nameJtf);
		jp.add(usernameJl);
		jp.add(usernameJtf);
		jp.add(passwordJl);
		jp.add(passwordJtf);
		jp.add(confirmPasswordJl);
		jp.add(confirmPasswordJpf);
		jp.add(genderJl);
		jp.add(genderJtf);
		jp.add(phoneNumberJl);
		jp.add(phoneNumberJtf);
		jp.add(emailJl);
		jp.add(emailJtf);
		jp.add(addressJl);
		jp.add(addressJtf);	
		
		jp.add(confirmJb);
		jp.add(cancelJb);
		
		jf.add(jp);
	}
	
	private static void addEventHandler(){
		confirmJb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				//验证码验证成功后再验证用户名，密码。
				User user = new User();
				String id = idJtf.getText().trim();
				String name = nameJtf.getText().trim();
				String userName = usernameJtf.getText().trim();
				String password = passwordJtf.getText().trim();
				String confirmPassword = confirmPasswordJpf.getText().trim();
				String gender = genderJtf.getText().trim();
				String phoneNumber = phoneNumberJtf.getText().trim();
				String email = emailJtf.getText().trim();			
				String address = addressJtf.getText().trim();
				String userNameAndPasswordRegex = "[a-zA-Z0-9_]{6,16}";
				String emailRegex = "(\\d|[a-zA-Z]){6,11}@(qq|sina).(com|cn)";
				if(id.length() != 18){
					JOptionPane.showMessageDialog(jp, "身份证号是18位！");
					return;	
				}else if(name.equals("")){
					JOptionPane.showMessageDialog(jp, "姓名不可以是空！");
					return;		
				} else if(!userName.matches(userNameAndPasswordRegex) || !(password.matches(userNameAndPasswordRegex))){
					JOptionPane.showMessageDialog(jp, "用户名与密码都是由6-16数字、字母、下划线组成");
					return;					
				} else if (!password.equals(confirmPassword)){
					JOptionPane.showMessageDialog(jp, "两次密码不一致");
					return;
				}else if (phoneNumber.length() != 11){
						JOptionPane.showMessageDialog(jp, "手机号错误！应由11位数字组成");
						return;
				}  else if(!email.matches(emailRegex)){
					JOptionPane.showMessageDialog(jp, "邮箱不匹配");
					return;					
				} else{
					user.setId(id);
					user.setName(name);
					user.setUserName(userName);
					user.setPassword(password);
					user.setGender(gender);
					user.setPhoneNumber(phoneNumber);
					user.setEmail(email);
					if(!address.equals("")){
						user.setAddress(address);
					}else {
						user.setAddress(" ");
					}
						
					UserService us = (UserService) ObjectFactory.getObject("UserService");
					try {
						try {
							us.regist(user);
						} catch (UserNotFoundException e1) {
							e1.printStackTrace();
						}
					} catch (DuplicateUsernameException e1) {
						e1.printStackTrace();
					} catch (ServiceException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					} catch (DataAccessException e1) {
						e1.printStackTrace();
					}			
					jf.setVisible(false);
					new Index().show();
				}
			}
		});
		
		
		cancelJb.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				new Index().show();
			}
			
		});
		
	}
	public void show(){
		init();
		addEventHandler();
		jf.setBounds(300, 100, 500,650);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
	}
}
