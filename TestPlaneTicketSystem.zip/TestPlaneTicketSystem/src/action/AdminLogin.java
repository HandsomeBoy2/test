package action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import service.AdminService;
import entity.Admin;
import exception.AdminNotFoundException;
import exception.DataAccessException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;
/**
 * 用户登录注册窗口
 * @author xzf
 *
 */
public class AdminLogin {
	private static JPanel jp;
	private JLabel titleJl, userNameJl, passwordJl;
	private JTextField userNameJtf;
	private JPasswordField passwordJpf;
	private JButton loginButton;
	
	public AdminLogin(){
		jp = new JPanel(null);
		titleJl = new JLabel("管理员登录界面");
		userNameJl = new JLabel("用户名:");
		passwordJl = new JLabel("密码:");
		userNameJtf = new JTextField(20);
		passwordJpf = new JPasswordField(20);
		loginButton=new JButton("登录");
		
	}
	
	public void init(){
		
		jp.add(titleJl);
		titleJl.setBounds(200,  50,  200, 50);
		
		userNameJl.setBounds(50,  110,  70, 30);
		jp.add(userNameJl);
		userNameJtf.setBounds(100, 110, 200 , 30);
		jp.add(userNameJtf);
		
		passwordJl.setBounds(50,  180,  70, 30);
		jp.add(passwordJl);
		passwordJpf.setBounds(100, 180, 200, 30 );
		jp.add(passwordJpf);

		loginButton.setBounds(150, 450, 100, 20);
		jp.add(loginButton);
		
	}
	
	public void setStyle(){
	
	}
	public void addEventHandler(){
		
		//登录键的监听事件
		loginButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				//验证码验证成功后再验证用户名，密码。
				String userName = userNameJtf.getText();
				String password = passwordJpf.getText();
				String regex = "[a-zA-Z0-9_]{6,16}";
				Admin admin = null;
				if(!userName.matches(regex) || !(password.matches(regex))){
					JOptionPane.showMessageDialog(jp, "用户名与密码都是由6-16数字、字母、下划线组成");
					return;
					
				} else{
					
					AdminService as = (AdminService) ObjectFactory.getObject("AdminService");
					try {
						try {
							admin= as.login(userName, password);
						} catch (AdminNotFoundException e1) {
							e1.printStackTrace();
						}
						if (admin != null){
							//登成功之后隐藏之前的窗口，并且显示出用户主界面
							JOptionPane.getFrameForComponent(jp).dispose();
							new AdminFrame().show();		
						}
					} catch (UserNotFoundException e1) {
						JOptionPane.showMessageDialog(jp, "该用户不存在");
						e1.printStackTrace();
					} catch (ServiceException e1) {
						e1.printStackTrace();
					} catch (DataAccessException e1) {		
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}					
		});
		
	}
	public void show(){
		init();
		setStyle();
		addEventHandler();
	} 
	public static JPanel getJpanel(){
		return jp;
	}
}

	
