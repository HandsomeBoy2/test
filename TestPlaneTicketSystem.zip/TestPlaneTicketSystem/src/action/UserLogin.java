package action;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import service.UserService;

import entity.User;
import exception.DataAccessException;
import exception.ServiceException;
import exception.UserNotFoundException;
import factory.ObjectFactory;
/**
 * 用户登录注册窗口
 * @author xzf
 *
 */
public class UserLogin {
	private static JPanel jp;
	private JLabel  titleJl, userNameJl, passwordJl, verificationCodeJl;
	private JTextField userNameJtf;
	private JPasswordField passwordJpf;
	private JButton registButton, loginButton;
	
	//验证码
	private String codeValue;//用于调用getCode时生成的随机验证码的保存变量
	private JLabel jl,jlImage;
	private JTextField jtf;
	private JButton changeJb;
	
	
	public UserLogin(){
		jp = new JPanel(null);
		titleJl = new JLabel("登录注册界面");
		userNameJl = new JLabel("用户名:");
		passwordJl = new JLabel("密码:");
		
		//验证码
		jl=new JLabel("验证码：");
		jlImage=new JLabel();
		jtf=new JTextField(10);
		changeJb = new JButton("换一换");
		
		userNameJtf = new JTextField(20);
		passwordJpf = new JPasswordField(20);
		registButton=new JButton("注册");
		loginButton=new JButton("登录");
		
	}
	
	public void init(){
		
		titleJl.setBounds(200,  50,  200, 50);
		jp.add(titleJl);
		
		userNameJl.setBounds(10,  110,  70, 30);
		jp.add(userNameJl);
		userNameJtf.setBounds(100, 110, 200 ,  30);
		jp.add(userNameJtf);
		
		passwordJl.setBounds(10,  190,  70, 30);
		jp.add(passwordJl);
		passwordJpf.setBounds(100, 190, 200, 30 );
		jp.add(passwordJpf);
		
		//关于验证码
		jl.setBounds(10,  270,  70, 30);
		jp.add(jl);
		//通过getCode方法返回验证码的Icon对象放入JLabel
		jlImage.setIcon(getCode());
		jlImage.setBounds(100, 310, 300, 100);
		jp.add(jlImage);
		changeJb.setBounds(220, 275, 80, 20);
		jp.add(changeJb);
		jtf.setBounds(100, 270, 100, 30);
		jp.add(jtf);
		
		
		registButton.setBounds(100, 450, 100 , 20 );
		jp.add(registButton);
		
		loginButton.setBounds(300, 450, 100, 20);
		jp.add(loginButton);
		
	}
	
	public void setStyle(){
	
	}
	public void addEventHandler(){
		
		//注册键的监听事件
		registButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				//隐藏之前的窗口
				JOptionPane.getFrameForComponent(jp).dispose();
				//出现之前的窗口
				new PersonalInfromationRegist().show();
			}		
		});	
		
		//登录键的监听事件
		loginButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				//首先对验证码进行验证，如果验证不成功就弹出窗口重新输入；					
				//验证码验证成功后再验证用户名，密码。
				String userName = userNameJtf.getText();
				String password = passwordJpf.getText();
				String regex = "[a-zA-Z0-9_]{6,16}";
				User user = null;
				if(!codeValue.equals(jtf.getText().trim())){
					JOptionPane.showMessageDialog(jp, "验证码不正确，请重新输入");
					return ;
				} else if(!userName.matches(regex) || !(password.matches(regex))){
					JOptionPane.showMessageDialog(jp, "用户名与密码都是由6-16数字、字母、下划线组成");
					return;
				} else{
					UserService us = (UserService) ObjectFactory.getObject("UserService");
					try {
						user = us.login(userName, password);
						//登成功之后隐藏之前的窗口，并且显示出用户主界面
						if (user != null){
							JOptionPane.getFrameForComponent(jp).dispose();
							new UserFrame(user).show();			
						}
					} catch (UserNotFoundException e1) {
						JOptionPane.showMessageDialog(jp, "该用户不存在");
						return;
					} catch (ServiceException e1) {
						e1.printStackTrace();
					} catch (DataAccessException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}			
		});		
		
		//换一换按钮
		changeJb.addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent e) {
		//更新验证码
				jlImage.setIcon(getCode());
			}
		});
	}
	
	//验证码
	private Icon getCode(){
		//随机数对象
		Random r=new Random();
		//创建画板
		BufferedImage image=new BufferedImage(280, 120, BufferedImage.TYPE_INT_RGB);
		//获得画笔
		Graphics g=image.getGraphics();
		//设置画笔随机颜色
		g.setColor(new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256)));//0-255
		//填充矩形
		g.fillRect(0, 0, 280, 120);
		//重新设置画笔随机颜色
		g.setColor(new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256)));
		g.setFont(new Font("宋体", Font.BOLD, 50));
		String str="qazxswedcvfrtgbnhyujmkiolp0123456789";
		//根据str字符串随机取出五个拼成一个字符串方放入以下方法中
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<5;i++){
			sb.append(str.charAt(r.nextInt(str.length())));
		}
		codeValue=sb.toString();
		//添加文字
		g.drawString(codeValue, 80, 80);
		//增加干扰圆点
		for(int i=0;i<20;i++){
			g.setColor(new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256)));
			g.fillOval(r.nextInt(281), r.nextInt(121), 15, 15);
		}
		Icon ic=new ImageIcon(image);
		return ic;
	}
	public void show(){
		init();
		setStyle();
		addEventHandler();
	} 
	
	public static JPanel getJpanel(){
		return jp;
	}
}

	