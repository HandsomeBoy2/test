package rowmapper;

import java.io.Serializable;
import java.sql.ResultSet;

import entity.User;

import util.RowMapper;
/**
 * 用户表行映射结果集的返回
 * @author xzf
 *
 */
public class UserRowMapper implements RowMapper, Serializable{

	public Object getMapRow(ResultSet rs) throws Exception {
		User u = new User();
		u.setId(rs.getString("id"));
		u.setName(rs.getString("name"));
		u.setUserName(rs.getString("userName"));
		u.setPassword(rs.getString("password"));
		u.setGender(rs.getString("gender"));
		u.setPhoneNumber(rs.getString("phoneNumber"));
		u.setEmail(rs.getString("email"));
		u.setAddress(rs.getString("address"));
		return u;
	}

}
