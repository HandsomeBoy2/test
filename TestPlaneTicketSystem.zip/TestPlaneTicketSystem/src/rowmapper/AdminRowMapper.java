package rowmapper;

import java.sql.ResultSet;

import entity.Admin;

import util.RowMapper;
/**
 * 管理员用户表行映射结果集的返回
 * @author xzf
 *
 */
public class AdminRowMapper implements RowMapper{

	public Object getMapRow(ResultSet rs) throws Exception {
		Admin ad = new Admin();
		ad.setId(rs.getString("id"));
		ad.setName(rs.getString("userName"));
		ad.setPassword(rs.getString("password"));
		ad.setPhoneNumber(rs.getString("name"));
		ad.setUserName(rs.getString("phoneNumber"));
		return ad;
	}

}
