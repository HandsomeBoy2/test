package rowmapper;

import java.sql.ResultSet;
import entity.PurchaseTicketInformation;
import util.RowMapper;
/**
 *购票表表行映射结果集的返回
 * @author xzf
 *
 */
public class PurchaseTicketInformationRowMapper implements RowMapper{

	public Object getMapRow(ResultSet rs) throws Exception {
		PurchaseTicketInformation pti = new PurchaseTicketInformation();
		pti.setOrderNumber(rs.getInt("orderNumber"));
		pti.setFlightNumber(rs.getString("flightNumber"));
		pti.setUserId(rs.getString("userId"));
		return pti;
	}
	
}
