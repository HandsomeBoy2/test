package rowmapper;

import java.sql.ResultSet;

import entity.FlightTable;

import util.RowMapper;
/**
 * 航班表行映射结果集的返回
 * @author xzf
 *
 */
public class FlightTableRowMapper implements RowMapper{

	public Object getMapRow(ResultSet rs) throws Exception {
		FlightTable ft = new FlightTable();
		ft.setFlightNumber(rs.getString("flightNumber"));
		ft.setTakeoffTime(rs.getString("takeoffTime"));
		ft.setFlyingTime(rs.getString("flyingTime"));
		ft.setStartPlace(rs.getString("startPlace"));
		ft.setEndPlace(rs.getString("endPlace"));
		ft.setTickets(rs.getInt("tickets"));
		ft.setPrice(rs.getInt("price"));
		return ft;
	}

}
