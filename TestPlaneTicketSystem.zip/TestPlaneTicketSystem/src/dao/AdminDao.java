package dao;

import java.util.List;

import entity.Admin;
import entity.FlightTable;
import exception.AdminNotFoundException;
import exception.DataAccessException;
import exception.DuplicateFlightTableException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;
/**
 *  Admin接口类
 * @author xzf
 *
 */
public interface AdminDao {
	/**
	 * 根据管理员用户名和密码登录
	 * @param userName
	 * @param password
	 * @return
	 * @throws DataAccessException
	 */
	public abstract Admin selectAdminByUsernameAndPassword(String userName, String password) 
				throws DataAccessException, ServiceException, AdminNotFoundException;
	
	
	/**
	 * 根据出发地.目的地.日期查询
	 * @param startPlace
	 * @param endPlace
	 * @param date
	 * @return FlightTable
	 * @throws DataAccessException
	 */
	public abstract List<FlightTable> selectFlighttableByStartPlaceAndEndPlaceAndDate(String startPlace, String endPlace, String date)
						throws DataAccessException, ServiceException, FlightTableNotFoundException;
	
	/**
	 * 根据航班号查询
	 * @param FlightNumber
	 * @return FlightTable
	 * @throws DataAccessException
	 */
	public abstract List<FlightTable> selectFlighttableByFlightNumber(String FlightNumber)
					throws DataAccessException, ServiceException, FlightTableNotFoundException;
	
	/**
	 * 删除航班
	 * @param ft
	 * @throws DataAccessException
	 */
	public abstract void deleteFlighttable(FlightTable ft) 
						throws DataAccessException, ServiceException, FlightTableNotFoundException;
	/**
	 * 修改航班
	 * @param ft
	 * @throws DataAccessException
	 */
	public abstract void modifyFlighttable(FlightTable  ft)
			throws DataAccessException, ServiceException, FlightTableNotFoundException;
	/**
	 * 添加航班
	 * @param ft
	 * @throws DataAccessException
	 */
	public abstract void addFlighttable(FlightTable ft) 
			throws DataAccessException, ServiceException, DuplicateFlightTableException, FlightTableNotFoundException;

	
}
