package dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import rowmapper.FlightTableRowMapper;
import rowmapper.UserRowMapper;
import util.JDBCTemplate;
import dao.UserDao;
import entity.FlightTable;
import entity.PurchaseTicketInformation;
import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.FlightTableNotFoundException;
import exception.PurchaseTicketInformationNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;

public class UserDaoImpl implements UserDao, Serializable{
	
	private static final long serialVersionUID = 1L;
	private JDBCTemplate jt;
	public UserDaoImpl(){
		jt = new JDBCTemplate();
	}
	
	/**
	 *  根据订单号给用户退票
	 */
	public void deleteTicket(int orderNumber) throws DataAccessException,
			ServiceException, FlightTableNotFoundException,
			PurchaseTicketInformationNotFoundException {
	 	String sql = new StringBuffer()
									.append("delete * from PurchaseTicketInformation ")
									.append("where orderNumber = ? ")
									.toString();
		Object[] object = {orderNumber};
		jt.update(sql,  object);	
	}
	
	/**
	 * 添加新用户信息
	 */
	public void insert(User user) throws DataAccessException, ServiceException,
			DuplicateUsernameException {	
		String sql = new StringBuffer()
								.append("insert into user ")
								.append("values(?, ?, ?, ?, ?, ?, ?, ?) ")
								.toString();
		Object [] object = { user.getId(), user.getName(),
		user.getUserName(), user.getPassword(), user.getGender(), user.getPhoneNumber(),
		user.getEmail(), user.getAddress()};
		jt.update(sql,object);		
	}
	
	/**
	 * 用户改签
	 */
	public void modifyTicket(User user, FlightTable ft, int orderNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException,
			PurchaseTicketInformationNotFoundException {
		String sql = new StringBuffer()
								.append("update user ")
								.append("set  userId = ?, ")
								.append("set name = ?, ")
								.append("flightNumber = ?, ")
								.append("startPlace = ?, ")
								.append("endPlace = ?, ")
								.append("takeoffTime = ?, ")
								.append("price = ? ")
								.append("where orderNumber = orderNumber ")
								.toString();
		Object [] object = { user.getId(), user.getName(), ft.getFlightNumber(),
											ft.getStartPlace(), ft.getEndPlace(), ft.getTakeoffTime(),
												ft.getPrice()};
		jt.update(sql,object);		
	}
	/**
	 * 用户订票
	 */
	public void orderTicket(User user, FlightTable ft)
			throws DataAccessException, ServiceException,
			UserNotFoundException, FlightTableNotFoundException {
		String sql = new StringBuffer()
									.append("insert into purchaseTicketInformation ")
									.append("(orderNumber, flightNumber, id)values (?, ?, ?) ")
									.toString();
		int orderNumber = PurchaseTicketInformation.orderNumber;
		PurchaseTicketInformation.orderNumber = orderNumber++;
		Object [] object = {PurchaseTicketInformation.orderNumber, ft.getFlightNumber(), user.getId()};
		jt.update(sql,object);	
	}
	/**
	 * 根据航班号查询
	 */
	public FlightTable selectFlighttableByFlightNumber(String FlightNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		String sql = new StringBuffer()
								.append("select * from Flighttable ")
								.append("where flightnumber = ? ")
								.toString();
		Object[] object = {FlightNumber};
		List <FlightTable> fts = jt.query(sql, new FlightTableRowMapper(), object);	
		return fts.size()==0?null:fts.get(0);
	}
	/**
	 * 根据出发地.目的地.日期查询
	 */
	public FlightTable selectFlighttableByStartPlaceAndEndPlaceAndDate(
			String startPlace, String endPlace, String date)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		String sql = new StringBuffer()
									.append("select * from Flighttable ")
									.append("where startPlace = ? and endPlace = ?  and date = ? ")
									.toString();
		Object[] object = {startPlace, endPlace, date};
		List <FlightTable> fts = jt.query(sql, new FlightTableRowMapper(), object);	
		return fts.size()==0?null:fts.get(0);
	}
	
	/**
	 * 根据用户名查询用户信息确定是否重复
	 */
	public User selectUserByUsername(String userName)
			throws DataAccessException, ServiceException, UserNotFoundException {
				String sql = new StringBuffer()
											.append("select * from user ")
											.append("where userName = ? ")
											.toString();
				Object[] object = {userName};
				List <User>users = jt.query(sql, new UserRowMapper(), object);	
				return users.size()==0?null:users.get(0);
	}
	
	/**
	 * 根据用户名密码查询用户信息
	 */
	public User selectUserByUsernameAndPassword(String userName, String password)
			throws DataAccessException, ServiceException, UserNotFoundException {
		String sql = new StringBuffer()
											.append("select * from user ")
											.append("where userName = ? and password = ?")
											.toString();
		Object[] object = {userName, password};
		List <User>users = jt.query(sql, new UserRowMapper(), object);	
		return users.size()==0?null:users.get(0);
	}
	/**
	 * 修改用户信息
	 */
	public void update(User user) throws DataAccessException, ServiceException,
			DuplicateUsernameException {

		String sql = new StringBuffer()
								.append("update user ")
								.append("set name = ?, ")
								.append("userName = ?,  ")
								.append("password = ?, ")
								.append("gender = ?, ")
								.append("phoneNumber = ?, ")
								.append("email = ?, ")
								.append("address = ? ")
								.append("where id =  " + user.getId())
								.toString();
	Object[] object = {user.getName(), user.getUserName(), user.getPassword(), user.getGender(), user.getPhoneNumber(),
									user.getEmail(), user.getAddress()};
	 jt.update(sql,  object);		
	}

	public List<FlightTable> selectAllFlighttable() throws DataAccessException,
			ServiceException, FlightTableNotFoundException {
		String sql = new StringBuffer()
										.append("select * from flightTable ")
										.toString();	
		List <FlightTable>ft = jt.query(sql, new FlightTableRowMapper());	
		return ft.size()==0?null:ft;
	}

}
