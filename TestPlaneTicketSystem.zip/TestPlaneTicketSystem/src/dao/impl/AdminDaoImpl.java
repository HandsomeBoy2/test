package dao.impl;

import java.util.List;

import rowmapper.AdminRowMapper;
import rowmapper.FlightTableRowMapper;
import util.JDBCTemplate;
import dao.AdminDao;
import entity.Admin;
import entity.FlightTable;
import exception.AdminNotFoundException;
import exception.DataAccessException;
import exception.DuplicateFlightTableException;
import exception.FlightTableNotFoundException;
import exception.ServiceException;

public class AdminDaoImpl implements AdminDao{
	private JDBCTemplate jt;
	public AdminDaoImpl(){
		jt = new JDBCTemplate();
	}
	/**
	 *  添加航班
	 */
	public void addFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, DuplicateFlightTableException,
			FlightTableNotFoundException {
		String sql = new StringBuffer()
									.append("insert into flightTable ")
									.append("values (?, ?, ?, ?, ?, ?, ? ) ")
									.toString();
			Object[] object = {ft.getFlightNumber(), ft.getTakeoffTime(), ft.getFlyingTime(), ft.getStartPlace(), ft.getEndPlace(), ft.getTickets(), ft.getPrice()};
			 jt.update(sql, object);	
	}
	/**
	 *  删除航班
	 */
	public void deleteFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, FlightTableNotFoundException {
		String sql = new StringBuffer()
								.append("delete from  flightTable ")
								.append("where  flightnumber = ? ")
								.toString();
		Object[] object = {ft.getFlightNumber()};
		jt.update(sql, object);	
		
	}
	/**
	 * 修改航班
	 */
	public void modifyFlighttable(FlightTable ft) throws DataAccessException,
			ServiceException, FlightTableNotFoundException {
		String sql = new StringBuffer()
								.append("update  flightTable ")
								.append("set  takeofftime= ?, ")
								.append("flyingtime= ?, ")
								.append("startplace= ?, ")
								.append("endplace= ?, ")
								.append("tickets= ?, ")
								.append("price= ? ")
								.append("where flightnumber = ?")
								.toString();
			Object[] object = {ft.getTakeoffTime(), ft.getFlyingTime(),
											ft.getStartPlace(), ft.getEndPlace(), ft.getTickets(),
												ft.getPrice(), ft.getFlightNumber()};
			jt.update(sql, object);	
		
	}
	/**
	 *  根据管理员用户名和密码登录
	 */
	public Admin selectAdminByUsernameAndPassword(String userName,
			String password) throws DataAccessException, ServiceException,
			AdminNotFoundException {
			String sql = new StringBuffer()
			.append("select * from admin ")
			.append("where userName = ? and password = ?")
			.toString();
			Object[] object = {userName, password};
			List <Admin>Admins = jt.query(sql, new AdminRowMapper(), object);	
			return Admins.size()==0?null:Admins.get(0);
	}
	/**
	 * 根据航班号查询
	 */
	public List<FlightTable> selectFlighttableByFlightNumber(String FlightNumber)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		String sql = new StringBuffer()
										.append("select * from flightTable ")
										.append("where flightnumber = ? ")
										.toString();
			Object[] object = {FlightNumber};
			List <FlightTable> fts = jt.query(sql, new FlightTableRowMapper(), object);	
			return fts.size()==0?null:fts;
	}
	/**
	 * 根据出发地.目的地.日期查询
	 */
	public List<FlightTable> selectFlighttableByStartPlaceAndEndPlaceAndDate(
			String startPlace, String endPlace, String date)
			throws DataAccessException, ServiceException,
			FlightTableNotFoundException {
		String sql = new StringBuffer()
								.append("select * from flightTable ")
								.append("where startPlace = ? and endPlace = ?  and takeoffTime = ? ")
								.toString();
		Object[] object = {startPlace, endPlace, date};
		List <FlightTable> fts = jt.query(sql, new FlightTableRowMapper(), object);	
		return fts.size()==0?null:fts;
	}
	
	
	
}
