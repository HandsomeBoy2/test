package dao;

import java.util.List;

import entity.FlightTable;
import entity.User;
import exception.DataAccessException;
import exception.DuplicateUsernameException;
import exception.FlightTableNotFoundException;
import exception.PurchaseTicketInformationNotFoundException;
import exception.ServiceException;
import exception.UserNotFoundException;

/**
 * UserDao接口类
 * @author xzf
 *
 */
public interface UserDao {
	/**
	 * 根据用户名密码查询用户信息
	 * @param userName
	 * @param password
	 * @return User
	 * @throws DataAccessException
	 */
	public abstract User selectUserByUsernameAndPassword(String userName, String password) 
								throws DataAccessException, ServiceException, UserNotFoundException;
	
	/**
	 * 添加新用户信息
	 * @param user
	 * @return User
	 * @throws DataAccessException
	 */
	public abstract void insert(User user) 
							throws DataAccessException, ServiceException, DuplicateUsernameException;

	/**
	 * 根据用户名确定是否重复
	 * @param userName
	 * @return  User
	 * @throws DataAccessException
	 */
	public abstract User selectUserByUsername(String userName) 
			throws DataAccessException, ServiceException, UserNotFoundException;
	
	/**
	 * 修改用户信息
	 * @param user
	 * @throws DataAccessException
	 */
	public abstract void update(User user)
			throws DataAccessException, ServiceException, DuplicateUsernameException;
	
	/**
	 * 根据出发地.目的地.日期查询
	 * @param startPlace
	 * @param endPlace
	 * @param date
	 * @return FlightTable
	 * @throws DataAccessException
	 */
	public abstract FlightTable selectFlighttableByStartPlaceAndEndPlaceAndDate(String startPlace, String endPlace, String date)
						throws DataAccessException, ServiceException, FlightTableNotFoundException;
	
	/**
	 * 根据航班号查询
	 * @param FlightNumber
	 * @return FlightTable
	 * @throws DataAccessException
	 */
	
	public abstract FlightTable selectFlighttableByFlightNumber(String FlightNumber)
				throws DataAccessException, ServiceException, FlightTableNotFoundException;
	
	
	/**
	 * 查询所有航班信息
	 * @return  List
	 * @throws DataAccessException
	 * @throws ServiceException
	 * @throws FlightTableNotFoundException
	 */
	public abstract List<FlightTable> selectAllFlighttable()
				throws DataAccessException, ServiceException, FlightTableNotFoundException;
	
	/**
	 * 用户订票
	 * @param user
	 * @param ft
	 * @throws DataAccessException
	 */
	public abstract void orderTicket(User user, FlightTable ft) 
			throws DataAccessException, ServiceException, UserNotFoundException, FlightTableNotFoundException;
	
	/**
	 *用户改签
	 * @param user
	 * @param ft
	 * @throws DataAccessException
	 */
	public abstract void modifyTicket(User user, FlightTable ft, int orderNumber) 
		throws DataAccessException, ServiceException, FlightTableNotFoundException, PurchaseTicketInformationNotFoundException;
	
	/**
	 * 根据订单号给用户退票
	 * @param orderNumber
	 * @throws DataAccessException
	 */
	public abstract void deleteTicket(int orderNumber) 
		throws DataAccessException, ServiceException, FlightTableNotFoundException, PurchaseTicketInformationNotFoundException;
	
}
