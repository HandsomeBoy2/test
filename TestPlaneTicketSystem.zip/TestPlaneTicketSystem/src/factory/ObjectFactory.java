package factory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;


public class ObjectFactory {
	static Map<String, Object> map = new HashMap<String, Object>();
	static {
		BufferedReader br = null; 							
		try {
			br = new BufferedReader(new InputStreamReader(
					ObjectFactory.class.getClassLoader().
					getResourceAsStream("objects.txt")));	
			String s = null;
			while((s = br.readLine())!=null){
				String arr[] = s.split("=");
				map.put(arr[0], Class.forName(arr[1]).newInstance());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ExceptionInInitializerError("ObjectFacotry初始化错误");
		}
	}
	
	public static Object getObject(String key){
		return map.get(key);
	}
}
