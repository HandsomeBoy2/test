package util;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import exception.DataAccessException;

/**
 * JDBC模版工具类
 * @author ljd
 */
public class JDBCTemplate implements Serializable{
	/**
	 * 新增、修改、删除通用模版方法
	 * @param sql 预编译sql语句
	 * @param params 针对于sql所需要的数据
	 * @throws DataAccessException 
	 */
	public void update(String sql,Object [] params) throws DataAccessException{
		//insert delete update
		Connection con=null;
		PreparedStatement ps=null;
		try {
			//通过工具类获得连接对象
			con=JDBCUtil.getConnection();
			ps=con.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				ps.setObject(i+1, params[i]);
			}
			//执行sql语句
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAccessException("数据库访问失败");
		} finally{
			JDBCUtil.close(null, ps, null);
		}
		
	}
	
	/**
	 * 查询通用模版方法
	 * @param sql 预编译sql语句
	 * @param rm 具体根据所需要返回的对象传入对应的行映射实现类对象
	 * @param params 针对于sql所需要的数据 
	 * @return
	 * @throws DataAccessException 
	 */
	public List query(String sql,RowMapper rm,Object [] params) throws DataAccessException{
		// select
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List <Object>list=new ArrayList<Object>();
		try {
			con=JDBCUtil.getConnection();
			ps=con.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
//				params(ps, params[i], i+1);
				ps.setObject(i+1, params[i]);
			}
			rs=ps.executeQuery();
			while(rs.next()){
				//接收结果集返回的每一行数据
				Object o=rm.getMapRow(rs);
				list.add(o);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAccessException("数据库访问失败");
		} finally{
			JDBCUtil.close(null, ps, rs);
		}
		
		return list;
	}
	
	//查询
	public List query(String sql,RowMapper rm) throws DataAccessException{
		// select
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List <Object>list=new ArrayList<Object>();
		try {
			con=JDBCUtil.getConnection();
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next()){
				//接收结果集返回的每一行数据
				Object o=rm.getMapRow(rs);
				list.add(o);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAccessException("数据库访问失败");
		} finally{
			JDBCUtil.close(null, ps, rs);
		}	
		return list;
	}
	

}
