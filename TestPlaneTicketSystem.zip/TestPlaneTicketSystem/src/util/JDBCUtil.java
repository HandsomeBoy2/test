package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;
/**
 * JDBC工具类
 * @author xzf
 *
 */
public class JDBCUtil {
	//用于存放一个线程中的Connection对象
	private static ThreadLocal <Connection>tl;
	private static DataSource ds;
	static {
		tl = new ThreadLocal<Connection>();
		try {
			// 获得Properties对象用于加载datasource.properties配置文件
			Properties p = new Properties();
			// 通过当前类的加载器读取类加载路径下的datasource.properties配置文件
			p.load(JDBCUtil.class.getClassLoader().getResourceAsStream(
					"datasource.properties"));
			// 通过数据源工厂解析配置文件获得数据源
			ds = BasicDataSourceFactory.createDataSource(p);

		} catch (Exception e) {
				e.printStackTrace();
				throw new ExceptionInInitializerError("JDBC初始化错误");
		}		
	}

	/**
	 * 得到Connection对象
	 * @return Connection
	 * @throws SQLException 
	 */
	//一个业务一个连接  一个事务一个连接  一个线程一个连接
	public static Connection getConnection () throws SQLException{
		Connection con = (Connection) tl.get();
		if(con == null){
			try {
				con = ds.getConnection();
				tl.set(con);
			} catch (SQLException e) {
				e.printStackTrace();
				throw e;
			}
		}
		return con;
	}
	/**
	 * 对数据库进行关闭
	 * @param con
	 * @param ps
	 * @param rs
	 */
	public static void close(Connection con, PreparedStatement ps, ResultSet rs){
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(ps != null){
			try {
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void close(){
		Connection con = tl.get();
		if(con != null){
			try {
				con.close();
				tl.remove();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}
