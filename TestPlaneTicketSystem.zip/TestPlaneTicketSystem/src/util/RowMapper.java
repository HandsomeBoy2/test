package util;

import java.sql.ResultSet;

/**
 * 行映射接口类
 * @author xzf
 *
 */

public interface RowMapper {
	/**
	 * 
	 * @return Object 行映射通用Object类型
	 */
	public abstract Object getMapRow(ResultSet rs) throws Exception;
}
