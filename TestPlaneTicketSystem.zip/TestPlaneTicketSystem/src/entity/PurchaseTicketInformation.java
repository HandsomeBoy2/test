package entity;

import java.io.Serializable;
/**
 * 购票信息实体类
 * @author xzf
 *
 */
public class PurchaseTicketInformation implements Serializable{
	/**
	 * 序列号
	 */
	private static final long serialVersionUID = 1L;
	public static int orderNumber = 0;
	private String flightNumber;
	private String userId;
	public static int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
