package entity;

import java.io.Serializable;

/**
 * 航班信息实体类
 * @author xzf
 *
 */
public class FlightTable implements Serializable{
	/**
	 * 序列号
	 */
	private static final long serialVersionUID = 1L;
	private String flightNumber;
	private String takeoffTime;
	private String  flyingTime;
	private String startPlace;
	private String endPlace;
	private int tickets;
	private float price;
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getTakeoffTime() {
		return takeoffTime;
	}
	public void setTakeoffTime(String takeoffTime) {
		this.takeoffTime = takeoffTime;
	}
	public String getFlyingTime() {
		return flyingTime;
	}
	public void setFlyingTime(String flyingTime) {
		this.flyingTime = flyingTime;
	}
	public String getStartPlace() {
		return startPlace;
	}
	public void setStartPlace(String startPlace) {
		this.startPlace = startPlace;
	}
	public String getEndPlace() {
		return endPlace;
	}
	public void setEndPlace(String endPlace) {
		this.endPlace = endPlace;
	}
	public int getTickets() {
		return tickets;
	}
	public void setTickets(int tickets) {
		this.tickets = tickets;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
}
