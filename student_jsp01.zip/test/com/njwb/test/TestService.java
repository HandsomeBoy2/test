package com.njwb.test;

import service.UserService;

public class TestService {

	public static void main(String[] args) throws Exception {
		//LoginService loginService = (LoginService) ObjectFactory.getObject("loginService");
		//空指针异常，1）找到异常的具体代码  2）确定为空的对象！！  3）对象的赋值在哪里？
		//引起空指针两个必要的条件
		//1.对象为null    2.使用了这个对象， 对象.方法（）
		//List list = null;
		//list.size(); --->空指针
		//System.out.println(loginService.login("admin", "admin"));
	}
}
