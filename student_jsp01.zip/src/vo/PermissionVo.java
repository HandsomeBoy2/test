package vo;

import entity.Menu;
import entity.Permission;
import entity.Role;

public class PermissionVo {
	private Menu menu;
	private Role role;
	private Permission permission;
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public Permission getPermission() {
		return permission;
	}
	public void setPermission(Permission permission) {
		this.permission = permission;
	}
	@Override
	public String toString() {
		return "PermissionVo [menu=" + menu + ", role=" + role
				+ ", permission=" + permission + "]";
	}
	
	
}
