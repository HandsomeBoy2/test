package vo;

import entity.Emp;
import entity.User;
/**
 * 账户视图类 做账户页面展示用
 * @author soft01
 *
 */
public class UserVo {
	private User user;
	private Emp emp;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Emp getEmp() {
		return emp;
	}
	public void setEmp(Emp emp) {
		this.emp = emp;
	}
	@Override
	public String toString() {
		return "UserVo [emp=" + emp + ", user=" + user + "]";
	}
	
	
}
