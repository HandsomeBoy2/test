package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Emp;
import entity.User;

import util.RowMapper;
import vo.UserVo;

/**
 *  t_user表和t_employee表行映射结果集返回
 * @author xzf
 *
 */
public class UserVoRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		UserVo userVo = new UserVo();
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setEmpNo(rs.getString("t_emp_no"));
		user.setUserAccount(rs.getString("t_user_account"));
		user.setUserPwd(rs.getString("t_user_pwd"));
		user.setRoleId(rs.getInt("t_role_id"));
		user.setUserStatus(rs.getString("t_user_status"));
		userVo.setUser(user);
		Emp emp = new Emp();
		emp.setEmpName(rs.getString("t_emp_name"));
		userVo.setEmp(emp);
		return userVo;
	}

}
