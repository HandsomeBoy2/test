package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Expense;

import util.RowMapper;

/**
 *  t_expense报销表行映射结果集返回
 * @author xzf
 *
 */
public class ExpenseRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		Expense expense = new Expense();
		expense.setId(rs.getInt("id"));
		expense.setExpenseNo(rs.getInt("t_exp_no"));
		expense.setExpenseName(rs.getString("t_emp_name"));
		expense.setExpenseType(rs.getString("t_exp_type"));
		expense.setExpenseMoney(rs.getDouble("t_exp_money"));
		expense.setExpenseDate(rs.getString("t_exp_Date"));
		expense.setExpenseStatus(rs.getString("t_exp_status"));
		expense.setExpenseDigest(rs.getString("t_exp_digest"));
		expense.setCreateTime(rs.getString("t_create_time"));
		return expense;
	}

}
