package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Role;

import util.RowMapper;

public class RoleRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		Role role = new Role();
		role.setId(rs.getInt("id"));
		role.setRoleName(rs.getString("t_role_name"));
		role.setCreateTime(rs.getString("t_create_time"));
		return role;
	}

}
