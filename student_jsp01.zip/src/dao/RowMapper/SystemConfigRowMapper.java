package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.SystemConfig;

import util.RowMapper;

public class SystemConfigRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		SystemConfig systemConfig = new SystemConfig();
		systemConfig.setConfigKey(rs.getString("t_config_key"));
		systemConfig.setConfigPageValue(rs.getString("t_config_page_value"));
		return systemConfig;
	}
}
