package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Dept;

import util.RowMapper;

/**
 *  t_department部门表行映射结果集返回
 * @author xzf
 *
 */
public class DeptRowMapper implements RowMapper{

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		Dept dept = new Dept();
		dept.setDeptNo(rs.getString("t_dept_no"));
		dept.setDeptName(rs.getString("t_dept_name"));
		dept.setDeptLoc(rs.getString("t_dept_loc"));
		dept.setDeptManager(rs.getString("t_dept_manager"));
		dept.setCreateTime(rs.getString("t_create_time"));
		return dept;
	}
	
}
