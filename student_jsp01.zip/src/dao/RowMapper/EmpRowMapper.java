package dao.RowMapper;

import java.sql.ResultSet;

import entity.Emp;

import util.RowMapper;

/**
 * t_employee员工表行映射结果集返回
 * @author xzf
 *
 */
public class EmpRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws Exception {
		Emp emp = new Emp();
		emp.setId(rs.getInt("id"));
		emp.setEmpNo(rs.getString("t_emp_no"));
		emp.setEmpName(rs.getString("t_emp_name"));
		emp.setEmpDept(rs.getString("t_emp_dept"));
		emp.setEmpSex(rs.getString("t_emp_sex"));
		emp.setEmpEducation(rs.getString("t_emp_education"));
		emp.setEmpEmail(rs.getString("t_emp_email"));
		emp.setEmpPhone(rs.getString("t_emp_phone"));
		emp.setEntryTime(rs.getString("t_entry_time"));
		emp.setCreateTime(rs.getDate("t_create_time"));
		return emp;
	}

}
