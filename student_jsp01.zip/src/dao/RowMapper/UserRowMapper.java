
package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.User;

import util.RowMapper;

public class UserRowMapper implements RowMapper{

	public Object getMapRow(ResultSet rs) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setUserAccount(rs.getString("t_user_account"));
		user.setUserPwd(rs.getString("t_user_pwd"));
		user.setRoleId(rs.getInt("t_role_id"));
		user.setEmpNo(rs.getString("t_emp_no"));
		return user;
	}

}
