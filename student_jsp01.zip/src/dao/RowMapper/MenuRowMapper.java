package dao.RowMapper;

import java.sql.ResultSet;

import util.RowMapper;

import entity.Menu;

/**
 * t_menu表行映射结果集返回
 * @author xzf
 *
 */
public class MenuRowMapper implements RowMapper {
	public Object getMapRow(ResultSet rs) throws Exception {
		Menu menu = new Menu();
		menu.setId(rs.getInt("id"));
		menu.setMenuName(rs.getString("t_menu_name"));
		menu.setHrefUrl(rs.getString("t_href_url"));
		menu.setParentId(rs.getInt("t_parent_id"));
		return menu;
	}
}
