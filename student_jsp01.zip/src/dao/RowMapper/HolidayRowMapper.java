package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import entity.Holiday;

import util.RowMapper;

/**
 * t_holiday表行映射结果集返回
 * @author xzf
 *
 */
public class HolidayRowMapper implements RowMapper{

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		Holiday holiday = new Holiday();
		holiday.setId(rs.getInt("id"));
		holiday.setHolidayNo(rs.getInt("t_holiday_no"));
		holiday.setHolidayUser(rs.getString("t_holiday_user"));
		holiday.setHolidayType(rs.getString("t_holiday_type"));
		holiday.setHolidayBz(rs.getString("t_holiday_bz"));
		holiday.setStartTime(rs.getString("t_start_time"));
		holiday.setEndTime(rs.getString("t_start_time"));
		holiday.setHolidayStatus(rs.getString("t_holiday_status"));
		String createTime = format.format(format.parse(rs.getString("t_create_time")));
		holiday.setCreateTime(createTime);
		return holiday;
	}

}
