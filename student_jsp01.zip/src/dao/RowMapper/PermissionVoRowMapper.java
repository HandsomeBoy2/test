package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Menu;
import entity.Permission;
import entity.Role;

import util.RowMapper;
import vo.PermissionVo;
/**
 * t_permisson表的行映射结果集返回
 * @author xzf
 *
 */
public class PermissionVoRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		PermissionVo permissionVo = new PermissionVo();
		Menu menu = new Menu();
		menu.setMenuName(rs.getString("t_menu_name"));
		menu.setId(rs.getInt("t_menu_id"));
		permissionVo.setMenu(menu);
		
		Role role = new Role();
		role.setId(rs.getInt("t_role_id"));
		role.setRoleName(rs.getString("t_role_name"));
		permissionVo.setRole(role);
		
		Permission permission = new Permission();
		permission.setId(rs.getInt("id"));
		permission.setRoleId(rs.getInt("t_role_id"));
		permission.setMenuId(rs.getInt("t_menu_id"));
		
		permissionVo.setPermission(permission);
		return permissionVo;
		
	}
}
