package dao.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import entity.AllMoney;

import util.RowMapper;
/**
 *	t_expense报销表行映射结果集返回
 * @author xzf
 *
 */
public class AllMoneyRowMapper implements RowMapper {

	public Object getMapRow(ResultSet rs) throws SQLException, Exception {
		AllMoney allMoney = new AllMoney();
		allMoney.setDept(rs.getString("deptName"));
		allMoney.setPrice(rs.getDouble("expenseMoney"));
		return allMoney;
	}

}
