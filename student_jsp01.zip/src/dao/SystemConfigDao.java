package dao;

import java.util.List;

import entity.Holiday;
import entity.SystemConfig;

public interface SystemConfigDao {
	
	/**
	 * 根据配置表查找配置holiday的key找到对应的value
	 * @param configType
	 * @return List
	 */
	List<SystemConfig> queryType(String configType);
}
