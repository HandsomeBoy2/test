package dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import service.impl.UserServiceImpl;
import util.JDBCTemplate;
import vo.UserVo;
import dao.UserDao;
import dao.RowMapper.MenuRowMapper;
import dao.RowMapper.UserRowMapper;
import dao.RowMapper.UserVoRowMapper;
import entity.Emp;
import entity.Menu;
import entity.User;


public class UserDaoImpl implements UserDao{
	
	private Logger log = Logger.getLogger(UserDaoImpl.class);
	
	private JDBCTemplate jt;
	public UserDaoImpl(){
		this.jt = new JDBCTemplate();
	}
	
	//根据id删除用户
	public void deleteUser(User user) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_user where id = ? ")
			.toString();
		
		jt.update(sql, user.getId());
	}

	//新增用户信息 
	public void insertUser(User user) throws Exception {
		String sql = new StringBuffer()
				.append("insert into t_user (t_user_account, t_user_pwd, t_emp_no, t_role_id, t_user_status,t_create_time) ")
				.append("values(?,?,?,?,?,now()) ")
				.toString();
		
		List params=new ArrayList(); 
		params.add(user.getUserAccount());
		params.add(user.getUserPwd());
		params.add(user.getEmpNo());
		params.add(user.getRoleId());
		params.add(user.getUserStatus());
		
		jt.update(sql, params.toArray());
	}	
	
	//根据姓名和密码查询用户信息
	public User queryByNameAndPwd(String userName, String pwd) throws Exception {
		String sql = new StringBuffer()
			.append("select id,t_user_account,t_user_pwd,t_emp_no,t_role_id,t_user_status, t_create_time from t_user ")
			.append("where t_user_account = ? and t_user_pwd = ? ")
			.toString();
		
		List<User> userList = jt.query(sql, new UserRowMapper(), userName, pwd);
		
		if (userList != null && userList.size() == 1) {
			return userList.get(0);
		} else {
			log.info("根据用户名密码查询不到数据，或者查询多条数据。userName:" + userName
				+ ",pwd:" + pwd + ",结果：" + userList);
			return null;
		}
	}

	//查询所有的一级菜单
	public List<Menu> queryLevelOne(int roleID) throws Exception {
		String sql = new StringBuffer()
			.append("select id, t_menu_name, t_href_url, t_parent_id from t_menu ")
			.append("where t_parent_id is null ")
			.append("and id in (select t_menu_id from t_permissions ")
			.append("where t_role_id = ?) ")			
			.toString();
	
		List <Menu> menuList = jt.query(sql, new MenuRowMapper(), roleID);
		return menuList;
	}

	//查询所有的一级菜单的子菜单
	public List<Menu> querySonMenu(int parentId, int roleID) throws Exception {
		String sql = new StringBuffer()
			.append("select id, t_menu_name, t_href_url, t_parent_id from t_menu ")
			.append("where t_parent_id = ? ")
			.append("and id in (select t_menu_id from t_permissions where t_role_id = ?) ")
			.toString();
		
		List <Menu> menuList = jt.query(sql, new MenuRowMapper(), parentId, roleID);
		return menuList;
	}

	//根据user的账号和emp的编号来查询t_user表和t_empoyee表做账户显示用
	public List<UserVo> queryAllUser() throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_user u, t_employee e ")
			.append("where u.t_emp_no = e.t_emp_no ")
			.toString();
		
		List<UserVo> userVoList = jt.query(sql, new UserVoRowMapper());
		return userVoList;
	}

	//根据账号、账号状态、角色id来模糊查询t_user表
	public List<UserVo> queryAllUserByPage(Map<String, Object> paramMap)
			throws Exception {
		int pageNo = (Integer)paramMap.get("pageNo");
		int  pageSize = (Integer)paramMap.get("pageSize");
		StringBuffer sql = new StringBuffer()
			.append("select * from t_user u, t_employee e ")
			.append("where u.t_emp_no = e.t_emp_no ");				
		
		List params=new ArrayList(); 
		if(paramMap.get("searchUserAccount") != null){
			sql.append("and u.t_user_account like '%"+paramMap.get("searchUserAccount")+"%' ");
		}
		if(paramMap.get("searchUserStatusType") != null){
			sql.append("and u.t_user_status = ? ");
			params.add(paramMap.get("searchUserStatusType"));
		}
		if(paramMap.get("searchRoleType") != null){
			sql.append(" and u.t_role_id = ? ");
			params.add(paramMap.get("searchRoleType"));
		}
		params.add((pageNo-1)*pageSize);
		params.add(pageSize);
		
		sql.append("order by u.id asc ");
		sql.append("limit ?,? ");	
		
		List<UserVo> userVoList = jt.query(sql.toString(), new UserVoRowMapper(), params.toArray());
		return userVoList;
	}

	
	//修改用户信息
	public void updateUser(User user) throws Exception {
		String sql = new StringBuffer()
			.append("update t_user ")
			.append("set t_user_pwd = ?, t_emp_no = ?, t_role_id=?, t_user_status=? ")
			.append("where t_user_account = ? ")
			.toString();
		
		List params=new ArrayList(); 
		params.add(user.getUserPwd());
		params.add(user.getEmpNo());
		params.add(user.getRoleId());
		params.add(user.getUserStatus());
		params.add(user.getUserAccount());
		
		jt.update(sql, params.toArray());
	}
	
	//更改用户的密码
	public void updateUserPwd(User user) throws Exception {
		String sql = new StringBuffer()
			.append("update t_user ")
			.append("set t_user_pwd = ? ")
			.append("where id = ? ")
			.toString();
		
		jt.update(sql, user.getUserPwd(), user.getId());
	}
	
}
