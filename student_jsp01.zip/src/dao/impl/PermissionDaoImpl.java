package dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import util.JDBCTemplate;
import vo.PermissionVo;
import dao.PermissionDao;
import dao.RowMapper.HolidayRowMapper;
import dao.RowMapper.PermissionVoRowMapper;
import entity.Permission;

public class PermissionDaoImpl implements PermissionDao {

	private Logger log = Logger.getLogger(EmpDaoImpl.class);
	
	private JDBCTemplate jt;
	public  PermissionDaoImpl(){
		this.jt = new JDBCTemplate();
	}
	
	//删除权限
	public void delete(Permission permission) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_permissions where t_role_id=? and t_menu_id=?  ")
			.toString();
		
		jt.update(sql, permission.getRoleId(), permission.getMenuId());
	}
	
	//新增权限
	public void insert(Permission permission) throws Exception {
		String sql = new StringBuffer()
			.append("insert into t_permissions (t_role_id, t_menu_id, t_create_time) ")
			.append("values(?,?,now()) ")
			.toString();
		
		jt.update(sql, permission.getRoleId(), permission.getMenuId());
	}

	//分页查询权限
	public List<PermissionVo> queryByPage(Map<String, Object> paramMap)
			throws Exception {
		List params=new ArrayList(); 
		StringBuffer sql = new StringBuffer()
					.append("select r.id as t_role_id, r.t_role_name as t_role_name,  m.id as t_menu_id ,m.t_menu_name, p.*  from t_role r, t_menu m, t_permissions p " +
							"where r.id = p.t_role_id and p.t_menu_id = m.id ");
		if(paramMap.get("searchPermissionId") != null){
			sql.append("and p.id =? ");
			params.add(paramMap.get("searchPermissionId"));
		}
		if(paramMap.get("searchRoleId") != null){
			sql.append("and r.id =? ");
			params.add(paramMap.get("searchRoleId"));
		}
		if(paramMap.get("searchMenuId") != null){
			sql.append("and p.t_menu_id=? ");
			params.add(paramMap.get("searchMenuId"));
		}
		sql.append(" order by p.t_role_id, p.t_menu_id asc ");
		return jt.query(sql.toString(), new PermissionVoRowMapper(), params.toArray());
	}
	
	//更新权限
	public void update(Permission permission) throws Exception {
		String sql = new StringBuffer()
			.append("update t_permissions ")
			.append("set  t_permissions.t_menu_id = ? ")
			.append("where t_permissions.t_role_id = ? ")
			.toString();
		
		jt.update(sql, permission.getMenuId(), permission.getRoleId());
	}
}
