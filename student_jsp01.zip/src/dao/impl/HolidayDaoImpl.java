package dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import util.JDBCTemplate;

import dao.HolidayDao;
import dao.RowMapper.HolidayRowMapper;
import entity.Holiday;

public class HolidayDaoImpl implements HolidayDao{
	
	private Logger log = Logger.getLogger(EmpDaoImpl.class);
	
	private JDBCTemplate jt;
	public HolidayDaoImpl(){
		this.jt = new JDBCTemplate();
	}
	

	//删除请假信息
	public void delete(Holiday holiday) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_holiday ")
			.append("where t_holiday_no = ? and t_holiday_status = ? ")
			.toString();
		
		jt.update(sql, holiday.getHolidayNo(), holiday.getHolidayStatus());
	}
	
	//新增请假信息
	public void insert(Holiday holiday) throws Exception {	
		String sql = new StringBuffer()
			.append("insert into t_holiday (t_holiday_user, t_holiday_type, t_holiday_bz, t_start_time, t_end_time, t_holiday_status,t_create_time) ")
			.append("values(?,?,?,?,?,?,now())")
			.toString();
		
		List params=new ArrayList(); 
		params.add(holiday.getHolidayUser());
		params.add(holiday.getHolidayType());
		params.add(holiday.getHolidayBz());
		params.add(holiday.getStartTime());
		params.add(holiday.getEndTime());
		params.add(holiday.getHolidayStatus());
		
		jt.update(sql, params.toArray());	
	}
	
	
	//修改请假信息
	public void update(Holiday holiday) throws Exception {	
		String sql = new StringBuffer()
			.append("update t_holiday ")
			.append("set t_holiday_type = ?, t_holiday_bz = ?, t_start_time = ?, t_end_time = ?, t_holiday_status = ? ")
			.append("where t_holiday_no=? ")
			.toString();
		
		List params=new ArrayList(); 
		params.add(holiday.getHolidayBz());
		params.add(holiday.getStartTime());
		params.add(holiday.getEndTime());
		params.add(holiday.getHolidayStatus());
		params.add(holiday.getHolidayNo());
		
		jt.update(sql, params.toArray());
	}	
	
	///查询请假信息
	public List<Holiday> queryAll(Map<String, Object>paramMap) throws Exception {
		StringBuffer sql = new StringBuffer()
			.append("select * from t_holiday ")
			.append("where 1=1 ");
		
		List params=new ArrayList(); 
		if(paramMap.get("searchProposer") != null){
			sql.append("and t_holiday_user like '%"+paramMap.get("searchProposer")+"%' ");
		}
		if(paramMap.get("searchHolidayId") != null){
			sql.append("and id = ? ");
			params.add(paramMap.get("searchHolidayId"));
		}
		if(paramMap.get("searchHolidayType") != null){
			sql.append(" and t_holiday_type = ? ");
			params.add(paramMap.get("searchHolidayType"));
		}
		if(paramMap.get("searchApplicationStatus") != null){
			sql.append(" and t_holiday_Status = ? ");
			params.add(paramMap.get("searchApplicationStatus"));
		}
		
		return jt.query(sql.toString(), new HolidayRowMapper(), params.toArray());
	}
	
	//分页查询请假信息
	public List<Holiday> queryByPage(Map<String, Object> paramMap) throws Exception {
		int pageNo = (Integer)paramMap.get("pageNo");
		int  pageSize = (Integer)paramMap.get("pageSize");
		
		StringBuffer sql = new StringBuffer()
			.append("select * from t_holiday ")
			.append("where 1=1 ");
		
		List params=new ArrayList(); 
		if(paramMap.get("searchProposer") != null){
			sql.append("and t_holiday_user like '%"+paramMap.get("searchProposer")+"%' ");
		}
		if(paramMap.get("searchHolidayType") != null){
			sql.append(" and t_holiday_type = ? ");
			params.add(paramMap.get("searchHolidayType"));
		}
		if(paramMap.get("searchApplicationStatus") != null){
			sql.append(" and t_holiday_Status = ? ");
			params.add(paramMap.get("searchApplicationStatus"));
		}
		if(paramMap.get("searchHolidayNo") != null){
			sql.append(" and t_holiday_no = ? ");
			params.add(paramMap.get("searchHolidayNo"));
		}
		sql.append(" order by t_holiday_no asc ");
		sql.append(" limit ?,? ");	
		params.add((pageNo-1)*pageSize);
		params.add(pageSize);
		
		return jt.query(sql.toString(), new HolidayRowMapper(), params.toArray());
	}
}
