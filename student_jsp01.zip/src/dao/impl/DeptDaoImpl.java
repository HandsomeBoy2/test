package dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import util.JDBCTemplate;

import dao.DeptDao;
import dao.RowMapper.DeptRowMapper;
import entity.Dept;

public class DeptDaoImpl  implements DeptDao{
	private Logger log = Logger.getLogger(EmpDaoImpl.class);
	
	private JDBCTemplate jt;
	public DeptDaoImpl(){
		this.jt = new JDBCTemplate();
	}
	
	//新增部门
	public void insertDept(Dept dept) throws Exception {
		String sql = new StringBuffer()
			.append("insert into t_department (t_dept_no, t_dept_name, t_dept_loc, t_dept_manager, t_create_time) ")
			.append("values(?, ?, ?, ?, now())")
			.toString();
		
		jt.update(sql, dept.getDeptNo(), dept.getDeptName(), dept.getDeptLoc(), dept.getDeptManager());
	}
	
	//删除部门
	public void deleteDept(String deptNo) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_department where t_dept_no = ? ")
			.toString();
		
		jt.update(sql, deptNo);
	}

	//修改部门
	public void updateDept(Dept dept) throws Exception {
		String sql = new StringBuffer()
			.append("update t_department ")
			.append("set t_dept_name = ?, t_dept_loc=?,t_dept_manager=? ")
			.append("where t_dept_no = ? ")
			.toString();
		
		jt.update(sql, dept.getDeptName(), dept.getDeptLoc(), dept.getDeptManager(), dept.getDeptNo());
	}
	
	//查询部门
	public List<Dept> queryAll() throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_department ")
			.toString();
		
		return jt.query(sql, new DeptRowMapper());
	}
	
	//根据部门编号查询部门详情
	public List<Dept> queryDept(String deptNo) throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_department where t_dept_no = ? ")
			.toString();
		
		return jt.query(sql, new DeptRowMapper(), deptNo);
	}

	//分页查询部门
	public List<Dept> queryByPage(Map<String, Object> paramMap) throws Exception {
		int pageNo = (Integer)paramMap.get("pageNo");
		int  pageSize = (Integer)paramMap.get("pageSize");
		String sql = new StringBuffer()
			.append("select * from t_department ")
			.append("order by t_dept_no asc  limit ?, ? ")
			.toString();
		
		return jt.query(sql.toString(), new DeptRowMapper(), (pageNo-1)*pageSize, pageSize);
	}
}
