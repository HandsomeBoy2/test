package dao.impl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import util.RowMapper;

import util.JDBCTemplate;

import dao.EmpDao;
import dao.RowMapper.EmpRowMapper;
import dao.RowMapper.HolidayRowMapper;
import entity.Emp;

public class EmpDaoImpl implements EmpDao{
	private Logger log = Logger.getLogger(EmpDaoImpl.class);
	
	private JDBCTemplate jt;
	public EmpDaoImpl(){
		this.jt = new JDBCTemplate();
	}
	
	//删除员工信息
	public void delete(int id) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_employee where id=? ")
			.toString();
		
		jt.update(sql, id);
	}
	
	//新增员工信息
	public void insert(Emp emp) throws Exception {
		String sql = new StringBuffer()
			.append("insert into t_employee (t_emp_no, t_emp_name, t_emp_dept, t_emp_sex, t_emp_education, t_emp_email, t_emp_phone,  t_entry_time)")
			.append("values(?, ?, ?, ?, ?, ?, ?, ?)")
			.toString();
		
		List params=new ArrayList(); 
		params.add(emp.getEmpNo());
		params.add(emp.getEmpName());
		params.add(emp.getEmpDept());
		params.add(emp.getEmpSex());
		params.add(emp.getEmpEducation());
		params.add(emp.getEmpEmail());
		params.add(emp.getEmpPhone());
		params.add(emp.getEntryTime());
		
		jt.update(sql, params.toArray());
	}
	
	//查询员工信息
	public List<Emp> queryAll() throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_employee ")
			.toString();
		
		return jt.query(sql, new EmpRowMapper());
	}
	
	//查询员工信息
	public Emp query(int id) throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_employee where id = ? ")
			.toString();
		List list =  jt.query(sql, new EmpRowMapper(), id);
		if (list != null && list.size() == 1) {
			return (Emp) list.get(0);     
		} else {
			log.info("根据sql查询不到数据,或者是查询出来多条数据!");
			return null;
		}
	}
	
	//查询员工信息
	public List<Emp> queryByName(String name) throws Exception{
		String sql = new StringBuffer()
			.append("select * from t_employee where t_emp_name = ?")
			.toString();
		
		return jt.query(sql, new EmpRowMapper(),name);
	}
	
	//查询员工信息
	public List<Emp> queryCount(Map<String, Object> paramMap) throws Exception {
		StringBuffer sql = new StringBuffer()
			.append("select * from t_employee ")
			.append("where 1=1 ");
		
		List params=new ArrayList(); 
		if(paramMap.get("searchName") != null){
			sql.append("and t_emp_name like '%"+paramMap.get("searchName")+"%' ");
		}
		if(paramMap.get("searchDept") != null){
			sql.append(" and t_emp_dept = ? ");
			params.add(paramMap.get("searchDept"));
		}
		return jt.query(sql.toString(), new EmpRowMapper(), params.toArray());
	}
	
	//查询员工信息
	public List<Emp> queryByNo(String no) throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_employee where  t_emp_no = ? ")
			.toString();
		
		return jt.query(sql, new EmpRowMapper(), no);
	}
	
	//分页查询员工信息
	public List<Emp> queryByPage(Map<String, Object>paramMap) throws Exception {
		int pageNo = (Integer)paramMap.get("pageNo");
		int  pageSize = (Integer)paramMap.get("pageSize");
		
		List params=new ArrayList(); 
		StringBuffer sql = new StringBuffer()
			.append("select * from t_employee ")
			.append("where 1=1 ");
		if(paramMap.get("searchName") != null){
			sql.append("and t_emp_name like '%"+paramMap.get("searchName")+"%' ");
		}
		if(paramMap.get("searchDept") != null){
			sql.append(" and t_emp_dept = ? ");
			params.add(paramMap.get("searchDept"));
		}
		sql.append(" order by id asc ");
		sql.append(" limit ?,? ");	
		params.add((pageNo-1)*pageSize);
		params.add(pageSize);
		
		return jt.query(sql.toString(), new EmpRowMapper(), params.toArray());
	}
	
	//查询员工信息
	public List<Emp> queryEmpByDeptNo(String deptNo) throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_employee where  t_emp_dept = ? ")
			.toString();
		
		return jt.query(sql, new EmpRowMapper(), deptNo);	
	}
	
	//修改员工信息
	public void update(Emp emp) throws Exception {
		String sql = new StringBuffer()
			.append("update t_employee ")
			.append("set t_emp_name = ?, t_emp_dept = ?, t_emp_sex = ?, t_emp_education = ?, t_emp_email = ?, t_emp_phone = ? ")
			.append("where t_emp_no = ? ")
			.toString();
		
		List params=new ArrayList(); 
		params.add(emp.getEmpName());
		params.add(emp.getEmpDept());
		params.add( emp.getEmpSex());
		params.add(emp.getEmpEducation());
		params.add(emp.getEmpEmail());
		params.add( emp.getEmpPhone());
		params.add(emp.getEmpPhone());
		
		jt.update(sql, params.toArray() );
	}
}
