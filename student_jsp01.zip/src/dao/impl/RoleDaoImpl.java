package dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import util.JDBCTemplate;

import dao.RoleDao;
import dao.RowMapper.RoleRowMapper;
import entity.Role;

public class RoleDaoImpl implements RoleDao {
	private Logger log = Logger.getLogger(RoleDaoImpl.class);
	
	private JDBCTemplate jt;	
	public RoleDaoImpl() {
		this.jt = new JDBCTemplate();
	}
	
	//删除角色
	public void deleteRole(Role role) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_role ")
			.append("where t_role.id = ? and t_role.id not in (select t_role_id from t_user) ")
			.toString();
		
		List params = new ArrayList();
		params.add(role.getId());
		
		jt.update(sql, params.toArray());
	}
	
	//添加角色
	public void insertRole(Role role) throws Exception{
		String sql = new StringBuffer()
			.append("insert into t_role (id, t_role_name, t_create_time) ")
			.append("values (?, ?, now()) ")
			.toString();
		
		jt.update(sql, role.getId(), role.getRoleName());
	}
	
	//查询角色
	public List<Role> queryAllRole() throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_role ")
			.toString();
		
		return jt.query(sql, new RoleRowMapper());
	}
	
	//修改角色内容
	public void updateRole(Role role) throws Exception {
		String sql = new StringBuffer()
			.append("update t_role ")
			.append("set t_role_name = ? ")
			.append("where id = ? ")
			.toString();
		
		jt.update(sql, role.getRoleName(), role.getId());
	}
	
	
}
