package dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import util.JDBCTemplate;
import dao.ExpenseDao;
import dao.RowMapper.AllMoneyRowMapper;
import dao.RowMapper.ExpenseRowMapper;
import dao.RowMapper.HolidayRowMapper;
import entity.AllMoney;
import entity.Expense;

public class ExpenseDaoImpl implements ExpenseDao {

	private Logger log = Logger.getLogger(EmpDaoImpl.class);
	
	private JDBCTemplate jt;
	public ExpenseDaoImpl(){
		jt = new JDBCTemplate();
	}
	
	//删除报销信息
	public void delete(Expense expense) throws Exception {
		String sql = new StringBuffer()
			.append("delete from t_expense where t_exp_no = ? and t_exp_status = ? ")
			.toString();
		
		jt.update(sql, expense.getExpenseNo(), expense.getExpenseStatus());
	}
	
	//新增报销信息
	public void insert(Expense expense) throws Exception {
		String sql = new StringBuffer()
			.append("insert into t_expense(t_exp_no, t_emp_name, t_exp_type, t_exp_money,  t_exp_date, t_exp_status, t_exp_digest, t_create_time)")
			.append("values(?,?,?,?,now(),?,?,now())")
			.toString();
		
		List params=new ArrayList(); 
		params.add(expense.getExpenseNo());
		params.add(expense.getExpenseName());
		params.add(expense.getExpenseType());
		params.add(expense.getExpenseMoney());
		params.add(expense.getExpenseStatus());
		params.add(expense.getExpenseDigest());

		jt.update(sql, params.toArray());
	}
	
	///查询报销信息
	public List<Expense> queryAll(Map<String, Object> paramMap) throws Exception {
		StringBuffer sql = new StringBuffer()
			.append("select * from t_expense where 1=1 ");
		
		List params=new ArrayList(); 
		if(paramMap.get("searchExpenseType") != null){
			sql.append("and t_exp_type = ? ");
			params.add(paramMap.get("searchExpenseType"));
		}
		if(paramMap.get("searchExpenseStatus") != null){
			sql.append("and t_exp_status = ? ");
			params.add(paramMap.get("searchExpenseStatus"));
		}
		if(paramMap.get("searchExpenseNo") != null){
			sql.append("and t_exp_no = ? ");
			params.add(paramMap.get("searchExpenseNo"));
		}
		
		return jt.query(sql.toString(), new ExpenseRowMapper(), params.toArray());
	}

	//分页查询报销信息
	public List<Expense> queryByPage(Map<String, Object> paramMap) throws Exception {
		StringBuffer sql = new StringBuffer()
			.append("select * from t_expense where 1=1 ");
		
		int pageNo = (Integer)paramMap.get("pageNo");
		int  pageSize = (Integer)paramMap.get("pageSize");
		List params=new ArrayList(); 
		if(paramMap.get("searchExpenseType") != null){
			sql.append("and t_exp_type = ? ");
			params.add(paramMap.get("searchExpenseType"));
		}
		if(paramMap.get("searchApplicationStatus") != null){
			sql.append("and t_exp_status = ? ");
			params.add(paramMap.get("searchApplicationStatus"));
		}
		if(paramMap.get("searchExpenseNo") != null){
			sql.append("and t_exp_no = ? ");
			params.add(paramMap.get("searchExpenseNo"));
		}
		sql.append("order by id asc ");
		sql.append("limit ?,? ");	
		params.add((pageNo-1)*pageSize);
		params.add(pageSize);
		
		return jt.query(sql.toString(), new ExpenseRowMapper(), params.toArray());
	}
	
	//报销统计
	public List<AllMoney> queryAM(Map<String, Object> paramMap) throws Exception {
		
		StringBuffer sql = new StringBuffer()
			.append("select d.t_dept_name as deptName, sum(e.t_exp_money) as expenseMoney from t_department d, t_expense e, t_employee em ")
			.append("where em.t_emp_name = e.t_emp_name and d.t_dept_no = em.t_emp_dept ");

		List params=new ArrayList();
		if(paramMap.get("searchDept") != null){
			sql.append("and d.t_dept_no = ? ");
			params.add(paramMap.get("searchDept"));
		}
		if(paramMap.get("searchBeginTime") != null && paramMap.get("searchEndTime") != null){
			sql.append("and e.t_exp_date between  ? and ? ");
			params.add(paramMap.get("searchBeginTime"));
			params.add(paramMap.get("searchEndTime"));
		}
		sql.append("and e.t_exp_status = 1 ");
		sql.append("group by d.t_dept_no ");	
		
		return jt.query(sql.toString(), new AllMoneyRowMapper(), params.toArray());
	}
	

	//修改报销信息
	public void update(Expense expense) throws Exception {
		String sql = new StringBuffer()
			.append("update t_expense ")
			.append("set t_exp_type = ?, t_exp_digest = ?, t_exp_money=?, t_exp_date=now(), t_exp_status = ? ")
			.append("where t_exp_no=? ")
			.toString();
		
		List params=new ArrayList();
		params.add(expense.getExpenseType());
		params.add(expense.getExpenseDigest());
		params.add(expense.getExpenseMoney());
		params.add(expense.getExpenseStatus());
		params.add(expense.getExpenseNo());
		
		jt.update(sql, params.toArray());
	}
}
