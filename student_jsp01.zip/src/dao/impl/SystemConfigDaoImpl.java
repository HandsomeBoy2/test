package dao.impl;

import java.util.List;

import org.apache.log4j.Logger;

import util.JDBCTemplate;

import dao.SystemConfigDao;
import dao.RowMapper.SystemConfigRowMapper;
import entity.Holiday;
import entity.SystemConfig;

public class SystemConfigDaoImpl implements SystemConfigDao{
	
	private Logger log = Logger.getLogger(EmpDaoImpl.class);
	
	private JDBCTemplate jt;
	public SystemConfigDaoImpl(){
		this.jt = new JDBCTemplate();
	}
	
	//通过配置表查询配置的类型
	public List<SystemConfig> queryType(String configType) {
		String sql = new StringBuffer()
			.append("select t_config_key ,t_config_page_value from t_sys_config ")
			.append("where t_config_type =? ")
			.toString();
		
		try {
			return jt.query(sql, new SystemConfigRowMapper(), configType);
		} catch (Exception e) {
			log.info("根据配置表的类型未查出相应数据", e);
		}
		return null;	
	}
}
