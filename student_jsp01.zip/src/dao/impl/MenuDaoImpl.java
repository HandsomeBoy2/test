package dao.impl;

import entity.Menu;
import java.util.List;

import util.JDBCTemplate;

import dao.MenuDao;
import dao.RowMapper.MenuRowMapper;

public class MenuDaoImpl implements MenuDao {
	
	private JDBCTemplate jt;
	public MenuDaoImpl(){
		jt = new JDBCTemplate();
	}
	
	//查询所有的菜单
	public List<Menu> queryAllMenu() throws Exception {
		String sql = new StringBuffer()
			.append("select * from t_menu ")
			.toString();
		
		return jt.query(sql, new MenuRowMapper());
	}

}
