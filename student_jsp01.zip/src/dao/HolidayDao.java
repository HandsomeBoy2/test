package dao;

import java.util.List;
import java.util.Map;

import entity.Emp;
import entity.Holiday;

public interface HolidayDao {
	
	/**
	 * 草稿状态下可删除请假记录
	 * @param holiday
	 * @throws Exception
	 */
	void delete(Holiday holiday) throws Exception;
	
	/**
	 * 新增请假记录
	 * @param holiday
	 * @throws Exception
	 */
	void insert(Holiday holiday) throws Exception;

	/**
	 * 查询请假记录
	 * @param holiday
	 * @return List
	 * @throws Exception
	 */
	List<Holiday> queryAll(Map<String, Object>paramMap) throws Exception;
	
	/**
	 * 分页查询请假记录
	 * @param paramMap
	 * @return List
	 * @throws Exception
	 */
	List<Holiday> queryByPage(Map<String, Object>paramMap) throws Exception; 
	
	/**
	 * 修改草稿状态下的请假记录，请假编号不可修改
	 * @param holiday
	 * @throws Exception
	 */
	void update(Holiday holiday) throws Exception;
}
