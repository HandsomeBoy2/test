package dao;

import java.util.List;
import java.util.Map;

import vo.UserVo;

import entity.Menu;

import entity.User;

public interface UserDao {
	
	/**
	 * 根据帐户的帐号删除账户
	 * @param user
	 * @throws Exception
	 */
	void deleteUser(User user) throws Exception;
	

	/**
	 * 添加账户信息
	 * @param user
	 * @throws Exception
	 */
	void insertUser(User user) throws Exception;
	
	/**
	 * 根据姓名和密码查询用户信息
	 * @param name
	 * @param pwd
	 * @return
	 * @throws Exception 
	 */
	User queryByNameAndPwd(String name, String pwd) throws Exception;

	/**
	 * 查询所有的一级菜单
	 * @return
	 */
	List<Menu> queryLevelOne(int roleID) throws Exception;
	
	/**
	 * 查询所有的一级菜单的子菜单
	 * @return
	 */
	List<Menu> querySonMenu(int parentId,int roleID) throws Exception;
	
	/**
	 * 根据user的账号和emp的编号来查询t_user表和t_empoyee表做账户显示用
	 * @param user
	 * @param emp
	 * @return List
	 * @throws Exception
	 */
	List<UserVo> queryAllUser() throws Exception;
	
	/**
	 * 根据账号、账号状态、角色id来模糊查询t_user表
	 * @param paramMap
	 * @return List 
	 * @throws Exception
	 */
	List <UserVo> queryAllUserByPage(Map<String, Object>paramMap) throws Exception;
	
	/**
	 * 修改帐户的信息
	 * @param user
	 * @throws Exception
	 */
	void updateUser(User user) throws Exception;
	
	/**
	 * 更改用户密码
	 * @param pwd
	 * @return User
	 * @throws Exception
	 */
	void updateUserPwd(User user) throws Exception;
}
