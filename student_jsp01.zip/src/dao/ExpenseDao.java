package dao;

import java.util.List;
import java.util.Map;

import entity.AllMoney;
import entity.Expense;



public interface ExpenseDao {
	
	/**
	 * 草稿状态下可删除报销记录
	 * @param expense
	 * @throws Exception
	 */
	void delete(Expense expense) throws Exception;
	
	/**
	 * 新增报销记录
	 * @param expense
	 * @throws Exception
	 */
	void insert(Expense expense) throws Exception;

	/**
	 * 查询报销记录
	 * @param expense
	 * @return List
	 * @throws Exception
	 */
	List<Expense> queryAll(Map<String, Object>paramMap) throws Exception;
	
	/**
	 * 分页查询报销
	 * @param paramMap
	 * @return List
	 * @throws Exception
	 */
	List<Expense> queryByPage(Map<String, Object>paramMap) throws Exception; 
	
	
	/**
	 * 报销表金额统计
	 * @param paramMap
	 * @return List
	 * @throws Exception
	 */
	List<AllMoney> queryAM(Map<String, Object>paramMap) throws Exception;
	

	/**
	 * 修改草稿状态下的报销记录
	 * @param expense
	 * @throws Exception
	 */
	void update(Expense expense) throws Exception;
}
