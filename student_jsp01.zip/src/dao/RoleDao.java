package dao;

import java.util.List;

import entity.Role;

public interface RoleDao {
	/**
	 * 删除角色
	 * @param role
	 * @throws Exception
	 */
	void deleteRole(Role role) throws Exception;
	
	/**
	 * 添加角色
	 * @param role
	 * @throws Exception
	 */
	void insertRole(Role role) throws Exception;
	
	/**
	 * 查询所有角色
	 * @return List
	 * @throws Exception
	 */
	List<Role> queryAllRole() throws Exception;
	
	/**
	 * 修改角色内容
	 * @param role
	 * @throws Exception
	 */
	void updateRole(Role role) throws Exception;
}
