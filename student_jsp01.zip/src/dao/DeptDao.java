package dao;

import java.util.List;
import java.util.Map;

import entity.Dept;

public interface DeptDao {
	
	
	/**
	 * 根据部门编号删除部门
	 * @param deptNo
	 * @throws Exception
	 */
	void deleteDept(String deptNo) throws Exception;
		
	/**
	 * 新增部门
	 * @param dept
	 * @throws Exception
	 */
	void insertDept(Dept dept)throws Exception;
	
	/**
	 * 根据部门编号更改部门信息
	 * @param deptNo
	 * @throws Exception
	 */
	void updateDept(Dept dept) throws Exception;
	
	/**
	 * 查询部门所有信息
	 * @return List
	 * @throws Exception
	 */
	List<Dept> queryAll() throws Exception;
	
	/**
	 * 根据员工部门号查询部门
	 * @param empDept
	 * @return List
	 * @throws Exception
	 */
	List<Dept> queryDept(String deptNo) throws Exception;
	
	/**
	 * 分页查询部门
	 * @param paramMap
	 * @return List
	 * @throws Exception
	 */
	List<Dept> queryByPage(Map<String, Object>paramMap) throws Exception; 
}
