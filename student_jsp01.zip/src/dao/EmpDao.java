package dao;

import java.util.List;
import java.util.Map;

import entity.Emp;

public interface EmpDao {

	/**
	 * 
	 * 根据员工的id删除员工
	 * @param emp
	 * @throws Exception
	 */
	void delete(int id) throws Exception;
	
	/**
	 * 新增员工
	 * @param emp
	 * @throws Exception
	 */
	void insert(Emp emp) throws Exception;

	/**
	 * 查询所有员工
	 * @return List
	 * @throws Exception
	 */
	List<Emp> queryAll() throws Exception;
	
	/**
	 * 根据id查询员工
	 * @param id
	 * @return Emp
	 * @throws Exception
	 */
	Emp query(int id) throws Exception;
	
	/**
	 * 根据员工姓名查询员工
	 * @param name
	 * @return List
	 * @throws Exception
	 */
	List<Emp> queryByName(String name) throws Exception;
	
	/**
	 * 分页查询员工
	 * @param paramMap
	 * @return List
	 * @throws Exception
	 */
	List<Emp> queryByPage(Map<String, Object>paramMap) throws Exception; 
	
	/**
	 * 查询员工数目
	 * @param paramMap
	 * @return List
	 * @throws Exception
	 */
	List<Emp>  queryCount(Map<String, Object>paramMap) throws Exception;
	
	/**
	 * 根据员工编号查询员工
	 * @param no
	 * @return List
	 * @throws Exception
	 */
	List<Emp> queryByNo(String no) throws Exception;

	/**
	 * 根据部门编号查询员工
	 * @param no
	 * @return List
	 * @throws Exception
	 */
	List<Emp> queryEmpByDeptNo(String no) throws Exception;
	
	/**
	 * 修改员工信息
	 * @param emp
	 * @throws Exception
	 */
	void update(Emp emp) throws Exception;
	
}
