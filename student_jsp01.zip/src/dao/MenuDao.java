package dao;

import java.util.List;

import entity.Menu;

public interface MenuDao {
	/**
	 * 查询所有的菜单
	 * @return List
	 * @throws Exception 
	 */
	List<Menu> queryAllMenu() throws Exception;
}
