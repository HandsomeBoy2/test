package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import service.DeptService;
import service.EmpService;
import util.StringUtil;
import entity.Dept;


public class DeptController {
	private static Logger log = Logger.getLogger(EmpController.class);
	private DeptService deptService;
	public void setDeptService(DeptService deptService) {
		this.deptService = deptService;
	}
	

	//添加部门
	public String insertDept(HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		String deptNo = request.getParameter("deptNo");
		String deptName = request.getParameter("deptName");
		String deptLoc = request.getParameter("deptLoc");
		String deptManager = request.getParameter("deptManager");
		
		//校验修改的东西是否合格
		
		Dept dept = new Dept();
		dept.setDeptNo(deptNo);
		dept.setDeptName(deptName);
		dept.setDeptLoc(deptLoc);
		dept.setDeptManager(deptManager);
		deptService.insertDept(dept);
		return "success";
	}
	
	
	//删除部门信息
	public void removeDept(HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		String deptNo = request.getParameter("deptNo");
		log.info("ajax校验部门是否还有员工,deptNo:" + deptNo);
	
		String result = deptService.deleteDept(deptNo);	
		response.getWriter().write(result);
	}
	
	//修改部门
	public String modifyDept(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String deptNo = request.getParameter("deptNo");
		String deptName = request.getParameter("deptName");
		String deptLoc = request.getParameter("deptLoc");
		String deptManager = request.getParameter("deptManager");
		
		
		//校验修改的东西是否合格
		
		Dept dept = new Dept();
		dept.setDeptNo(deptNo);
		dept.setDeptName(deptName);
		dept.setDeptLoc(deptLoc);
		dept.setDeptManager(deptManager);
		deptService.updateDept(dept);
		return "success";
	}
	
	//根据部门编号查询部门信息
	public String queryDeptByNo(HttpServletRequest request,
			HttpServletResponse response) throws NumberFormatException,
			Exception {
		String deptNo = request.getParameter("deptNo");
		Dept dept = deptService.queryDept(deptNo).get(0);
		request.setAttribute("dept", dept);
		return "success";
	}
	
	//查询要修改的部门信息
	public String showModifyDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String deptNo = request.getParameter("deptNo");
		try {
			Dept dept = deptService.queryDept(deptNo).get(0);
			request.setAttribute("dept", dept);
		} catch (Exception e) {
			log.info("请求对象设置属性失败", e);
		}	
		return "success";
	}
	//根据分页查询数据
	public String queryDeptByPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		int pageSize = 3;

		String pageNoStr = request.getParameter("pageNo");
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();

		int pageNo = StringUtil.isEmpty(pageNoStr) ? 1 : Integer
				.valueOf(pageNoStr);

		int totalPage = 0;

		int count = deptService.queryAll().size();
		//如果不能整除,则+1 
		//(count+pageSize-1)/pageSize;
		totalPage = count % pageSize == 0 ? count / pageSize : count / pageSize
				+ 1;

		//pageNo需要校验
		pageNo = pageNo <= 1? 1: pageNo;
		pageNo = pageNo >= totalPage? totalPage : pageNo;
		
		paramMap.put("pageSize", pageSize);
		paramMap.put("pageNo", pageNo);
		
		
		// 1.调用serivce查询list
		List<Dept> deptList = deptService.queryByPage(paramMap);
		// 2.list进行数据传递
		request.setAttribute("deptList", deptList);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalPage", totalPage);
		// 3.页面跳转
		return "success";
	}
}
