package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import entity.Role;
import entity.User;

import service.RoleService;
import service.UserService;
import vo.UserVo;

public class RoleController {
	private Logger  log = Logger.getLogger(RoleController.class);
	
	private RoleService roleService;
	private UserService userService;
	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	//删除角色信息 如果角色还有用户关联则删除失败
	public void removeRole(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id = Integer.parseInt(request.getParameter("id"));
		log.info("ajax请求---checkId----id:" + id);
		String result = "success";
		Role role = new Role();
		role.setId(id);
		List <UserVo> userVoList = userService.queryAllUser();
		for (UserVo u : userVoList) {
			if(u.getUser().getRoleId() == id){
				result = "error";
				// 将结果响应给浏览器
				log.info("ajax响应结果,result:" + result);
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().write(result);
				return;
			}
		}
		roleService.deleteRole(role);
		log.info("ajax响应结果,result:" + result);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(result);
	}
	
	//查询所有角色信息
	public String queryAllRole(HttpServletRequest request, HttpServletResponse response) throws Exception{
		List <Role> roleList = roleService.queryAllRole();	
		request.setAttribute("roleList", roleList);
		return "success";
	}
	
	//修改角色信息
	public String showModifyRole(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id = Integer.parseInt(request.getParameter("id"));
		List <Role> roleList = roleService.queryAllRole();	
		for (Role role : roleList) {
			if(role.getId() == id){
				request.setAttribute("role", role);
				return "success";
			}
		}
		return "error";
	}
	
	public String modifyRole(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id = Integer.parseInt(request.getParameter("id"));
		String roleName = request.getParameter("roleName");
		Role role = new Role();
		role.setId(id);
		role.setRoleName(roleName);
		roleService.updateRole(role);
		return "success";
	}
	
	//新增角色信息
	public void insertRole(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id = Integer.parseInt(request.getParameter("id"));
		String roleName = request.getParameter("roleName");
		Role role = new Role();
		role.setId(id);
		role.setRoleName(roleName);
		String result = "success";
		List <Role> roleList = roleService.queryAllRole();
		for (Role r : roleList) {
			if(r.getId() == id){
				result =  "error";
				log.info("ajax响应结果,result:" + result);
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().write(result);
			}
		}
		roleService.insertRole(role);
		log.info("ajax响应结果,result:" + result);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(result);
	}
}
