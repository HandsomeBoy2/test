package controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;

import service.DeptService;
import service.EmpService;
import service.SystemConfigService;
import util.StringUtil;
import entity.Dept;
import entity.Emp;
import entity.SystemConfig;
import factory.ApplicationContext;

public class EmpController {
	//private EmpService empService = (EmpService) ApplicationContext.getObject("empService");		
	
	private static Logger log = Logger.getLogger(EmpController.class);
	private EmpService empService;
	private DeptService deptService;
	private SystemConfigService systemConfigService;
	public void setEmpService(EmpService empService) {
		this.empService = empService;
	}
	public void setDeptService(DeptService deptService) {
		this.deptService = deptService;
	}
	public void setSystemConfigService(SystemConfigService systemConfigService) {
		this.systemConfigService = systemConfigService;
	}
	//添加员工
	public String queryAllDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		try {
			List <Dept> deptList = deptService.queryAll();
			List <SystemConfig> systemConfigList = systemConfigService.queryType("educationType");
			request.setAttribute("deptList", deptList);
			request.setAttribute("systemConfigList", systemConfigList);
		} catch (Exception e) { 
			log.info("请求对象设置属性失败", e);
		}	
		return "success";
	}
	
	public String insertEmp(HttpServletRequest request,
			HttpServletResponse response)throws IOException, ParseException{
		String empNo = request.getParameter("no");
		String empName = request.getParameter("name");
		String empSex = request.getParameter("sex");
		String empDept = request.getParameter("dept");
		String empEducation = request.getParameter("edu");
		String empEmailName = request.getParameter("email");
		String empPhone = request.getParameter("phone");
		String entryTime = request.getParameter("empEntryTime");
		
		//校验修改的东西是否合格
		Emp emp = new Emp();
		emp.setEmpNo(empNo);
		emp.setEmpName(empName);
		emp.setEmpSex(empSex);
		emp.setEmpDept(empDept);
		emp.setEmpEducation(empEducation);
		emp.setEmpEmail(empEmailName);
		emp.setEmpPhone(empPhone);		
		emp.setEntryTime(entryTime);
		empService.insertEmp(emp);
		return "success";
	}
	
	//删除员工信息
	public String removeEmp(HttpServletRequest request,
			HttpServletResponse response)throws IOException{
		String id = request.getParameter("id");
		empService.deleteEmp(Integer.parseInt(id));
		return "success";
	}
	
	//修改员工
	public String modifyEmp(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String empNo = request.getParameter("no");
		String empName = request.getParameter("name");
		String empSex = request.getParameter("sex");
		String empDept = request.getParameter("dept");
		String empEducation = request.getParameter("edu");
		String empEmailName = request.getParameter("email");
		String empPhone = request.getParameter("phone");
		
		
		//校验修改的东西是否合格
		
		
		
		Emp emp = new Emp();
		emp.setEmpNo(empNo);
		emp.setEmpName(empName);
		emp.setEmpSex(empSex);
		emp.setEmpDept(empDept);
		emp.setEmpEducation(empEducation);
		emp.setEmpEmail(empEmailName);
		emp.setEmpPhone(empPhone);
		empService.updateEmp(emp);
		return "success";
	}

	//根据分页查询员工信息
	public String queryEmpByPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		int pageSize = 3;

		String pageNoStr = request.getParameter("pageNo");

		String searchName = request.getParameter("searchEmpName");
		String searchDept = request.getParameter("searchDept");
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();
		
		if(!StringUtil.isEmpty(searchName)){
			paramMap.put("searchName", searchName);
		}
		if(!StringUtil.isEmpty(searchDept)){
			paramMap.put("searchDept", searchDept);
		}
		
		int pageNo = StringUtil.isEmpty(pageNoStr) ? 1 : Integer
				.valueOf(pageNoStr);

		int totalPage = 0;

		int count = empService.queryCount(paramMap);
		//如果不能整除,则+1 
		//(count+pageSize-1)/pageSize;
		totalPage = count % pageSize == 0 ? count / pageSize : count / pageSize
				+ 1;

		//pageNo需要校验
		pageNo = pageNo <= 1? 1: pageNo;
		pageNo = pageNo >= totalPage? totalPage : pageNo;
		
		paramMap.put("pageSize", pageSize);
		paramMap.put("pageNo", pageNo);
		
		
		// 1.调用serivce查询list
		List<Emp> empList = empService.queryByPage(paramMap);
		List <Dept> deptList = deptService.queryAll();	
		List <SystemConfig> systemConfigList = systemConfigService.queryType("educationType");
		// 2.list进行数据传递
		request.setAttribute("empList", empList);
		request.setAttribute("deptList", deptList);
		request.setAttribute("systemConfigList", systemConfigList);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("searchName", searchName);
		request.setAttribute("searchDept", searchDept);
		// 3.页面跳转
		return "success";
	}
	
	//查询要修改的员工信息
	public String showModifyEmp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		int id  = Integer.parseInt(request.getParameter("id"));
		try {
			Emp emp = empService.query(id);
			List <Dept> deptList = deptService.queryAll();
			List <SystemConfig> systemConfigList = systemConfigService.queryType("educationType");		
			request.setAttribute("emp", emp);
			request.setAttribute("deptList", deptList);
			request.setAttribute("systemConfigList", systemConfigList);
		} catch (Exception e) {
			log.info("请求对象设置属性失败", e);
		}	
		return "success";
	}
	
	
	/**
	 * 根据id查询员工
	 * @param request
	 * @param response
	 * @return
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	public String queryEmpById(HttpServletRequest request,
			HttpServletResponse response) throws NumberFormatException,
			Exception {
		String id = request.getParameter("id");
		Emp emp = empService.query(Integer.valueOf(id));
		List <Dept> deptList = deptService.queryAll();	
		List <SystemConfig> systemConfigList = systemConfigService.queryType("educationType");
		request.setAttribute("emp", emp);
		request.setAttribute("deptList", deptList);
		request.setAttribute("systemConfigList", systemConfigList);
		return "success";
	}
	/**
	 * ajax使用,根据前台传的No查询emp数据
	 * @param request
	 * @param response
	 * @return
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	public void  queryEmpByNo(HttpServletRequest request,
			HttpServletResponse response) throws NumberFormatException,
			Exception {
		String no = request.getParameter("empNo");
		log.info("ajax校验编号是否重复,empNo:" + no);
		String result = "success";
		if (empService.query(no).size() > 0) {
			result = "error";
		}else{
			result = "success";
		}
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(result);
	}
	
	/**
	 * 根据姓名查询是否重复
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void checkEmpName(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String empName = request.getParameter("empName");
		String id = request.getParameter("id");
		log.info("ajax校验姓名是否重复,empName:" + empName);
		String result = "success";
		
		// 调用service查.....
		List<Emp> empList = empService.queryByName(empName);
		if (empList != null && empList.size() > 0) {
			
			if(empList.size() == 1 && empList.get(0).getId().toString().equals(id))
			{
				//如果查询结果只有1条数据,并且数据的ID=前台传入的ID,
				//那么就认为查询的是本身,也就是姓名没有修改
				result = "success";
			}
			else
			{
				result = "error";
			}
		}
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(result);
	}
}
