 package controller;


import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import entity.Emp;
import entity.Holiday;
import entity.Menu;
import entity.Role;
import entity.SystemConfig;
import entity.User;

import service.EmpService;
import service.RoleService;
import service.SystemConfigService;
import service.UserService;
import util.MakeCertPic;
import util.StringUtil;
import vo.UserVo;


public class UserController {

	private Logger log = Logger.getLogger(UserController.class);

	private UserService userService;
	private SystemConfigService systemConfigService;
	private RoleService roleService;
	private EmpService empService;
	
	
	public void setUserService(UserService userService) {
		this.userService= userService;
	}
	public void setSystemConfigService(SystemConfigService systemConfigService) {
		this.systemConfigService = systemConfigService;
	}
	public void setRoleService (RoleService roleService){
		this.roleService = roleService;
	}
	
	public void setEmpService(EmpService empService) {
		this.empService = empService;
	}
	/**
	 * 获取验证码图片 不需要做页面跳转,所以方法不需要返回值
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public void checkCode(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String code = request.getParameter("code");
		log.info("ajax请求---checkNameStr----name:" + code);
		String result = "success";
		String sysCode = (String) request.getSession().getAttribute("sysCode");
		if (!(sysCode.equals(code))){
			result = "error";
		}
		// 将结果响应给浏览器
		log.info("ajax响应结果,result:" + result);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(result);
	}
	
	//用户登录
	public void checkNP(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String uN = request.getParameter("userName");
		String pwd =request.getParameter("password");
		log.info("ajax请求---checkNameStr----name:" + uN+pwd);
		String result = "success";
		try {
			User user = userService.login(uN, pwd);
	
		// 5.判断用户是否为空
		// 6.根据判断结果跳转页面，success-->main.jsp, error-->result.jsp
		if (user == null) {
			result = "error";
		}
		} catch (Exception e) {
			log.info("未找到相应账号！",e);			
		}
		// 将结果响应给浏览器
		log.info("ajax响应结果,result:" + result);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(result);
	}
	
	//获取验证码
	public void getCodeImg(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String code = MakeCertPic
				.getCertPic(60, 20, response.getOutputStream());
		log.info("请求的验证码:" + code);
		request.getSession().setAttribute("sysCode", code);
		// 短信验证码,必须携带手机号码作为参数
		// 先随机生成4位数,保存在session中, 套用短信模版,调用短信接口 (短信网关)
	}

	//用户登录
	public String login(HttpServletRequest req, HttpServletResponse resp) {
		String userName = req.getParameter("userName");
		String pwd = req.getParameter("password");
		String code = req.getParameter("code");
		log.info("======登录参数打印,userName:" + userName + ",pwd:" + pwd + ",code:"
				+ code);
		if (StringUtil.isEmpty(userName) || StringUtil.isEmpty(pwd)
				|| StringUtil.isEmpty(code)) {
			log.info("用户名或者密码为空或者验证码,登录失败！");
			return "error";
		}
		// 比较验证码
		// 单例模式中,不能轻易使用成员变量
		// String sysCode = MakeCertPic.getCode();
		String sysCode = (String) req.getSession().getAttribute("sysCode");
		if (!sysCode.equalsIgnoreCase(code)) {
			log.info("验证码不匹配,系统验证码:" + sysCode + ",用户输入验证码:" + code);
			return "error";
		}
		try {
			User user = userService.login(userName, pwd);
			// 5.判断用户是否为空
			// 6.根据判断结果跳转页面，success-->main.jsp, error-->result.jsp
			if (user != null) {
				req.getSession().setAttribute("user", user);
				
				//动态展示菜单
				//查询所有的菜单信息(一级菜单,二级菜单作为子菜单存在)
				List<Menu> menuList = userService.queryMenuList(user.getRoleId());
				log.info(menuList);
				req.getSession().setAttribute("menuList", menuList);
				return "success";
			} else {
				return "error";
			}

		} catch (Exception e) {
			log.info("登录失败！",e);
			return "error";
		}
	}
	
	//账户展示
	public String queryAllUserByPage(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int pageSize = 3;

		String pageNoStr = request.getParameter("pageNo");
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();

		//查询信息
		String searchUserAccount = request.getParameter("searchUserAccount");
		String searchUserStatusType = request.getParameter("searchUserStatusType");
		String searchRoleType = request.getParameter("searchRoleType");
		if(!StringUtil.isEmpty(searchUserAccount)){
			paramMap.put("searchUserAccount", searchUserAccount);
		}
		if(!StringUtil.isEmpty(searchUserStatusType)){
			paramMap.put("searchUserStatusType", searchUserStatusType);
		}
		if(!StringUtil.isEmpty(searchRoleType)){
			paramMap.put("searchRoleType", searchRoleType);
		}
		int pageNo = StringUtil.isEmpty(pageNoStr) ? 1 : Integer
				.valueOf(pageNoStr);

		int totalPage = 0;

		int count = userService.queryAllUser().size();
		//如果不能整除,则+1 
		//(count+pageSize-1)/pageSize;
		totalPage = count % pageSize == 0 ? count / pageSize : count / pageSize
				+ 1;

		//pageNo需要校验
		pageNo = pageNo <= 1? 1: pageNo;
		pageNo = pageNo >= totalPage? totalPage : pageNo;
		
		paramMap.put("pageSize", pageSize);
		paramMap.put("pageNo", pageNo);
		
		
		// 1.调用serivce查询list
		List<UserVo> userVoList = userService.queryAllUserByPage(paramMap);
		List <SystemConfig> systemConfigList = systemConfigService.queryType("userStatusType");
		List <Role> roleList = roleService.queryAllRole();
		// 2.list进行数据传递
		//System.out.println(userVoList.size()+"+++++++");
		//System.out.println(systemConfigList.size()+"++++++++++++++++");
		request.setAttribute("searchUserAccount", searchUserAccount);
		request.setAttribute("searchUserStatusType", searchUserStatusType);
		request.setAttribute("searchRoleType", searchRoleType);
		request.setAttribute("userVoList", userVoList);
		request.setAttribute("systemConfigList", systemConfigList);
		request.setAttribute("roleList", roleList);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalPage", totalPage);
		// 3.页面跳转
		return "success";
	}
	//删除账户
	public String removeUser(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println(id+"++++++++++++");
		User user = new User();
		user.setId(id);
		userService.deleteUser(user);
		return "success";
	}
	//添加新账户时将添加页面要的东西带过去
	public String queryInsertUserBasicInfo(HttpServletRequest request, HttpServletResponse response) throws Exception{
		List <Emp> empList = empService.queryAll();
		List <SystemConfig> systemConfigList = systemConfigService.queryType("userStatusType");
		List <Role> roleList = roleService.queryAllRole();
		
		request.setAttribute("empList", empList);
		request.setAttribute("systemConfigList", systemConfigList);
		request.setAttribute("roleList", roleList);
		return "success";
	}
	
	public String insertUser(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String userAccount = request.getParameter("userAccount");
		String userPwd = request.getParameter("userPwd");
		String empNo = request.getParameter("empNo");
		String userStatus = request.getParameter("userStatus");
		int roleId = Integer.parseInt(request.getParameter("roleId"));
		
		User u = new User();
		u.setUserAccount(userAccount);
		u.setUserPwd(userPwd);
		u.setEmpNo(empNo);
		u.setUserStatus(userStatus);
		u.setRoleId(roleId);
		
		userService.insertUser(u);
		return "success";
	}

	//修改账户信息
	public String showModifyUser(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int searchId = Integer.parseInt(request.getParameter("id"));
		UserVo userVo = new UserVo();
		List<UserVo> userVoList = userService.queryAllUser();
		for (UserVo userVo2 : userVoList) {
			if(userVo2.getUser().getId() == searchId){
				userVo = userVo2;
			}
		}
		List <Emp> empList = empService.queryAll();
		List <SystemConfig> systemConfigList = systemConfigService.queryType("userStatusType");
		List <Role> roleList = roleService.queryAllRole();
		
		request.setAttribute("empList", empList);
		request.setAttribute("systemConfigList", systemConfigList);
		request.setAttribute("roleList", roleList);
		request.setAttribute("userVo", userVo);
		return "success";
	}
	public String modifyUser(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String userAccount = request.getParameter("userAccount");
		String userPwd = request.getParameter("userPwd");
		String empNo = request.getParameter("empNo");
		String userStatus = request.getParameter("userStatus");
		int roleId = Integer.parseInt(request.getParameter("roleId"));
		
		System.out.println(userAccount+"+++++++++++++++");
		User u = new User();
		u.setUserAccount(userAccount);
		u.setUserPwd(userPwd);
		u.setEmpNo(empNo);
		u.setUserStatus(userStatus);
		u.setRoleId(roleId);
		
		userService.updateUser(u);
		return "success";
	}
	
	//修改用户密码
	public String resetPwd(HttpServletRequest request, HttpServletResponse response) throws Exception{
		return "success";
	}
	public void updateUserPwd(HttpServletRequest request, HttpServletResponse response) throws Exception{
		User user = (User) request.getSession().getAttribute("user");
		String oldPwd = request.getParameter("oldPwd");
		String newPwd = request.getParameter("newPwd");
		String confirmPwd = request.getParameter("confirmPwd");
		System.out.println(newPwd+"==="+confirmPwd);
		if(!newPwd.equals(confirmPwd)){
			response.getWriter().write("confirm");
			return;
		}
		String userAccount =user.getUserAccount();
		 User userA = userService.login(userAccount, oldPwd);
		 if(userA == null){
			 response.getWriter().write("error");
			 return;
		 }else{
			 user.setUserPwd(newPwd);
			 userService.updateUserPwd(user);		 
			 response.getWriter().write("success");
			 request.getSession().invalidate();
		 }
	}
}
