package controller;

import entity.Menu;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import service.MenuService;
import service.PermissionService;
import service.RoleService;
import util.StringUtil;
import vo.PermissionVo;
import entity.Permission;
import entity.Role;

public class PermissionController {
	private static Logger log = Logger.getLogger(EmpController.class);
	private PermissionService permissionService;
	private RoleService roleService;
	private MenuService menuService;

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}	
	
	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}

	public void setMenuService(MenuService menuService) {
		this.menuService = menuService;
	}


	//添加权限信息
	public String queryType(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{	
		Map<String, Object> paramMap = new HashMap<String, Object>();
		List<Role> roleList = roleService.queryAllRole();
		List<Menu> menuList = menuService.queryAllMenu();
		request.setAttribute("roleList", roleList);	
		request.setAttribute("menuList", menuList);	
		return "success";
	}
	public String insertPermission(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		int searchRoleId = Integer.parseInt(request.getParameter("roleId"));
		int searchMenuId = Integer.parseInt(request.getParameter("menuId"));
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("searchRoleId", searchRoleId);
		paramMap.put("searchMenuId", searchMenuId);
		if(permissionService.queryByPage(paramMap).size() > 0){
			return "success";
		}	
		Permission permission = new Permission();
		permission.setRoleId(searchRoleId);
		permission.setMenuId(searchMenuId);
		permissionService.insert(permission);
		return "success";
	}
	
	
	//删除权限信息
	public String removePermission(HttpServletRequest request,
				HttpServletResponse response)throws Exception{

		int roleId = Integer.parseInt(request.getParameter("roleId"));
		int menuId = Integer.parseInt(request.getParameter("menuId"));
		Permission permission = new Permission();
		permission.setRoleId(roleId);
		permission.setMenuId(menuId);
		permissionService.delete(permission);
		
		return "success";
	}
	
	//修改权限信息
	public String showModifyPermission(HttpServletRequest request,
					HttpServletResponse response)throws Exception{	
		try{
			//用来存放查询的过滤条件

			int searchRoleId = Integer.parseInt(request.getParameter("roleId"));
			int searchMenuId = Integer.parseInt(request.getParameter("menuId"));
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("searchRoleId", searchRoleId);
			paramMap.put("searchMenuId", searchMenuId);
			
			PermissionVo permissionVo = permissionService.queryByPage(paramMap).get(0);
			System.out.println(permissionVo.toString()+"++++++++++");
			List<Menu> menuList = menuService.queryAllMenu();
			request.setAttribute("menuList", menuList);
			request.setAttribute("permissionVo", permissionVo);
		} catch (Exception e) {
			log.info("请求对象设置属性失败", e);
		}	
		return "success";
	}
	public String modifyPermission(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String searchId = request.getParameter("searchId");
		String searchName = request.getParameter("searchName");
		
		Permission permission = new Permission();
		permission.setRoleId(Integer.parseInt(searchId));
		permission.setMenuId(Integer.parseInt(searchName));
		//校验修改的东西是否合格
		permissionService.update(permission);
			
	
		return "success";
	}
	//查询权限信息
	public String queryPermissionByPage(HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();


		String searchRoleId = request.getParameter("searchRoleId");
		String searchMenuId = request.getParameter("searchMenuId");

		if(!StringUtil.isEmpty(searchRoleId)){
			paramMap.put("searchRoleId", searchRoleId);
		}
		if(!StringUtil.isEmpty(searchMenuId)){
			paramMap.put("searchMenuId", searchMenuId);
		}
		// 1.调用serivce查询list
		List<PermissionVo> permissionVoList = permissionService.queryByPage(paramMap);
		List<Role> roleList = roleService.queryAllRole();
		List<Menu> menuList = menuService.queryAllMenu();
		
		// 2.list进行数据传递
		request.setAttribute("permissionVoList", permissionVoList);
		request.setAttribute("roleList", roleList);
		request.setAttribute("menuList", menuList);
		request.setAttribute("searchRoleId", searchRoleId);
		request.setAttribute("searchMenuId", searchMenuId);
		// 3.页面跳转
		return "success";
	}	
}
