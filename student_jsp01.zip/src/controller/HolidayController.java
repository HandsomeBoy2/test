package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import entity.Dept;
import entity.Emp;
import entity.Holiday;
import entity.SystemConfig;
import entity.User;

import service.EmpService;
import service.HolidayService;
import service.SystemConfigService;
import util.StringUtil;

public class HolidayController {
	private static Logger log = Logger.getLogger(EmpController.class);
	private HolidayService holidayService;
	private EmpService empService;
	private SystemConfigService systemConfigService;
	public void setHolidayService(HolidayService holidayService) {
		this.holidayService = holidayService;
	}	
	public void setEmpService(EmpService empService) {
		this.empService = empService;
	}
	public void setSystemConfigService(SystemConfigService systemConfigService) {
		this.systemConfigService = systemConfigService;
	}
	
	//添加请假信息
	public String queryAllHolidayType(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		String configHolidayType = request.getParameter("type");
		
		List <SystemConfig> systemConfigList = systemConfigService.queryType(configHolidayType);
		
		request.setAttribute("systemConfigList", systemConfigList);	
		return "success";
	}
	public String insertHoliday(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		User user =  (User) request.getSession().getAttribute("user");
		String empNo = user.getEmpNo();
		String holidayProposer = empService.query(empNo).get(0).getEmpName();
		String holidayType = request.getParameter("holidayType");
		String leaveBz = request.getParameter("leaveBz");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String holidayStatus = request.getParameter("insertStatus");
		
			
		Holiday holiday = new Holiday();
		holiday.setHolidayUser(holidayProposer);
		holiday.setHolidayType(holidayType);
		holiday.setHolidayBz(leaveBz);
		holiday.setStartTime(startTime);
		holiday.setEndTime(endTime);
		holiday.setHolidayStatus(holidayStatus);
		
		holidayService.insertHoliday(holiday);
		return "success";
	}
	
	
	//删除请假信息
	public String removeHoliday(HttpServletRequest request,
				HttpServletResponse response)throws Exception{

		String holidayNo = request.getParameter("holidayNo");
		String holidayStatus = request.getParameter("holidayStatus");
		if(holidayStatus.equals("1")){
			return "success";
		}
		Holiday holiday = new Holiday();
		holiday.setHolidayNo(Integer.parseInt(holidayNo));
		holiday.setHolidayStatus(holidayStatus);
		holidayService.deleteHoliday(holiday);
		return "success";
	}
	
	//修改请假信息
	public String showModifyHoliday(HttpServletRequest request,
					HttpServletResponse response)throws Exception{	
		try{
			//用来存放查询的过滤条件
			Map<String, Object> paramMap = new HashMap<String, Object>();
			
			String searchHolidayId = request.getParameter("holidayId");


			if(!StringUtil.isEmpty(searchHolidayId)){
				paramMap.put("searchHolidayId", searchHolidayId);
			}
			Holiday holiday = holidayService.queryAll(paramMap).get(0);
			System.out.println(holiday.toString()+"+++++++++++++++++++++++++");
			List <SystemConfig> systemConfigList = systemConfigService.queryType("leaveType");
			request.setAttribute("holiday", holiday);
			request.setAttribute("systemConfigList", systemConfigList);
		} catch (Exception e) {
			log.info("请求对象设置属性失败", e);
		}	
		return "success";
	}
	public String modifyHoliday(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String searchProposer = request.getParameter("searchProposer");
		String searchHolidayType = request.getParameter("searchHolidayType");
		String searchApplicationStatus = request.getParameter("searchApplicationStatus");
		String searchHolidayNo = request.getParameter("searchHolidayNo");
		String searchHolidayBz = request.getParameter("searchHolidayBz");
		String searchStartTime = request.getParameter("searchStartTime");
		String searchEndTime = request.getParameter("searchEndTime");
		
		
		//校验修改的东西是否合格
		
		
		
		Holiday holiday = new Holiday();
		holiday.setHolidayUser(searchProposer);
		holiday.setHolidayType(searchHolidayType);
		holiday.setHolidayStatus(searchApplicationStatus);
		holiday.setHolidayNo(Integer.parseInt(searchHolidayNo));
		holiday.setHolidayBz(searchHolidayBz);
		holiday.setStartTime(searchStartTime);
		holiday.setEndTime(searchEndTime);
		holidayService.updateHoliday(holiday);
		return "success";
	}
	//查询请假信息
	public String queryHolidayByPage(HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		int pageSize = 3;

		String pageNoStr = request.getParameter("pageNo");
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();

		//查询详细信息
		String searchHolidayNo = request.getParameter("searchHolidayNo");
		
		
		String searchProposer = request.getParameter("searchProposer");
		String searchHolidayType = request.getParameter("searchHolidayType");
		String searchApplicationStatus = request.getParameter("searchApplicationStatus");
		if(!StringUtil.isEmpty(searchProposer)){
			paramMap.put("searchProposer", searchProposer);
		}
		if(!StringUtil.isEmpty(searchHolidayType)){
			paramMap.put("searchHolidayType", searchHolidayType);
		}
		if(!StringUtil.isEmpty(searchApplicationStatus)){
			paramMap.put("searchApplicationStatus", searchApplicationStatus);
		}
		if(!StringUtil.isEmpty(searchHolidayNo)){
			paramMap.put("searchHolidayNo", searchHolidayNo);
		}
		
		int pageNo = StringUtil.isEmpty(pageNoStr) ? 1 : Integer
				.valueOf(pageNoStr);

		int totalPage = 0;

		int count = holidayService.queryAll(paramMap).size();
		//如果不能整除,则+1 
		//(count+pageSize-1)/pageSize;
		totalPage = count % pageSize == 0 ? count / pageSize : count / pageSize
				+ 1;

		//pageNo需要校验
		pageNo = pageNo <= 1? 1: pageNo;
		pageNo = pageNo >= totalPage? totalPage : pageNo;
		
		paramMap.put("pageSize", pageSize);
		paramMap.put("pageNo", pageNo);
		
		
		// 1.调用serivce查询list
		List<Holiday> holidayList = holidayService.queryByPage(paramMap);
		List <SystemConfig> systemConfigList = systemConfigService.queryType("leaveType");
		// 2.list进行数据传递
		request.setAttribute("holidayList", holidayList);
		request.setAttribute("systemConfigList", systemConfigList);
		request.setAttribute("searchProposer", searchProposer);
		request.setAttribute("searchHolidayType", searchHolidayType);
		request.setAttribute("searchApplicationStatus", searchApplicationStatus);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalPage", totalPage);
		// 3.页面跳转
		return "success";
	}	
}
