package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import entity.Dept;

import service.DeptService;
import service.EmpService;
import service.ExpenseService;
import service.HolidayService;
import service.SystemConfigService;
import util.StringUtil;
import entity.AllMoney;
import entity.Expense;
import entity.Holiday;
import entity.SystemConfig;
import entity.User;

public class ExpenseController {
	private static Logger log = Logger.getLogger(EmpController.class);
	private ExpenseService expenseService;
	private EmpService empService;
	private DeptService deptService;
	private SystemConfigService systemConfigService;
	public void setExpenseService(ExpenseService expenseService) {
		this.expenseService = expenseService;
	}	
	public void setEmpService(EmpService empService) {
		this.empService = empService;
	}
	public void setDeptService( DeptService deptService) {
		this.deptService = deptService;
	}
	public void setSystemConfigService(SystemConfigService systemConfigService) {
		this.systemConfigService = systemConfigService;
	}
	
	//添加报销信息
	public String queryAllExpenseType(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		String configExpenseType = request.getParameter("type");
		
		List <SystemConfig> systemConfigList = systemConfigService.queryType(configExpenseType);
		
		System.out.println(systemConfigList.size()+"++++++++++++++");
		
		request.setAttribute("systemConfigList", systemConfigList);	
		return "success";
	}
	public String insertExpense(HttpServletRequest request, HttpServletResponse response) 
			throws Exception{
		
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();
		List<Expense> expenseList = expenseService.queryAll(paramMap);
		
		User user =  (User) request.getSession().getAttribute("user");
		String empNo = user.getEmpNo();
		String expenseName = empService.query(empNo).get(0).getEmpName();
		String expenseType = request.getParameter("expenseType");
		String expenseDigest = request.getParameter("expenseDigest");
		String expenseStatus = request.getParameter("expenseStatus");
		String expenseMoney = request.getParameter("expenseMoney");
			
		Expense expense = new Expense();
		expense.setExpenseName(expenseName);
		expense.setExpenseType(expenseType);
		expense.setExpenseDigest(expenseDigest);
		expense.setExpenseStatus(expenseStatus);
		expense.setExpenseMoney(Double.parseDouble(expenseMoney));
		expense.setExpenseNo(expenseList.size()+1);
		expenseService.insert(expense);
		return "success";
	}
	
	
	//删除报销信息
	public String removeExpense(HttpServletRequest request,
				HttpServletResponse response)throws Exception{

		String expenseNo = request.getParameter("expenseNo");
		String expenseStatus = request.getParameter("expenseStatus");
		if(expenseStatus.equals("1")){
			return "success";
		}
		Expense expense = new Expense();
		expense.setExpenseNo(Integer.parseInt(expenseNo));
		expense.setExpenseStatus(expenseStatus);
		expenseService.delete(expense);
		return "success";
	}
	
	//修改报销信息
	public String showModifyExpense(HttpServletRequest request,
					HttpServletResponse response)throws Exception{	
		try{
			//用来存放查询的过滤条件
			Map<String, Object> paramMap = new HashMap<String, Object>();
			
			String searchExpenseNo = request.getParameter("searchExpenseNo");
			
			if(!StringUtil.isEmpty(searchExpenseNo)){
				paramMap.put("searchExpenseNo", searchExpenseNo);
			}
			Expense expense = expenseService.queryAll(paramMap).get(0);
			System.out.println(expense.toString()+"+++++++++++++++++++++++++");
			List <SystemConfig> systemConfigList = systemConfigService.queryType("expenseType");
			request.setAttribute("expense", expense);
			request.setAttribute("systemConfigList", systemConfigList);
		} catch (Exception e) {
			log.info("请求对象设置属性失败", e);
		}	
		return "success";
	}
	public String modifyExpense(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String searchExpenseName = request.getParameter("searchExpenseName");
		String searchExpenseType = request.getParameter("searchExpenseType");
		String searchApplicationStatus = request.getParameter("searchApplicationStatus");
		String searchExpenseDigest = request.getParameter("searchExpenseDigest");
		String searchExpenseDate = request.getParameter("searchExpenseDate");
		String searchExpenseMoney = request.getParameter("searchExpenseMoney");
		String searchExpenseNo = request.getParameter("searchExpenseNo");
		
		//校验修改的东西是否合格
		Expense expense = new Expense();
		expense.setExpenseNo(Integer.parseInt(searchExpenseNo));
		expense.setExpenseName(searchExpenseName);
		expense.setExpenseType(searchExpenseType);
		expense.setExpenseMoney(Double.parseDouble(searchExpenseMoney));
		expense.setExpenseDate(searchExpenseDate);
		expense.setExpenseStatus(searchApplicationStatus);
		expense.setExpenseDigest(searchExpenseDigest);
		expenseService.update(expense);
		return "success";
	}
	//查询报销信息
	public String queryExpenseByPage(HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		int pageSize = 3;

		String pageNoStr = request.getParameter("pageNo");
		//用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();

		//查询详细信息
		String searchExpenseType = request.getParameter("searchExpenseType");
		String searchApplicationStatus = request.getParameter("searchApplicationStatus");
		String searchExpenseNo = request.getParameter("searchExpenseNo");
		
		if(!StringUtil.isEmpty(searchExpenseType)){
			paramMap.put("searchExpenseType", searchExpenseType);
		}
		if(!StringUtil.isEmpty(searchApplicationStatus)){
			paramMap.put("searchApplicationStatus", searchApplicationStatus);
		}
		if(!StringUtil.isEmpty(searchExpenseNo)){
			paramMap.put("searchExpenseNo", searchExpenseNo);
		}
	
		int pageNo = StringUtil.isEmpty(pageNoStr) ? 1 : Integer
				.valueOf(pageNoStr);

		int totalPage = 0;

		int count = expenseService.queryAll(paramMap).size();
		//如果不能整除,则+1 
		//(count+pageSize-1)/pageSize;
		totalPage = count % pageSize == 0 ? count / pageSize : count / pageSize
				+ 1;

		//pageNo需要校验
		pageNo = pageNo <= 1? 1: pageNo;
		pageNo = pageNo >= totalPage? totalPage : pageNo;
		
		paramMap.put("pageSize", pageSize);
		paramMap.put("pageNo", pageNo);
		
		
		// 1.调用serivce查询list
		List<Expense> expenseList = expenseService.queryByPage(paramMap);
		List <SystemConfig> systemConfigList = systemConfigService.queryType("expenseType");
		// 2.list进行数据传递
		request.setAttribute("expenseList", expenseList);
		request.setAttribute("systemConfigList", systemConfigList);
		request.setAttribute("searchExpenseType", searchExpenseType);
		request.setAttribute("searchApplicationStatus", searchApplicationStatus);
		request.setAttribute("pageNo", pageNo);
		request.setAttribute("totalPage", totalPage);
		// 3.页面跳转
		return "success";
	}	
	
	//报销统计
	public String showStatistics(HttpServletRequest request,HttpServletResponse response) throws Exception{
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		List<Dept> deptList = deptService.queryAll();
		request.setAttribute("deptList", deptList);
	
		String searchDept = request.getParameter("searchDept");
		//获取查询条件：开始时间
		String searchBeginTime = request.getParameter("searchBeginTime");
		//获取查询条件：结束时间
		String searchEndTime = request.getParameter("searchEndTime");
		// 用来存放查询的过滤条件
		Map<String, Object> paramMap = new HashMap<String, Object>();
		//校验是不是空null
		if (!StringUtil.isEmpty(searchDept)) {
			paramMap.put("searchDept", searchDept);
		}
		if(!StringUtil.isEmpty(searchBeginTime)){
			paramMap.put("searchBeginTime", searchBeginTime);
		}
		if(!StringUtil.isEmpty(searchEndTime)){
			paramMap.put("searchEndTime", searchEndTime);
		}
		log.info("查询请假信息的参数："+paramMap);
		List <AllMoney> allMoneyList =  expenseService.queryAM(paramMap);
		request.setAttribute("allMoneyList", allMoneyList);
		
		// 2.list进行数据传递
		request.setAttribute("searchDept", searchDept);
		request.setAttribute("searchBeginTime", searchBeginTime);
		request.setAttribute("searchEndTime", searchEndTime);
		// 3.页面跳转
		return "success";
	}
}
