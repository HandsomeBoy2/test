package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.User;

public class ExitCurrentUserController {
	
	
	public String exit(HttpServletRequest request, HttpServletResponse response) throws Exception{
		request.getSession().invalidate();
		return "success";
	}
}
