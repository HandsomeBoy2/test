package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import service.UserService;

import entity.User;

public class AuthFilter implements Filter {
	//private LoginService loginService = (LoginService) ObjectFactory.getObject("loginService");
	private UserService loginService;
	public void setLoginService(UserService loginService) {
		this.loginService = loginService;
	}

	private Logger log = Logger.getLogger(AuthFilter.class);
	private String noAuth = "";
	
	public void init(FilterConfig filterConfig) throws ServletException {
		noAuth = filterConfig.getInitParameter("NoAuth");
		log.info("不需要权限过滤器拦截的地址,notAuth:" + noAuth);
	}
	
	/**
	 * 校验请求地址是否需要拦截
	 * @param path
	 * @return true需要拦截，false不需要拦截
	 */
	private boolean isAuth(String path){
		//不需要拦截的地址
		String [] noAuths = noAuth.split(",");
		for (String string : noAuths) {
			if(path.endsWith(string)){
				return false;
			}
		}
		return true;
	}
	
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse resp = (HttpServletResponse)response;
		String path = req.getServletPath();	
	
		//路径为login.jsp继续流程
//		if(path.endsWith("login.jsp")||path.endsWith("result.jsp") || path.endsWith("login.action")||path.endsWith(".js")
//				||path.endsWith(".css")){
//			chain.doFilter(req, resp);
//			return;
//		} 
		//不需要校验
		if(!isAuth(path)){
			chain.doFilter(req, resp);
			return;
		}
		//判断user
		//user为空， 跳到login.jsp
		User user = (User) req.getSession().getAttribute("user");
		if(user == null){
			log.info("未登录,需要重新登录再访问,path:" + req.getServletPath());
			resp.sendRedirect(req.getContextPath() + "/njwb/login.jsp");		
		}else{
			chain.doFilter(req, resp);
		}
	}

	public void destroy() {
	}

}
