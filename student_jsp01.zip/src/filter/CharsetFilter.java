package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import util.StringUtil;

public class CharsetFilter implements Filter {
	
	private String encoding;
	
	public void destroy() {
	
	}

	//针对post的请求方式的编码处理
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		//System.out.println("---------进入字符集过滤器设置----------");	
		// 1.设置字符集
		//request.setCharacterEncoding("utf-8");
		req.setCharacterEncoding(encoding);
		//2.流程继续往下走
		chain.doFilter(req, resp);                               
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		// 通过获取ServletContext拿web.xml中配置的全局变量
		encoding = filterConfig.getServletContext().getInitParameter("Encoding");
		if(StringUtil.isEmpty(encoding))
			encoding = "utf-8";
		System.out.println("----------字符集过滤器初始化--------");
	}

}
