package util;

import java.util.Arrays;

public class StringUtil {

	/**
	 * 判断字符串是否为空
	 * @param str
	 * @return true: 为空， false:不为空
	 */
	public static boolean isEmpty(String str)
	{
		return str == null || "".equals(str.trim());
	}
	
	/**
	 * 将String数组,转换成string输出,相邻的对象用逗号分隔
	 * @param args
	 * @return
	 */
	public static String arraysToString(String[] args)
	{
		String string = Arrays.toString(args);//[2,3,4]
		string = string.substring(1,string.length()-1);
		return string;
	}
}
