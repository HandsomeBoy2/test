package util;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 行映射接口
 * @author xzf
 *
 */
public interface RowMapper {
	/**
	 * @param rs
	 * @return Object 行映射通用Object类型
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public abstract Object getMapRow(ResultSet rs) throws SQLException, Exception;
}
