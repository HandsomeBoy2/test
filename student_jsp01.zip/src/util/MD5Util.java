package util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

import sun.misc.BASE64Encoder;

public class MD5Util {
	private static Logger log =  Logger.getLogger(MD5Util.class);
	public static String enc(String password){
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] b = md.digest(password.getBytes());
			BASE64Encoder encoder = new BASE64Encoder();
			return encoder.encode(b);
		} catch (NoSuchAlgorithmException e) {	
			System.out.println("MD5加密失败");
			log.info("MD5加密失败");
		}
		return null;
	}
}
