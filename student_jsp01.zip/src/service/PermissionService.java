package service;

import java.util.List;
import java.util.Map;

import vo.PermissionVo;
import entity.Permission;

public interface PermissionService {
	/**
	 * 添加权限
	 * @param permission
	 * @throws Exception
	 */
	public abstract void insert(Permission permission) throws Exception;

	/**
	 * 删除权限
	 * @param permission
	 * @throws Exception
	 */
	public abstract void delete(Permission permission) throws Exception;

	/**
	 * 修改权限
	 * @param Permission
	 * @throws Exception
	 */
	public abstract void update(Permission permission) throws Exception;

	/**
	 * 查询权限
	 * @param permission
	 * @return List
	 * @throws Exception
	 */
	public abstract List<PermissionVo> queryByPage(Map<String, Object>paramMap) throws Exception; 

	
}
