package service;

import java.util.List;
import java.util.Map;

import entity.Holiday;


public interface HolidayService {
	//添加请假信息
	public void insertHoliday(Holiday holiday);
	
	//删除请假信息
	public void deleteHoliday(Holiday holiday);
	
	//修改请假信息
	public void updateHoliday(Holiday holiday);
	
	//查询请假信息
	public List<Holiday> queryAll(Map<String, Object> paramMap);
	public List<Holiday> queryByPage(Map<String, Object>paramMap) throws Exception; 
}	
