package service;

import java.util.List;
import java.util.Map;

import entity.AllMoney;
import entity.Expense;

public interface ExpenseService {
	/**
	 * 新增报销记录
	 * @param expense
	 * @throws Exception
	 */
	public void insert(Expense expense) throws Exception;

	/**
	 * 草稿状态下可删除报销记录
	 * @param expense
	 * @throws Exception
	 */
	public void delete(Expense expense) throws Exception;
	
	/**
	 * 修改草稿状态下的报销记录
	 * @param expense
	 * @throws Exception
	 */
	public void update(Expense expense) throws Exception;
	
	/**
	 * 查询报销记录
	 * @param expense
	 * @return List
	 * @throws Exception
	 */
	public List<Expense> queryAll(Map<String, Object>paramMap) throws Exception;
	public List<Expense> queryByPage(Map<String, Object>paramMap) throws Exception; 

	//查询报销金额
	public List<AllMoney> queryAM(Map<String, Object>paramMap) throws Exception;
}
