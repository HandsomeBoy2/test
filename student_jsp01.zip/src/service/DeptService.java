package service;

import java.util.List;
import java.util.Map;

import entity.Dept;

public interface DeptService {
	//新增部门
	public abstract void insertDept(Dept dept)throws Exception;
	
	// 根据部门编号删除部门
	public abstract String deleteDept(String deptNo) throws Exception;

	// 根据部门编号更改部门信息
	public abstract void updateDept(Dept dept) throws Exception;

	// 查询部门所有信息
	public abstract List<Dept> queryAll() throws Exception;

	//根据员工部门号查询部门
	public abstract List<Dept> queryDept(String deptNo) throws Exception;
	public List<Dept> queryByPage(Map<String, Object>paramMap) throws Exception; 
}
