package service.proxy;

import java.util.List;
import java.util.Map;

import entity.Dept;
import service.DeptService;

public class DeptServiceProxy implements DeptService{

	public String deleteDept(String deptNo) throws Exception {
		return deptNo;
		// TODO Auto-generated method stub
	}

	public void insertDept(Dept dept) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public List<Dept> queryAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Dept> queryDept(String deptNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateDept(Dept dept) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public List<Dept> queryByPage(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
