package service.proxy;

import java.util.List;
import java.util.Map;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import entity.Menu;
import entity.User;

import service.UserService;
import transaction.TransactionManager;
import vo.UserVo;

public class UserServiceProxy implements UserService{
	private Logger log = Logger.getLogger(UserServiceProxy.class);
	private UserService loginService;
	private TransactionManager transactionManager;
	
	public void setLoginService(UserService loginService) {
		this.loginService = loginService;
	}
	
	public void setTransactionManager(TransactionManager transactionManager){
		this.transactionManager = transactionManager;
	}

	//登录功能
	public User login(String userName, String pwd) throws Exception {
		log.info("事物开启");
		User user = null;
		try {
			
			transactionManager.beginTransation();
			user=loginService.login(userName, pwd);
			transactionManager.commit();
			log.info("事物提交");
		} catch (ServiceException e) {
			e.printStackTrace();
			transactionManager.rollback();
			log.info("事物回滚");
			throw e;
		} 
		return user;
	}

	//查询所有的一级菜单,以及它的子菜单
	public List<Menu> queryMenuList(int roleID) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserVo> queryAllUser() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserVo> queryAllUserByPage(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteUser(User user) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void insertUser(User user) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void updateUser(User user) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void updateUserPwd(User user) throws Exception {
		// TODO Auto-generated method stub
		
	}
}


