package service.proxy;

import java.util.List;
import java.util.Map;

import entity.Emp;
import service.EmpService;

public class EmpServiceProxy implements EmpService {
	
	
	//添加员工信息
	public void insertEmp(Emp emp) {
		// TODO Auto-generated method stub
		
	}

	//删除员工信息
	public void deleteEmp(int id) {
		// TODO Auto-generated method stub

	}

	//修改员工信息
	public void updateEmp(Emp emp) {
		// TODO Auto-generated method stub

	}
	
	//查询员工信息
	public Emp query(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Emp> queryAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Emp> queryByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Emp> queryByPage(Map<String, Object> parmMap) {
		// TODO Auto-generated method stub
		return null;
	}

	public int queryCount(Map<String, Object> parmMap) {
		// TODO Auto-generated method stub
		return 0;
	}

	

	public List<Emp> query(String no) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
