package service;

import java.util.List;

import entity.Role;

public interface RoleService {
	/**
	 * 删除角色
	 * @param role
	 * @throws Exception
	 */
	public abstract void deleteRole(Role role) throws Exception;
	
	/**
	 * 查询所有角色
	 * @return List
	 * @throws Exception
	 */
	public abstract List<Role> queryAllRole() throws Exception;
	
	/**
	 * 修改角色内容
	 * @param role
	 * @throws Exception
	 */
	public abstract void updateRole(Role role) throws Exception;
	
	/**
	 * 新增角色
	 * @param role
	 * @throws Exception
	 */
	public abstract void insertRole(Role role) throws Exception;
}
