package service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import dao.HolidayDao;
import entity.Emp;
import entity.Holiday;
import service.HolidayService;

public class HolidayServiceImpl implements HolidayService {

	private Logger log = Logger.getLogger(HolidayServiceImpl.class);


	private HolidayDao holidayDao;
	public void setHolidayDao(HolidayDao holidayDao) {
		this.holidayDao = holidayDao;
	}
	
	public void insertHoliday(Holiday holiday) {
		try {
			holidayDao.insert(holiday);
		} catch (Exception e) {
			log.info("请假表添加失败", e);
		}
	}

	public void deleteHoliday(Holiday holiday) {
		try {
			holidayDao.delete(holiday);
		} catch (Exception e) {
			log.info("请假表删除失败", e);
		}
	}

	public void updateHoliday(Holiday holiday) {
		try {
			holidayDao.update(holiday);
		} catch (Exception e) {
			log.info("请假表修改失败", e);
		}	
	}

	public List<Holiday> queryAll(Map<String, Object> paramMap) {
		List <Holiday> holidayList = null;
		try {
			holidayList = holidayDao.queryAll(paramMap);
			return holidayList;
		} catch (Exception e) {
			log.info("请假表修改失败", e);
		}
		return holidayList;
	}

	public List<Holiday> queryByPage(Map<String, Object> paramMap) throws Exception {
		List <Holiday> holidayList = null;
		try {
			holidayList = holidayDao.queryByPage(paramMap);
		} catch (Exception e) {
			log.debug("debug：数据库查询失败");
		}
		return holidayList;
	}
}
