package service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import dao.DeptDao;
import dao.EmpDao;

import entity.Dept;
import entity.Emp;
import service.DeptService;

public class DeptServiceImpl implements DeptService {
	private Logger log = Logger.getLogger(DeptServiceImpl.class);
	
	private EmpDao empDao;
	private DeptDao deptDao;	
	public void setEmpDao(EmpDao empDao) {
		this.empDao = empDao;
	}
	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}
	


	//新增部门
	public void insertDept(Dept dept) throws Exception {
		deptDao.insertDept(dept);
	}

	// 根据部门编号删除部门
	public String deleteDept(String deptNo) throws Exception {
		List<Emp> empList = empDao.queryEmpByDeptNo(deptNo);
		log.info("查询部门"+deptNo+"下的员工数目"+empList.size());
		if(empList.size() > 0){
			return "error";
		}else{
			deptDao.deleteDept(deptNo);
			return "success";
		}
	}

	// 根据部门编号更改部门信息
	public void updateDept(Dept dept) throws Exception {
		deptDao.updateDept(dept);
	}

	// 查询部门所有信息
	public List<Dept> queryAll() throws Exception {	
		return deptDao.queryAll();
	}

	//根据员工部门号查询部门
	public List<Dept> queryDept(String deptNo) throws Exception {
		return deptDao.queryDept(deptNo);	
	}
	//部门分页查询
	public List<Dept> queryByPage(Map<String, Object> paramMap) throws Exception {
		return deptDao.queryByPage(paramMap);
	}
}
