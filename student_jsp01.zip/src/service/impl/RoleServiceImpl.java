package service.impl;

import java.util.List;

import dao.RoleDao;

import entity.Role;
import service.RoleService;

public class RoleServiceImpl implements RoleService {
	private RoleDao roleDao;
	public void setRoleDao(RoleDao roleDao) {
		this.roleDao = roleDao;
	}
	//删除角色
	public void deleteRole(Role role) throws Exception {
		roleDao.deleteRole(role);
	}
	//查询角色
	public List<Role> queryAllRole() throws Exception {
		return roleDao.queryAllRole();
	}
	//修改角色内容
	public void updateRole(Role role) throws Exception {
		roleDao.updateRole(role);
	}
	//新增角色
	public void insertRole(Role role) throws Exception {
		roleDao.insertRole(role);
	}
}
