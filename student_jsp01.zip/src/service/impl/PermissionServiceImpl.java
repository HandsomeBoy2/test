package service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import dao.PermissionDao;

import entity.Permission;
import service.PermissionService;
import vo.PermissionVo;

public class PermissionServiceImpl implements PermissionService {

	private Logger log = Logger.getLogger(HolidayServiceImpl.class);


	private PermissionDao permissionDao;
	
	public void setPermissionDao(PermissionDao permissionDao) {
		this.permissionDao = permissionDao;
	}

	public void insert(Permission permission) throws Exception {
		permissionDao.insert(permission);
	}

	public void delete(Permission permission) throws Exception {
		permissionDao.delete(permission);
	}

	public void update(Permission permission) throws Exception {
		permissionDao.update(permission);
	}
	
	public List<PermissionVo> queryByPage(Map<String, Object> paramMap)
			throws Exception {
		return permissionDao.queryByPage(paramMap);
	}
}
