package service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import dao.ExpenseDao;
import dao.HolidayDao;

import entity.AllMoney;
import entity.Expense;
import service.ExpenseService;

public class ExpenseServiceImpl implements ExpenseService {

	private Logger log = Logger.getLogger(HolidayServiceImpl.class);


	private ExpenseDao expenseDao;
	public void setExpenseDao(ExpenseDao expenseDao) {
		this.expenseDao = expenseDao;
	}
	
	public void delete(Expense expense) throws Exception {
		expenseDao.delete(expense);
	}

	public void insert(Expense expense) throws Exception {
		expenseDao.insert(expense);
	}

	public List<Expense> queryAll(Map<String, Object> paramMap) throws Exception {
		return expenseDao.queryAll(paramMap);
	}

	public List<Expense> queryByPage(Map<String, Object> paramMap) throws Exception {
		return expenseDao.queryByPage(paramMap);
	}

	public void update(Expense expense) throws Exception {
		expenseDao.update(expense);
	}

	public List<AllMoney> queryAM(Map<String, Object> paramMap) throws Exception {
		return expenseDao.queryAM(paramMap);
	}

}
