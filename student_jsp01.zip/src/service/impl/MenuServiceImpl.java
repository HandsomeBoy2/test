package service.impl;

import java.util.List;

import dao.MenuDao;

import entity.Menu;
import service.MenuService;

public class MenuServiceImpl implements MenuService {
	private MenuDao menuDao;
	
	
	public void setMenuDao(MenuDao menuDao) {
		this.menuDao = menuDao;
	}


	public List<Menu> queryAllMenu() throws Exception {
		return menuDao.queryAllMenu();
	}

}
