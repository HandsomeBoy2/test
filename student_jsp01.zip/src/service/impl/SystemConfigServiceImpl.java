package service.impl;

import java.util.List;

import org.apache.log4j.Logger;

import dao.SystemConfigDao;

import entity.Holiday;
import entity.SystemConfig;
import service.SystemConfigService;

public class SystemConfigServiceImpl implements SystemConfigService {
	
	private Logger log = Logger.getLogger(SystemConfigServiceImpl.class);

	private SystemConfigDao systemConfigDao;
	public void setSystemConfigDao(SystemConfigDao systemConfigDao) {
		this.systemConfigDao = systemConfigDao;
	}
	
	public List<SystemConfig> queryType(String configType) {
		return systemConfigDao.queryType(configType);
	
	}

}
