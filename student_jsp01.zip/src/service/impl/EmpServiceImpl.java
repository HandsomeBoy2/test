package service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import dao.EmpDao;
import entity.Emp;


import service.EmpService;


public class EmpServiceImpl implements EmpService {
	
	private Logger log = Logger.getLogger(EmpServiceImpl.class);

	//private EmpDao empDao = (EmpDao)ObjectFactory.getObject("empDao");
	private EmpDao empDao;
	public void setEmpDao(EmpDao empDao) {
		this.empDao = empDao;
	}


	//添加员工信息
	public void insertEmp(Emp emp) {
		try {
			empDao.insert(emp);
		} catch (Exception e) {
			log.debug("debug:数据库查询失败", e);
		}	
		
	}

	//删除员工信息
	public void deleteEmp(int id) {
		try {
			empDao.delete(id);
		} catch (Exception e) {
			log.debug("debug:数据库查询失败", e);
		}	
	}

	//修改员工信息
	public void updateEmp(Emp emp) {
		try {
			empDao.update(emp);
		} catch (Exception e) {
			log.debug("debug:数据库查询失败", e);
		}
	}
	//查询员工信息
	public List<Emp> queryAll(){
		log.debug("debug:数据库查询所有员工");
		List<Emp> empList = null;
		try {
			empList =  empDao.queryAll();
		} catch (Exception e) {		
			log.info("info:数据库查询失败", e);
		}
		return empList;
	}
	
	public Emp query(int id) {
		try {
			return empDao.query(id);
		} catch (Exception e) {
			log.debug("debug:数据库查询失败", e);
		}
		return null;
	}
	
	public List<Emp> query(String no) {
		try {
			return empDao.queryByNo(no);
		} catch (Exception e) {
			log.debug("debug:数据库查询失败", e);
		}
		return null;
	}
	public List<Emp> queryByName(String name){
		try {
			return empDao.queryByName(name);
		} catch (Exception e) {
			log.debug("debug：数据库查询失败");
		}
		return null;
	}
	
	public  int queryCount(Map<String, Object>paramMap) {
		int count = 0;
		try {
			count = empDao.queryCount(paramMap).size();
		} catch (Exception e) {
			log.debug("debug：数据库查询失败");
		}
		return count;
	}
	
	public List<Emp> queryByPage(Map<String, Object> paramMap) {
		List <Emp> empList = null;
		try {
			empList = empDao.queryByPage(paramMap);
		} catch (Exception e) {
			log.debug("debug：数据库查询失败");
		}
		return empList;
	}
	
}
