package service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import dao.UserDao;
import entity.Menu;
import entity.User;
import service.UserService;
import vo.UserVo;

public class UserServiceImpl implements UserService{
	private UserDao userDao;
	private Logger log = Logger.getLogger(UserServiceImpl.class);
	public void setUserDao(UserDao userDao){
		this.userDao = userDao;
	}
	
	//登录功能
	public User login(String userName, String password) {
		try {
			return userDao.queryByNameAndPwd(userName, password);
		} catch (Exception e) {
			log.info("登录失败", e);
			return null;
		}	
	}
	
	//更改用户的密码
	public void updateUserPwd(User user) throws Exception {
		userDao.updateUserPwd(user);
	}
	

	//查询所有的一级菜单,以及它的子菜单
	public List<Menu> queryMenuList(int roleID) throws Exception {
		//1.查询所有的一级菜单
		List <Menu> menuList;
		menuList = userDao.queryLevelOne(roleID);
		//2.循环, 查询每一个一级菜单的子菜单
		for (Menu menu : menuList) {
			List<Menu> sonList = userDao.querySonMenu(menu.getId(), roleID);
			menu.setSonList(sonList);
		}
		return  menuList;
	}
	
	//根据user的账号和emp的编号来查询t_user表和t_empoyee表做账户显示用
	public List<UserVo> queryAllUser() throws Exception {
		return userDao.queryAllUser();
	}
	
	// 根据账号、账号状态、角色id来模糊查询t_user表
	public List <UserVo> queryAllUserByPage(Map<String, Object>paramMap) throws Exception{
		return userDao.queryAllUserByPage(paramMap);
	}

	//根据帐户的帐号删除账户
	public void deleteUser(User user) throws Exception {
		 userDao.deleteUser(user);
	}
	//修改帐户的信息
	public void insertUser(User user) throws Exception {
		userDao.insertUser(user);
	}
	//添加账户信息
	public void updateUser(User user) throws Exception {
		userDao.updateUser(user);
	}

	
}
