package service;

import java.util.List;

import entity.SystemConfig;

public interface SystemConfigService {
	
	//根据配置表查找配置holiday的key找到对应的value
	public List <SystemConfig> queryType(String configType);
}
