package service;

import java.util.List;
import java.util.Map;

import entity.Emp;



public interface EmpService {
	
	//添加员工信息
	public void insertEmp(Emp emp);
	
	//删除员工信息
	public void deleteEmp(int id);
	
	//修改员工信息
	public void updateEmp(Emp emp);
	
	//查询员工信息
	public List<Emp> queryAll();
	public Emp query(int id );
	public List<Emp> query(String no);
	public List<Emp> queryByName(String name) ;
	public  int queryCount(Map<String, Object>parmMap);
	public List<Emp> queryByPage(Map<String, Object>parmMap);
}
