package service;

import java.util.List;

import entity.Menu;

public interface MenuService {
	/**
	 * 查询所有的菜单
	 * @return List
	 * @throws Exception 
	 */
	public List<Menu> queryAllMenu() throws Exception;
}
