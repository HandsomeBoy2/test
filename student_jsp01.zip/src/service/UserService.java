package service;

import java.util.List;
import java.util.Map;

import vo.UserVo;

import entity.Menu;

import entity.User;

public interface UserService {
	/**
	 * 登录功能
	 * @param name
	 * @param pwd
	 * @return User
	 * @throws Exception 
	 */
	public abstract User login(String userName, String password) throws Exception;
	
	public abstract void updateUserPwd(User user) throws Exception;
	/**
	 * 查询所有的一级菜单,以及它的子菜单
	 * @return
	 */
	public List<Menu> queryMenuList(int roleID) throws Exception;
	
	
	/**
	 * 根据user的账号和emp的编号来查询t_user表和t_empoyee表做账户显示用
	 * @param user
	 * @param emp
	 * @return List
	 * @throws Exception
	 */
	public List<UserVo> queryAllUser() throws Exception;
	
	/**
	 * 根据账号、账号状态、角色id来模糊查询t_user表
	 * @param paramMap
	 * @return List 
	 * @throws Exception
	 */
	public List <UserVo> queryAllUserByPage(Map<String, Object>paramMap) throws Exception;
	
	/**
	 * 根据帐户的帐号删除账户
	 * @param user
	 * @throws Exception
	 */
	public void deleteUser(User user) throws Exception;
	
	/**
	 * 修改帐户的信息
	 * @param user
	 * @throws Exception
	 */
	public void updateUser(User user) throws Exception;
	
	/**
	 * 添加账户信息
	 * @param user
	 * @throws Exception
	 */
	public void insertUser(User user) throws Exception;
}
