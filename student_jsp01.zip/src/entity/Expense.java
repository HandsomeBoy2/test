package entity;

import java.util.Date;

public class Expense {
	private int id;
	private int expenseNo;
	private String expenseName;
	private String expenseType;
	private Double expenseMoney;
	private String expenseDate;
	private String expenseStatus;
	private String expenseDigest;
	private String createTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getExpenseNo() {
		return expenseNo;
	}
	public void setExpenseNo(int expenseNo) {
		this.expenseNo = expenseNo;
	}
	public String getExpenseName() {
		return expenseName;
	}
	public void setExpenseName(String expenseName) {
		this.expenseName = expenseName;
	}
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public Double getExpenseMoney() {
		return expenseMoney;
	}
	public void setExpenseMoney(Double expenseMoney) {
		this.expenseMoney = expenseMoney;
	}
	public String getExpenseDate() {
		return expenseDate;
	}
	public void setExpenseDate(String expenseDate) {
		this.expenseDate = expenseDate;
	}
	public String getExpenseStatus() {
		return expenseStatus;
	}
	public void setExpenseStatus(String expenseStatus) {
		this.expenseStatus = expenseStatus;
	}
	public String getExpenseDigest() {
		return expenseDigest;
	}
	public void setExpenseDigest(String expenseDigest) {
		this.expenseDigest = expenseDigest;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "Expense [createTime=" + createTime + ", expenseDate=" + expenseDate + ", expenseDigest=" + expenseDigest + ", expenseMoney=" + expenseMoney + ", expenseName=" + expenseName
				+ ", expenseNo=" + expenseNo + ", expenseStatus=" + expenseStatus + ", expenseType=" + expenseType + ", id=" + id + "]";
	}
	
	
}
