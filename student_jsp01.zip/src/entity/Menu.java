package entity;

import java.util.List;
/**
 * 菜单表实体类
 * @author soft01
 *
 */
public class Menu {
	private Integer id;
	private String menuName;
	//菜单请求地址
	private String hrefUrl;
	//父级菜单ID
	private Integer parentId;
	/**
	 * 子菜单
	 */
	private List<Menu> sonList;
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getHrefUrl() {
		return hrefUrl;
	}
	public void setHrefUrl(String hrefUrl) {
		this.hrefUrl = hrefUrl;
	}
	public List<Menu> getSonList() {
		return sonList;
	}
	public void setSonList(List<Menu> sonList) {
		this.sonList = sonList;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	@Override
	public String toString() {
		return "Menu [id=" + id + ", menuName=" + menuName + ", hrefUrl="
				+ hrefUrl + ", parentId=" + parentId + ", sonList=" + sonList
				+ "]";
	}
	
}
