package entity;
/**
 * 请假实体类
 * @author soft01
 *
 */
public class Holiday {
	private int id;
	private int holidayNo;
	private String holidayUser;
	private String holidayType;
	private String holidayBz;
	private String startTime;
	private String endTime;
	private String holidayStatus;
	private String createTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getHolidayNo() {
		return holidayNo;
	}
	public void setHolidayNo(int holidayNo) {
		this.holidayNo = holidayNo;
	}
	public String getHolidayUser() {
		return holidayUser;
	}
	public void setHolidayUser(String holidayUser) {
		this.holidayUser = holidayUser;
	}
	public String getHolidayType() {
		return holidayType;
	}
	public void setHolidayType(String holidayType) {
		this.holidayType = holidayType;
	}
	public String getHolidayBz() {
		return holidayBz;
	}
	public void setHolidayBz(String holidayBz) {
		this.holidayBz = holidayBz;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getHolidayStatus() {
		return holidayStatus;
	}
	public void setHolidayStatus(String holidayStatus) {
		this.holidayStatus = holidayStatus;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "Holiday [id=" + id + ", holidayNo=" + holidayNo
				+ ", holidayUser=" + holidayUser + ", holidayType="
				+ holidayType + ", holidayBz=" + holidayBz + ", startTime="
				+ startTime + ", endTime=" + endTime + ", holidayStatus="
				+ holidayStatus + ", creatTime=" + createTime + "]";
	}
}
