package entity;

import java.util.Date;
/**
 * User实体类
 * @author xzf
 *
 */
public class User {
	private int id;
	private String userAccount;
	private String userPwd;
	private String empNo;
	private int roleId;
	private String userStatus;
	private Date createTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "User [createTime=" + createTime + ", empNo=" + empNo + ", id=" + id + ", roleId=" + roleId + ", userAccount=" + userAccount + ", userPwd=" + userPwd + ", userStatus=" + userStatus
				+ ", toString()=" + super.toString() + "]";
	}
	
}
