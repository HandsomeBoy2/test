package entity;

import java.util.Map;
/**
 * mvc.xml中action元素对应的实体类
 * @author xzf
 *
 */
public class ActionConfig {
	
	private String name;
	private String className;
	private String method;
	private Map<String, ResultConfig> resultMap;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public Map<String, ResultConfig> getResultMap() {
		return resultMap;
	}
	public void setResultMap(Map<String, ResultConfig> resultMap) {
		this.resultMap = resultMap;
	}
	@Override
	public String toString() {
		return "ActionConfig [className=" + className + ", method=" + method + ", name=" + name + ", resultMap=" + resultMap + "]";
	}

	
}
