package entity;
/**
 * 配置表实体类
 * @author soft01
 *
 */
public class SystemConfig {
	private String configType;
	private String configKey;
	private String configPageValue;
	public String getConfigType() {
		return configType;
	}
	public void setConfigType(String configType) {
		this.configType = configType;
	}
	public String getConfigKey() {
		return configKey;
	}
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}
	public String getConfigPageValue() {
		return configPageValue;
	}
	public void setConfigPageValue(String configPageValue) {
		this.configPageValue = configPageValue;
	}
	@Override
	public String toString() {
		return "SystemConfig [configKey=" + configKey + ", configType=" + configType + ", configPageValue=" + configPageValue + "]";
	}
	
}
