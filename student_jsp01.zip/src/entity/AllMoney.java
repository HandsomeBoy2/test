package entity;

public class AllMoney {
	private String dept;
	private Double price;
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "AllMoney [dept=" + dept + ", price=" + price + "]";
	}
	
}	
