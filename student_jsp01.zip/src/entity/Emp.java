package entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 员工实体类
 * @author xzf
 *
 */
public class Emp implements Serializable {
	private Integer id;
	private String empNo;
	private String empName;
	private String empDept;
	private String empSex;
	private String empEducation;
	private String empEmail;
	private String empPhone;
	private String entryTime;
	private Date createTime;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpDept() {
		return empDept;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	public String getEmpSex() {
		return empSex;
	}
	public void setEmpSex(String empSex) {
		this.empSex = empSex;
	}
	public String getEmpEducation() {
		return empEducation;
	}
	public void setEmpEducation(String empEducation) {
		this.empEducation = empEducation;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpPhone() {
		return empPhone;
	}
	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}
	
	
	
	
	public String getEntryTime() {
		return entryTime;
	}
	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "Emp [createTime=" + createTime + ", empDept=" + empDept + ", empEducation=" + empEducation + ", empName=" + empName + ", empNo=" + empNo + ", empPhone=" + empPhone + ", empSex="
				+ empSex + ", empEmail=" + empEmail + ", entryTime=" + entryTime + ", id=" + id + ", toString()=" + super.toString() + "]";
	}
	
}
