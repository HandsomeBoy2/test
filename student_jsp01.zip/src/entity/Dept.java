package entity;

import java.sql.Date;

/**
 * 部门实体类
 * @author soft01
 *
 */
public class Dept {
	private String deptNo;
	private String deptName;
	private String deptLoc;
	private String deptManager;
	private String createTime;
	public String getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptLoc() {
		return deptLoc;
	}
	public void setDeptLoc(String deptLoc) {
		this.deptLoc = deptLoc;
	}
	public String getDeptManager() {
		return deptManager;
	}
	public void setDeptManager(String deptManager) {
		this.deptManager = deptManager;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "Dept [createTime=" + createTime + ", deptLoc=" + deptLoc + ", deptManager=" + deptManager + ", deptName=" + deptName + ", deptNo=" + deptNo + ", toString()=" + super.toString() + "]";
	}
	
}
