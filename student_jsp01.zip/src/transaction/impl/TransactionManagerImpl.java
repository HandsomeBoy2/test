package transaction.impl;

import java.sql.Connection;
import java.sql.SQLException;

import transaction.TransactionManager;
import util.JDBCUtil;


/**
 * 事务管理器具体实现
 * @author ljd
 *
 */
public class TransactionManagerImpl implements TransactionManager {
	public void beginTransation() throws Exception {
		Connection con=null;
		try {
			con=JDBCUtil.getConnection();//获得当前线程的Connection对象
			con.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("数据库访问失败");
		}
	}

	public void commit() throws Exception {
		Connection con=null;
		try {
			con=JDBCUtil.getConnection();//获得当前线程的Connection对象
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("数据库访问失败");
		} finally{
			JDBCUtil.close();
		}
		
	}

	public void rollback() {
		Connection con=null;
		try {
			con=JDBCUtil.getConnection();//获得当前线程的Connection对象
			con.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally{
			JDBCUtil.close();
		}
	}
	
}
