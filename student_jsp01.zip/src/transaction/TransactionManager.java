package transaction;

/**
 * 事务管理器
 * @author ljd
 *
 */
public interface TransactionManager {
	/**
	 * 开启事务
	 * @throws Exception 
	 */
	public abstract void beginTransation() throws Exception;
	/**
	 * 提交事务
	 * @throws Exception 
	 */
	public abstract void commit() throws Exception;
	/**
	 * 回滚事务
	 */
	public abstract void rollback();
}
